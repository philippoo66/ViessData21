﻿using System;
using System.Globalization;
using System.IO.Ports;
using System.Threading.Tasks;
using System.Windows.Forms;
using OptoLinkCommAsyncLib;

namespace OptoLinkTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private COptoLinkCommAsync mycomm = new COptoLinkCommAsync();

        // important better don't forget ++++++++++++++++++++++++++++++++++++++

        private async Task DoCleanExit()
        {
            await mycomm.CleanExit();
        }


        // protocol stuff ++++++++++++++++++++++++++++++++++++++

        private async Task<bool> Init300()
        {
            mycomm.fCancel = false;

            bool ret = await mycomm.Init300ProtocolA();

            ShowInfo("Init300: " + ret.ToString());

            chkProtocolV2.Checked = (mycomm.Protocol == PROTOCOL.VS2_300);

            return ret;
        }

        private void BackToKW()
        {
            mycomm.SendBytes(new byte[1] { mycomm.EOT });  // 0x04
            chkProtocolV2.Checked = false;
        }


        // read write (flxible lenth) ++++++++++++++++++++++++++++++++++++++

        private async Task ReadData()
        {
            string msg = "Read Data - ";
            ushort addr = 0;
            byte len = 0;

            try
            {
                addr = ushort.Parse(tbAddr.Text, NumberStyles.AllowHexSpecifier);
                len = byte.Parse(tbLen.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }

            tbValue.Text = tbValHex.Text = String.Empty;

            mycomm.fCancel = false;

            CCommRequReturn rr = await mycomm.ReadDataA(addr, len);

            if (rr.Success)
            {
                //tbValue.Text = BitConverter.ToInt64(rr.Data, 0).ToString();
                if (rr.Data.Length <=8)
                {
                    UInt64 val = 0;
                    for (int i = 0; i < rr.Data.Length; i++)
                        val += (UInt64)rr.Data[i] << (8 * i);

                    tbValue.Text = val.ToString();
                }

                string valhex = String.Empty;
                for (int i = 0; i < rr.Data.Length; i++)
                    valhex += rr.Data[i].ToString("X2") + " ";

                tbValHex.Text = valhex;
                msg += "success";
            }
            else
            {
                tbValue.Text = tbValHex.Text = "<Error>";
                msg += "failed";
            }

            ShowInfo(msg);
        }

        private async Task WriteData()
        {
            string msg = "Write Data - ";
            ushort addr = 0;
            byte len = 0;
            Int64 val = 0;

            try
            {
                addr = ushort.Parse(tbAddr.Text, NumberStyles.AllowHexSpecifier);
                len = byte.Parse(tbLen.Text);
                val = Int64.Parse(tbValue.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Parse failed");
                return;
            }

            byte[] valb = BitConverter.GetBytes(val);
            byte[] data = new byte[len];

            // lsb - msb
            Array.Copy(valb, data, len);

            mycomm.fCancel = false;

            CCommRequReturn rr = await mycomm.WriteDataA(addr, data);

            string valhex = String.Empty;

            if (rr.Success)
            {
                for (int i = 0; i < data.Length; i++)
                    valhex += rr.Data[i].ToString("X2") + " ";

                tbValHex.Text = valhex;
                msg += "success";
            }
            else
            {
                tbValue.Text = tbValHex.Text = "<Error>";
                msg += "failed";
            }

            ShowInfo(msg);
        }


        // read write simple (fixed lenth) ++++++++++++++++++++++++++++++++++++++

        private async Task ReadNiveau()
        {
            int at = await mycomm.Read1ByteValueA(0x27d4, true);

            ShowInfo("Niveau: " + at.ToString());
        }

        private async Task WriteNiveau()
        {
            sbyte val;

            if (sbyte.TryParse(tbTest.Text, out val))
            {
                bool res = await mycomm.Write1ByteValueA(0x27d4, (byte)val);

                ShowInfo("Write Niveau: " + res.ToString());
            }
            else
                ShowInfo("Parse failed");
        }

        private async Task ReadATemp()
        {
            float at = await mycomm.Read2ByteValueA(0x0800, true, 0.1f);

            ShowInfo("ATemp: " + at.ToString("0.0"));
        }


        private async Task ReadF8KwBulk()
        {
            int val = await mycomm.Read2ByteValueA(0xF8);
            ShowInfo("F8_0: " + val.ToString("X4"));

            mycomm.fKWBulk = true;

            val = await mycomm.Read2ByteValueA(0xF8);
            ShowInfo("F8_1: " + val.ToString("X4"));

            val = await mycomm.Read2ByteValueA(0xF8);
            ShowInfo("F8_2: " + val.ToString("X4"));

            mycomm.fKWBulk = false;
        }


        // utils ++++++++++++++++++++++++++++++++++++++

        public void ShowInfo(string message)
        {
            lbxInfo.Items.Add(message);
            lbxInfo.SelectedIndex = lbxInfo.Items.Count - 1;
        }

        private void EnumComPorts()
        {
            string[] theSerialPortNames = SerialPort.GetPortNames();

            if (theSerialPortNames.Length == 0)
            {
                MessageBox.Show("Keinen COM Port gefunden.", "EnumComPorts");
                return;
            }

            Array.Sort(theSerialPortNames);

            cbxComPort.Items.Clear();
            cbxComPort.Items.AddRange(theSerialPortNames);
        }



        // ctrl events ++++++++++++++++++++++++++++++++++++++

        private void Form1_Load(object sender, EventArgs e)
        {
            EnumComPorts();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DoCleanExit();
        }

        private void lbxInfo_DoubleClick(object sender, EventArgs e)
        {
            lbxInfo.Items.Clear();
        }

        private void btnRefreshPorts_Click(object sender, EventArgs e)
        {
            EnumComPorts();
        }


        private void btnOpenPort_Click(object sender, EventArgs e)
        {
            string msg = "Open Port " + cbxComPort.Text;

            if (mycomm.OpenPort(cbxComPort.Text))
                msg += " - success.";
            else
                msg += " - failed!";

            ShowInfo(msg);
        }

        private void btnClosePort_Click(object sender, EventArgs e)
        {
            mycomm.ClosePort();
            ShowInfo("COM Port closed");
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            mycomm.fCancel = true;
        }

        private void btnUncancel_Click(object sender, EventArgs e)
        {
            mycomm.fCancel = false;
            //mycomm.fBusy = false; //!
        }

        private void btnInit300_Click(object sender, EventArgs e)
        {
            Init300();
        }

        private void btnSend04_Click(object sender, EventArgs e)
        {
            BackToKW();
        }


        private void btnRead_Click(object sender, EventArgs e)
        {
            ReadData();
        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            WriteData();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            ReadNiveau();
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            WriteNiveau();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ReadATemp();
        }

        private void chkProtocol_Click(object sender, EventArgs e)
        {
            if (chkProtocolV2.Checked)
                mycomm.Protocol = PROTOCOL.VS2_300;
            else
                mycomm.Protocol = PROTOCOL.VS1_KW;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ReadF8KwBulk();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            mycomm.SendBytes(new byte[1] { 0x01 });
        }

        private void btnConnectTcp_Click(object sender, EventArgs e)
        {
            mycomm.ClosePort();

            bool ret = mycomm.ConnectTcp(tbIP.Text, int.Parse(tbPort.Text));

            chkProtocolV2.Checked = (mycomm.Protocol == PROTOCOL.VS2_300);
            ShowInfo("TCP connected: " + ret.ToString());
        }

        private void btnDiconnectTcp_Click(object sender, EventArgs e)
        {
            mycomm.DisconnectTcp();
            ShowInfo("TCP disconnected");
        }

        private void chkFullRaw_CheckedChanged(object sender, EventArgs e)
        {
            mycomm.fTcpFullRaw = chkFullRaw.Checked;
        }
    }

}
