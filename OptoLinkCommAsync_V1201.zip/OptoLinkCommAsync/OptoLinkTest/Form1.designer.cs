﻿namespace OptoLinkTest
{
   partial class Form1
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
            this.lbxInfo = new System.Windows.Forms.ListBox();
            this.cbxComPort = new System.Windows.Forms.ComboBox();
            this.btnOpenPort = new System.Windows.Forms.Button();
            this.btnClosePort = new System.Windows.Forms.Button();
            this.btnRefreshPorts = new System.Windows.Forms.Button();
            this.btnWriteNiv = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnUncancel = new System.Windows.Forms.Button();
            this.btnSend04 = new System.Windows.Forms.Button();
            this.btnInit300 = new System.Windows.Forms.Button();
            this.tbTest = new System.Windows.Forms.TextBox();
            this.btnReadNiv = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.chkProtocolV2 = new System.Windows.Forms.CheckBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnWrite = new System.Windows.Forms.Button();
            this.btnRead = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.tbValHex = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbValue = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbLen = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbAddr = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gbxTcpip = new System.Windows.Forms.GroupBox();
            this.btnDiconnectTcp = new System.Windows.Forms.Button();
            this.btnConnectTcp = new System.Windows.Forms.Button();
            this.tbPort = new System.Windows.Forms.TextBox();
            this.tbIP = new System.Windows.Forms.TextBox();
            this.chkFullRaw = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbxTcpip.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbxInfo
            // 
            this.lbxInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxInfo.FormattingEnabled = true;
            this.lbxInfo.HorizontalScrollbar = true;
            this.lbxInfo.ItemHeight = 16;
            this.lbxInfo.Location = new System.Drawing.Point(16, 15);
            this.lbxInfo.Margin = new System.Windows.Forms.Padding(4);
            this.lbxInfo.Name = "lbxInfo";
            this.lbxInfo.Size = new System.Drawing.Size(247, 420);
            this.lbxInfo.TabIndex = 0;
            this.lbxInfo.DoubleClick += new System.EventHandler(this.lbxInfo_DoubleClick);
            // 
            // cbxComPort
            // 
            this.cbxComPort.FormattingEnabled = true;
            this.cbxComPort.Location = new System.Drawing.Point(271, 15);
            this.cbxComPort.Margin = new System.Windows.Forms.Padding(4);
            this.cbxComPort.Name = "cbxComPort";
            this.cbxComPort.Size = new System.Drawing.Size(155, 24);
            this.cbxComPort.TabIndex = 1;
            // 
            // btnOpenPort
            // 
            this.btnOpenPort.Location = new System.Drawing.Point(271, 48);
            this.btnOpenPort.Margin = new System.Windows.Forms.Padding(4);
            this.btnOpenPort.Name = "btnOpenPort";
            this.btnOpenPort.Size = new System.Drawing.Size(100, 30);
            this.btnOpenPort.TabIndex = 2;
            this.btnOpenPort.Text = "Open";
            this.btnOpenPort.UseVisualStyleBackColor = true;
            this.btnOpenPort.Click += new System.EventHandler(this.btnOpenPort_Click);
            // 
            // btnClosePort
            // 
            this.btnClosePort.Location = new System.Drawing.Point(379, 48);
            this.btnClosePort.Margin = new System.Windows.Forms.Padding(4);
            this.btnClosePort.Name = "btnClosePort";
            this.btnClosePort.Size = new System.Drawing.Size(100, 30);
            this.btnClosePort.TabIndex = 3;
            this.btnClosePort.Text = "Close";
            this.btnClosePort.UseVisualStyleBackColor = true;
            this.btnClosePort.Click += new System.EventHandler(this.btnClosePort_Click);
            // 
            // btnRefreshPorts
            // 
            this.btnRefreshPorts.Location = new System.Drawing.Point(433, 15);
            this.btnRefreshPorts.Name = "btnRefreshPorts";
            this.btnRefreshPorts.Size = new System.Drawing.Size(46, 25);
            this.btnRefreshPorts.TabIndex = 4;
            this.btnRefreshPorts.Text = "upd.";
            this.btnRefreshPorts.UseVisualStyleBackColor = true;
            this.btnRefreshPorts.Click += new System.EventHandler(this.btnRefreshPorts_Click);
            // 
            // btnWriteNiv
            // 
            this.btnWriteNiv.Location = new System.Drawing.Point(9, 73);
            this.btnWriteNiv.Name = "btnWriteNiv";
            this.btnWriteNiv.Size = new System.Drawing.Size(120, 30);
            this.btnWriteNiv.TabIndex = 5;
            this.btnWriteNiv.Text = "Write Niveau";
            this.btnWriteNiv.UseVisualStyleBackColor = true;
            this.btnWriteNiv.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(379, 85);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnUncancel
            // 
            this.btnUncancel.Location = new System.Drawing.Point(271, 85);
            this.btnUncancel.Name = "btnUncancel";
            this.btnUncancel.Size = new System.Drawing.Size(100, 30);
            this.btnUncancel.TabIndex = 7;
            this.btnUncancel.Text = "UnCancel";
            this.btnUncancel.UseVisualStyleBackColor = true;
            this.btnUncancel.Click += new System.EventHandler(this.btnUncancel_Click);
            // 
            // btnSend04
            // 
            this.btnSend04.Location = new System.Drawing.Point(502, 85);
            this.btnSend04.Name = "btnSend04";
            this.btnSend04.Size = new System.Drawing.Size(202, 30);
            this.btnSend04.TabIndex = 8;
            this.btnSend04.Text = "back to KW Protocol";
            this.btnSend04.UseVisualStyleBackColor = true;
            this.btnSend04.Click += new System.EventHandler(this.btnSend04_Click);
            // 
            // btnInit300
            // 
            this.btnInit300.Location = new System.Drawing.Point(502, 48);
            this.btnInit300.Name = "btnInit300";
            this.btnInit300.Size = new System.Drawing.Size(202, 30);
            this.btnInit300.TabIndex = 9;
            this.btnInit300.Text = "Init 300 Protocol";
            this.btnInit300.UseVisualStyleBackColor = true;
            this.btnInit300.Click += new System.EventHandler(this.btnInit300_Click);
            // 
            // tbTest
            // 
            this.tbTest.Location = new System.Drawing.Point(144, 77);
            this.tbTest.Name = "tbTest";
            this.tbTest.Size = new System.Drawing.Size(45, 22);
            this.tbTest.TabIndex = 11;
            this.tbTest.Text = "-2";
            this.tbTest.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnReadNiv
            // 
            this.btnReadNiv.Location = new System.Drawing.Point(9, 30);
            this.btnReadNiv.Name = "btnReadNiv";
            this.btnReadNiv.Size = new System.Drawing.Size(120, 30);
            this.btnReadNiv.TabIndex = 12;
            this.btnReadNiv.Text = "Read Niveau";
            this.btnReadNiv.UseVisualStyleBackColor = true;
            this.btnReadNiv.Click += new System.EventHandler(this.button1_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(154, 30);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(120, 30);
            this.button5.TabIndex = 14;
            this.button5.Text = "Read Temp";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // chkProtocolV2
            // 
            this.chkProtocolV2.AutoSize = true;
            this.chkProtocolV2.Location = new System.Drawing.Point(501, 17);
            this.chkProtocolV2.Name = "chkProtocolV2";
            this.chkProtocolV2.Size = new System.Drawing.Size(133, 20);
            this.chkProtocolV2.TabIndex = 15;
            this.chkProtocolV2.Text = "VS2_300 Protocol";
            this.chkProtocolV2.UseVisualStyleBackColor = true;
            this.chkProtocolV2.Click += new System.EventHandler(this.chkProtocol_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(299, 30);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(120, 30);
            this.button7.TabIndex = 17;
            this.button7.Text = "Read Bulk (KW)";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(299, 73);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(120, 30);
            this.button8.TabIndex = 18;
            this.button8.Text = "Send 0x01";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnWrite);
            this.groupBox1.Controls.Add(this.btnRead);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tbValHex);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tbValue);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tbLen);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.tbAddr);
            this.groupBox1.Location = new System.Drawing.Point(271, 189);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(433, 122);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Read Data";
            // 
            // btnWrite
            // 
            this.btnWrite.ForeColor = System.Drawing.Color.Red;
            this.btnWrite.Location = new System.Drawing.Point(282, 55);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(137, 30);
            this.btnWrite.TabIndex = 21;
            this.btnWrite.Text = "Write dec Value";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(282, 20);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(137, 30);
            this.btnRead.TabIndex = 20;
            this.btnRead.Text = "Read Data";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 83);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 16);
            this.label4.TabIndex = 19;
            this.label4.Text = "hex";
            // 
            // tbValHex
            // 
            this.tbValHex.BackColor = System.Drawing.SystemColors.Window;
            this.tbValHex.Location = new System.Drawing.Point(55, 80);
            this.tbValHex.Name = "tbValHex";
            this.tbValHex.ReadOnly = true;
            this.tbValHex.Size = new System.Drawing.Size(185, 22);
            this.tbValHex.TabIndex = 18;
            this.tbValHex.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 16);
            this.label3.TabIndex = 17;
            this.label3.Text = "Value";
            // 
            // tbValue
            // 
            this.tbValue.Location = new System.Drawing.Point(55, 52);
            this.tbValue.Name = "tbValue";
            this.tbValue.Size = new System.Drawing.Size(185, 22);
            this.tbValue.TabIndex = 16;
            this.tbValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(141, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 16);
            this.label2.TabIndex = 15;
            this.label2.Text = "Lenght";
            // 
            // tbLen
            // 
            this.tbLen.Location = new System.Drawing.Point(195, 24);
            this.tbLen.Name = "tbLen";
            this.tbLen.Size = new System.Drawing.Size(30, 22);
            this.tbLen.TabIndex = 14;
            this.tbLen.Text = "8";
            this.tbLen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 16);
            this.label1.TabIndex = 13;
            this.label1.Text = "Addr hex";
            // 
            // tbAddr
            // 
            this.tbAddr.Location = new System.Drawing.Point(73, 24);
            this.tbAddr.Name = "tbAddr";
            this.tbAddr.Size = new System.Drawing.Size(52, 22);
            this.tbAddr.TabIndex = 12;
            this.tbAddr.Text = "00F8";
            this.tbAddr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button5);
            this.groupBox2.Controls.Add(this.button8);
            this.groupBox2.Controls.Add(this.btnReadNiv);
            this.groupBox2.Controls.Add(this.button7);
            this.groupBox2.Controls.Add(this.tbTest);
            this.groupBox2.Controls.Add(this.btnWriteNiv);
            this.groupBox2.Location = new System.Drawing.Point(271, 317);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(433, 122);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Play / Example";
            // 
            // gbxTcpip
            // 
            this.gbxTcpip.Controls.Add(this.chkFullRaw);
            this.gbxTcpip.Controls.Add(this.btnDiconnectTcp);
            this.gbxTcpip.Controls.Add(this.btnConnectTcp);
            this.gbxTcpip.Controls.Add(this.tbPort);
            this.gbxTcpip.Controls.Add(this.tbIP);
            this.gbxTcpip.Location = new System.Drawing.Point(271, 124);
            this.gbxTcpip.Name = "gbxTcpip";
            this.gbxTcpip.Size = new System.Drawing.Size(433, 58);
            this.gbxTcpip.TabIndex = 22;
            this.gbxTcpip.TabStop = false;
            this.gbxTcpip.Text = "TCP/IP";
            // 
            // btnDiconnectTcp
            // 
            this.btnDiconnectTcp.Location = new System.Drawing.Point(334, 18);
            this.btnDiconnectTcp.Margin = new System.Windows.Forms.Padding(4);
            this.btnDiconnectTcp.Name = "btnDiconnectTcp";
            this.btnDiconnectTcp.Size = new System.Drawing.Size(85, 30);
            this.btnDiconnectTcp.TabIndex = 23;
            this.btnDiconnectTcp.Text = "Disconnect";
            this.btnDiconnectTcp.UseVisualStyleBackColor = true;
            this.btnDiconnectTcp.Click += new System.EventHandler(this.btnDiconnectTcp_Click);
            // 
            // btnConnectTcp
            // 
            this.btnConnectTcp.Location = new System.Drawing.Point(241, 18);
            this.btnConnectTcp.Margin = new System.Windows.Forms.Padding(4);
            this.btnConnectTcp.Name = "btnConnectTcp";
            this.btnConnectTcp.Size = new System.Drawing.Size(85, 30);
            this.btnConnectTcp.TabIndex = 22;
            this.btnConnectTcp.Text = "Connect";
            this.btnConnectTcp.UseVisualStyleBackColor = true;
            this.btnConnectTcp.Click += new System.EventHandler(this.btnConnectTcp_Click);
            // 
            // tbPort
            // 
            this.tbPort.Location = new System.Drawing.Point(120, 22);
            this.tbPort.Name = "tbPort";
            this.tbPort.Size = new System.Drawing.Size(50, 22);
            this.tbPort.TabIndex = 21;
            this.tbPort.Text = "65234";
            this.tbPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbIP
            // 
            this.tbIP.Location = new System.Drawing.Point(9, 22);
            this.tbIP.Name = "tbIP";
            this.tbIP.Size = new System.Drawing.Size(105, 22);
            this.tbIP.TabIndex = 20;
            this.tbIP.Text = "127.0.0.1";
            this.tbIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // chkFullRaw
            // 
            this.chkFullRaw.AutoSize = true;
            this.chkFullRaw.Location = new System.Drawing.Point(176, 16);
            this.chkFullRaw.Name = "chkFullRaw";
            this.chkFullRaw.Size = new System.Drawing.Size(48, 36);
            this.chkFullRaw.TabIndex = 24;
            this.chkFullRaw.Text = "full\r\nraw";
            this.chkFullRaw.UseVisualStyleBackColor = true;
            this.chkFullRaw.CheckedChanged += new System.EventHandler(this.chkFullRaw_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(715, 444);
            this.Controls.Add(this.gbxTcpip);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.chkProtocolV2);
            this.Controls.Add(this.btnInit300);
            this.Controls.Add(this.btnSend04);
            this.Controls.Add(this.btnUncancel);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnRefreshPorts);
            this.Controls.Add(this.btnClosePort);
            this.Controls.Add(this.btnOpenPort);
            this.Controls.Add(this.cbxComPort);
            this.Controls.Add(this.lbxInfo);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "OptoLinkTest";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.gbxTcpip.ResumeLayout(false);
            this.gbxTcpip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.ListBox lbxInfo;
      private System.Windows.Forms.ComboBox cbxComPort;
      private System.Windows.Forms.Button btnOpenPort;
      private System.Windows.Forms.Button btnClosePort;
      private System.Windows.Forms.Button btnRefreshPorts;
      private System.Windows.Forms.Button btnWriteNiv;
      private System.Windows.Forms.Button btnCancel;
      private System.Windows.Forms.Button btnUncancel;
      private System.Windows.Forms.Button btnSend04;
      private System.Windows.Forms.Button btnInit300;
      private System.Windows.Forms.TextBox tbTest;
      private System.Windows.Forms.Button btnReadNiv;
      private System.Windows.Forms.Button button5;
      private System.Windows.Forms.CheckBox chkProtocolV2;
      private System.Windows.Forms.Button button7;
      private System.Windows.Forms.Button button8;
      private System.Windows.Forms.GroupBox groupBox1;
      private System.Windows.Forms.Label label3;
      private System.Windows.Forms.TextBox tbValue;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.TextBox tbLen;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.TextBox tbAddr;
      private System.Windows.Forms.Label label4;
      private System.Windows.Forms.TextBox tbValHex;
      private System.Windows.Forms.Button btnRead;
      private System.Windows.Forms.Button btnWrite;
      private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox gbxTcpip;
        private System.Windows.Forms.Button btnDiconnectTcp;
        private System.Windows.Forms.Button btnConnectTcp;
        private System.Windows.Forms.TextBox tbPort;
        private System.Windows.Forms.TextBox tbIP;
        private System.Windows.Forms.CheckBox chkFullRaw;
    }
}

