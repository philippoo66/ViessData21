﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ViessData
{
   public partial class FCopyZeiten : Form
   {
      public FCopyZeiten(int source, ref bool[] destinations)
      {
         InitializeComponent();
         src = source;
         Init();
         dests = destinations;
      }

      string[] wtage = new string[7] { "Montag", "Dienstag", "Mittwoch", "Donnestag", "Freitag", "Samstag", "Sonntag" };
      List<CheckBox> lstchks = new List<CheckBox>();
      private bool[] dests = new bool[7];
      private int src = 0;

      private void Init()
      {
         lstchks = new List<CheckBox>();

         for (int i = 0; i < 7; i++)
         {
            // chkDest
            CheckBox chk = new CheckBox();

            chk.AutoSize = true;
            chk.Location = new System.Drawing.Point(20, 15 + i * 25);
            chk.Name = "chkDest";
            chk.Size = new System.Drawing.Size(80, 17);
            chk.TabIndex = 2;
            chk.Text = wtage[i];
            chk.UseVisualStyleBackColor = true;
            chk.Enabled = (i != src);
            chk.Checked = false;

            lstchks.Add(chk);
            this.Controls.Add(chk);
         }

         Size size = new Size(this.ClientSize.Width, lstchks[6].Top + 65);
         this.ClientSize = size;
      }

      private void OnOk()
      {
         for (int i = 0; i < 7; i++)
            if (lstchks[i].Checked) dests[i] = true;

         this.DialogResult = DialogResult.OK;
         this.Hide();
      }

      private void SelectAll()
      {
         for (int i = 0; i < 7; i++)
            if (i != src) lstchks[i].Checked = true;
      }

      private void btnOk_Click(object sender, EventArgs e)
      {
         OnOk();
      }

      private void btnAll_Click(object sender, EventArgs e)
      {
         SelectAll();
      }
   }
}
