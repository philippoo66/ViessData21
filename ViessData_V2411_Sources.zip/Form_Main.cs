﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using GraphLib;
using OptoLinkCommAsyncLib;

namespace ViessData
{
    public partial class Main_Form : Form
    {

        /* Copyright (c) 2011 Chris, Code Modifications Ver. 2.1.x (c) 2023 Phil Oebel  
        * Permission is hereby granted, free of charge, to any person obtaining a copy 
        * of this software and associated documentation files (the "Software"), to 
        * deal in the Software without restriction, including without limitation the 
        * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or 
        * sell copies of the Software, and to permit persons to whom the Software is 
        * furnished to do so, subject to the following conditions:
        * 
        * The above copyright notice and this permission notice shall be included in 
        * all copies or substantial portions of the Software. 
        * 
        * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
        * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
        * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
        * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
        * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
        * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
        * THE SOFTWARE.
        */

        #region DEKLARATIONEN

        public static Main_Form frmMain;

        //int Zeichenanzahl1;
        string Applikation_Pfad;
        string Appname = "Viessdata " + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString();
        string DataFilename;       // CSV Datei für Daten - das angezeigte
        string DataFilename_akt;   // CSV Datei für Daten - da wo aktuell gelesene reingeschrieben werden
                                   //string DumpFilename;   // Name für Dumpdaten
        string cfg_DateiName = "vito_Config.xml";
        string cfg_Datei;       // applicationpath + cfg_dateiname
        string dp_Dateiname = "vito_DP.xml";
        string dp_Datei;
        string ds_Dateiname = "vito_Durchschnitt.xml";
        string ds_Datei;


        // nur noch 'informell'
        private string portName;

        private int iPollDelay = 30000;

        //public System.IO.Ports.SerialPort mySerialPort = new System.IO.Ports.SerialPort();
        //private int baudRate;
        //private Parity parity;
        //private int dataBits;
        //private StopBits stopBits;
        //private Handshake handshake;

        //public static Byte[] My_Serial_Output_Buffer = new byte[256];
        //public static Byte[] My_Serial_Input_Buffer = new byte[256];
        //public int My_Serial_Input_Buffer_Zeiger;
        //public int Ser_Uebertragungsstatus = 0;
        //public int Warte_auf_AntwortTelegramm = 0;
        //public int gelesener_Datenpunkt = 0;

        public float volstrom = 9999, kesseltemp;
        public int SparA5 = -20, SparA6 = -20, RTStemp = -20;
        public byte sparhkpumpe = 16;


        #region Graph vars
        // timing ++++
        private int Minuten_seit_Montag_alt;

        // Graph Skalierung ++++
        private int iGraphStepsPerHour = 60;      // minutes
        private const int ciTwentyfourSeven = 168; // 24*7
        private int Skala_in_Min = 2880;
        private int RangeX = 240;
        private int Value_old = 0;  //??

        private float rAnaDefault = -20.0f;

        public class CGraphInfo
        {
            public string addr = "0";
            public string label = String.Empty;
            public Color color = Color.White;
            public bool active = true;
            public bool analog = true;
            public bool hidden = false; // false bei Werten nur für Statistik
            public int column = 0;
        }
        public List<CGraphInfo> lstGraphInfo = new List<CGraphInfo>();
        #endregion Graph vars

        public string myDate = DateTime.Now.ToString("yyyy-MM-dd");

        // poll timer
        System.Windows.Forms.Timer tmrPoll = new System.Windows.Forms.Timer(); // Timer anlegen

        // Verbrauch stuff +++++
        private static double maxpower = 19;            //Max.Leistung der Therme 
        private static double zzahl = 1;           //Gas Zustandszahl 
        private static double brennwert = 10;      //Gas Brennwert

        private static double gaswert = maxpower / zzahl / brennwert; //Max.Leistung der Therme und Umrechnung kWh - Kubikmeter Gas



        // Zeiten Kram Control Arrays
        private List<TextBox> lstTbZeiten = new List<TextBox>();
        private List<Button> lstBtnCopy = new List<Button>();
        private List<Button> lstBtnWriteDay = new List<Button>();

        //private ushort iZeitenTabBaseAddr = 0x2000;

        private string[] Wochentag = new string[7] { "Mo", "Di", "Mi", "Do", "Fr", "Sa", "So" }; // testweise

        //  plotterDisplayEx1.BackgroundColorTop = Color.FromArgb(0, 64, 0);
        //private PrecisionTimer.HighPerfTimer mTimer = null;
        //private static NotifyIcon notico;  // eigenes Icon

        private bool auto_start = false;

        //private static FDebug frmDebug = new FDebug();
        private COptoLinkCommAsync mycomm = new COptoLinkCommAsync();  // (frmDebug.lbxInfo);

        private const string csBlank = " ";
        private const string csCrLf = "\r\n";

        public CHeatingDevice.CDevice currDevice = new CHeatingDevice.CDevice();
        private bool fDeviceReadDone = false;
        #endregion

        // aus Main  Application.Run(new Main_Form(args))
        public Main_Form(string[] args)  // Init
        {
            InitializeComponent();

            frmMain = this;

            foreach (string s in args)
            {
                if (s.ToLower().Contains("a")) auto_start = true;
            }

            InitPathsAndFiles();
        }

        private void createDataFile()
        {
            DateTime jetzt = DateTime.Now;
            CultureInfo CUI = new CultureInfo("es-US", false); ;

            int kalenderwoche = CUI.Calendar.GetWeekOfYear(jetzt, CUI.DateTimeFormat.CalendarWeekRule, (System.DayOfWeek)1);
            int kalendermonat = CUI.Calendar.GetMonth(jetzt);
            int my_year = Convert.ToInt32(jetzt.ToString("yyyy"));

            // geht auch schon mal daneben... lieber zwei halbe
            //if (kalenderwoche == 53)
            //{
            //   kalenderwoche = 1;
            //   my_year = Convert.ToInt32(jetzt.ToString("yyyy"));
            //   my_year++;
            //}
            //else
            //{
            //   my_year = Convert.ToInt32(jetzt.ToString("yyyy"));
            //}

            DataFilename = Path.Combine(Applikation_Pfad, my_year.ToString("0000") + "-KW" + kalenderwoche.ToString("00") + "_data.csv");

            if (File.Exists(DataFilename))
            {
            }
            else  // wenn Datei nicht da, dann erstellen
            {
                using (StreamWriter Stream_Writer = new StreamWriter(new FileStream(DataFilename, FileMode.Append, FileAccess.Write, FileShare.Write)))
                {
                    Stream_Writer.Write(System.DateTime.Now.ToString(";" + "yyyy-MM-dd") + ";");
                    for (int j = 0; j < mydataGridView1.RowCount; j++)
                    {
                        if (mydataGridView1["Sp.", j].Value.ToString() == "1")  // Wenn selektiert dann..
                        {
                            Stream_Writer.Write(mydataGridView1["addr", j].Value.ToString() + ";");
                        }
                    }
                    Stream_Writer.Write(csCrLf); // \r=return \n=newline
                }  // hier wird Stream_Writer und der zugrunde liegende FileStream geschlossen
            }

            DataFilename_akt = DataFilename;

            tbDataFile.Text = DataFilename;
            tbCurrDataFile.Text = DataFilename_akt;

        }

        private void OpenDataFile()
        {
            OpenFileDialog dlg = new OpenFileDialog();

            // Doppelklick in Spalte 'ParamWert'
            dlg.Filter = "Alle Daten-Dateien (*.csv)|*.csv";

            // Es sollen nicht mehrere Dateien ausgewählt werden können
            dlg.Multiselect = false;

            // Windows-Titel
            dlg.Title = "Datei auswählen";

            // Kein Standard-Verzeichnis
            dlg.InitialDirectory = String.Empty;

            // Keine Standard-Datei anzeigen
            dlg.FileName = Path.GetFileName(DataFilename);    //String.Empty;

            // Dialogfenster anzeigen und Ergebnis testen
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                DataFilename = dlg.FileName;
                CalcDataGraphs();
            }
        }

        // not used
        private void AdjustColumn(string name, string displayName)
        {
            DataGridViewColumn clmn = mydataGridView1.Columns[name];
            clmn.HeaderText = displayName;
            clmn.Visible = true;
            clmn.DisplayIndex = mydataGridView1.Columns.Count - 1;
        }

        private void UpdateScreen(int row)
        {
            // Achtung Event musste zu Fuss im Designer eingetragen werden.
            //if (e.ColumnIndex == 15) //mydataGridView1.Columns["Wert_Val"].Index & mydataGridView1.Columns["Wert_Val"].Index.ToString() != "0")   // wenn sich die Valuespalte geändert hat
            bool convertok;

            switch (mydataGridView1["addr", row].Value.ToString().ToUpper())
            {
                case "088E":  // Datum Zeit
                    TextBox0200.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;
                case "0800":  // Temperatur Sensor 1 Aussen 
                    TextBox0800.Text = String.Format("{0:0.0}", mydataGridView1["Wert_Val", row].Value); break;
                case "083A":  // Aussen Sensor  Status ok nicht ok
                    if (mydataGridView1["Wert_Val", row].Value.ToString() != "0")  // Wert val
                    { TextBox0800.BackColor = Color.Red; }
                    else { TextBox0800.BackColor = Color.LightGreen; }
                    break; // Hintergrund Rot
                case "0896":  // Temperatur Sensor Raum HK1 
                    if (mydataGridView1["len", row].Value.ToString() != "0")
                    {
                        TextBoxRT.Visible = true;
                        TextBoxRT.Text = String.Format("{0:0.0}", mydataGridView1["Wert_Val", row].Value);
                    }
                    break;
                case "5523":  // AussenTmp ged.
                    float ATged;
                    convertok = float.TryParse(mydataGridView1["Wert_Val", row].Value.ToString(), out ATged);
                    if ((convertok) && (SparA6 != -20))
                    {
                        if (ATged > SparA6) Label_SparA6.BackColor = Color.Green;
                        if (ATged < (SparA6 - 2)) Label_SparA6.BackColor = Color.LightGray;
                    }
                    if (!(convertok))
                    {
                        Label_SparA6.BackColor = Color.Yellow;
                    }
                    if ((SparA6 == -20))
                    {
                        Label_SparA6.BackColor = Color.LightGray;
                    }
                    break;
                case "5525":  // AussenTmp geg.
                    float ATgeg;
                    convertok = float.TryParse(mydataGridView1["Wert_Val", row].Value.ToString(), out ATgeg);
                    if ((convertok) && (SparA5 != -20) && (RTStemp != -20))
                    {
                        if (ATgeg > SparA5) Label_SparA5.BackColor = Color.Green;
                        if (ATgeg < (SparA5 - 1)) Label_SparA5.BackColor = Color.LightGray;
                    }
                    if (!(convertok))
                    {
                        Label_SparA5.BackColor = Color.Yellow;
                    }
                    if ((SparA5 == -20) || (RTStemp == -20))
                    {
                        Label_SparA5.BackColor = Color.LightGray;
                    }
                    break;
                case "5527":  // AussenTmp gem.
                    TextBox5525.Text = String.Format("{0:0.0}", mydataGridView1["Wert_Val", row].Value);
                    break;
                case "2500":  // Frostgefahr (Byte 16) und aktuelle RTS (Bytes 12..13, lsb..hsb, /10)
                    byte frostg = byte.Parse(mydataGridView1["Wert_hex", row].Value.ToString().Substring(16 * 3, 2), NumberStyles.HexNumber);  // Substring(ab wann,länge)

                    if ((frostg & 1) != 0)
                    { Frostgefahr.BackColor = Color.Red; }
                    else
                    { Frostgefahr.BackColor = Color.LightGray; }

                    // Bytes 12..13, lsb..hsb, /10
                    RTStemp = (byte.Parse(mydataGridView1["Wert_hex", row].Value.ToString().Substring(12 * 3, 2), NumberStyles.HexNumber) + byte.Parse(mydataGridView1["Wert_hex", row].Value.ToString().Substring(13 * 3, 2), System.Globalization.NumberStyles.HexNumber) * 256) / 10;
                    TB_RTSakt.Text = String.Format("{0:0.0}", RTStemp);

                    if (sparhkpumpe < 16)
                    {
                        SparA5 = RTStemp + 6 - sparhkpumpe;
                        if (sparhkpumpe == 0) SparA5 = -20;
                    }
                    break;

                case "0802":  // Temperatur Sensor 3 Kessel
                    TextBox0802.Text = String.Format("{0:0.0}", mydataGridView1["Wert_Val", row].Value);
                    convertok = float.TryParse(mydataGridView1["Wert_Val", row].Value.ToString(), out kesseltemp);
                    if (!convertok)
                    {
                        kesseltemp = 0;
                    }
                    break;
                case "083B":  // Kessel Sensor 2  Status ok nicht ok
                    if (mydataGridView1["Wert_Val", row].Value.ToString() != "0")  // Wert val
                    { TextBox0802.BackColor = Color.Red; }
                    else { TextBox0802.BackColor = Color.LightGreen; }
                    break; // Hintergrund Rot
                case "555A":  // KesselT Soll
                    TextBox0810.Text = String.Format("{0:0.0}", mydataGridView1["Wert_Val", row].Value); break;
                case "0C20":  // RL Temp
                    if (mydataGridView1["len", row].Value.ToString() != "0")    //wenn len=0, dann wird RL-Temp nicht von Therme geliefert und wird berechnet
                    {
                        label7.Visible = true;
                        TextBoxRL.Visible = true;
                        TextBoxRL.Text = String.Format("{0:0.0}", mydataGridView1["Wert_Val", row].Value);
                    }
                    break;

                case "0808":  // Temperatur Sensor 15 Abgas
                    TextBox0808.Text = String.Format("{0:0.0}", mydataGridView1["Wert_Val", row].Value); break;
                case "083E":  // Abgas Sensor 2  Status ok nicht ok
                    if (mydataGridView1["Wert_Val", row].Value.ToString() != "0")  // Wert val
                    { TextBox0808.BackColor = Color.Red; }
                    else { TextBox0808.BackColor = Color.LightGreen; }
                    break; // Hintergrund Rot

                case "0804":  // Temperatur Sensor 5 WW-Speicher
                    TextBox0804.Text = String.Format("{0:0.0}", mydataGridView1["Wert_Val", row].Value); break;
                case "083C":  // WW-Speicher Sensor   Status ok nicht ok
                    if (mydataGridView1["Wert_Val", row].Value.ToString() != "0")  // Wert val
                    { TextBox0804.BackColor = Color.Red; }
                    else { TextBox0804.BackColor = Color.LightGreen; }
                    break; // Hintergrund Rot
                case "6500":  // WW SpeicherT Soll
                    TextBox0812.Text = String.Format("{0:0.0}", mydataGridView1["Wert_Val", row].Value); break;

                case "55D3":  // Brennermodulation
                    TextBox0818.Text = mydataGridView1["Wert_Val", row].Value.ToString();
                    if (mydataGridView1["Wert_Hex", row].Value == null) break;
                    if (mydataGridView1["Wert_Hex", row].Value.ToString() != "00 ")
                    { Label0842.BackColor = Color.Green; }
                    else { Label0842.BackColor = Color.LightGray; }

                    int row_rltemp = ListRowIdx(0x0C20);
                    if ((row_rltemp >= 0) && (mydataGridView1["len", row_rltemp].Value.ToString() == "0"))    //wenn len=0, dann wird RL-Temp nicht von Therme geliefert und wird berechnet
                    {
                        float brennerleistung;
                        convertok = float.TryParse(mydataGridView1["Wert_Val", row].Value.ToString(), out brennerleistung);
                        if ((convertok) && (volstrom != 0) && (volstrom != 9999) && (kesseltemp != 0))
                        {
                            label7.Visible = true;
                            TextBoxRL.Visible = true;
                            TextBoxRL.Text = (kesseltemp - (brennerleistung / volstrom * maxpower * 0.8571579)).ToString("00.0");
                        }
                        else
                        {
                            if ((volstrom == 9999) || (!convertok))
                            { TextBoxRL.Text = String.Empty; }
                            else
                            {
                                label7.Visible = true;
                                TextBoxRL.Visible = true;
                                TextBoxRL.Text = kesseltemp.ToString("00.0");
                            }
                        }

                        mydataGridView1["Wert_Val", row_rltemp].Value = TextBoxRL.Text;
                    }
                    break;

                case "0A10":  // Umaschaltventil
                    switch (mydataGridView1["Wert_Val", row].Value.ToString())
                    {
                        case "0":
                            TextBox081A.Text = "nicht def.";
                            break;
                        case "1":
                            TextBox081A.Text = "Heizen";
                            break;
                        case "2":
                            TextBox081A.Text = "Mittelst.";
                            break;
                        case "3":
                            TextBox081A.Text = "Warmwasser";
                            break;
                        default:
                            break;
                    }
                    break;

                case "0A3C":  // Interne Pumpe 
                    if (mydataGridView1["len", row].Value.ToString() != "0")
                    {
                        TextBox080C.Text = mydataGridView1["Wert_Val", row].Value.ToString();
                        if (mydataGridView1["Wert_Hex", row].Value.ToString() != "00 ")
                        { Label3906.BackColor = Color.Green; }
                        else { Label3906.BackColor = Color.LightGray; }
                    }
                    break;
                //case "7660":  // Interne Pumpe Status
                //    if (mydataGridView1["Wert_Hex", Reihe].Value == null) break;
                //    if (mydataGridView1["Wert_Hex", Reihe].Value.ToString() == "01 ")
                //    { Label3906.BackColor = Color.Green; }
                //     else { Label3906.BackColor = Color.LightGray; } break;


                case "6513":  // Speicherladepumpe
                    if (mydataGridView1["Wert_Hex", row].Value == null) break;
                    if (mydataGridView1["Wert_Hex", row].Value.ToString() == "01 ")
                    { Label0845.BackColor = Color.Green; }
                    else { Label0845.BackColor = Color.LightGray; }
                    break;

                case "0C24":  // Volumenstrom
                    if (mydataGridView1["len", row].Value.ToString() != "0")
                    {
                        label9.Visible = true;
                        Label11.Visible = true;
                        TextBox080A.Visible = true;
                        convertok = float.TryParse(mydataGridView1["Wert_Val", row].Value.ToString(), out volstrom);
                        if (convertok)
                        {
                            TextBox080A.Text = (volstrom * 10).ToString();
                        }
                        else
                        {
                            volstrom = 9999;
                            TextBox080A.Text = String.Empty;
                        }
                    }
                    break;

                case "6515":  // Zirkulationspumpe 
                    if (mydataGridView1["len", row].Value.ToString() != "0")
                    {
                        if (mydataGridView1["Wert_Hex", row].Value == null) break;
                        if (mydataGridView1["Wert_Hex", row].Value.ToString() == "01 ")
                        { Label0846.BackColor = Color.Green; }
                        else { Label0846.BackColor = Color.LightGray; }
                    }
                    break;

                case "0A82":  // Sammelstoerung
                    if (mydataGridView1["Wert_Hex", row].Value == null) break;
                    if (mydataGridView1["Wert_Hex", row].Value.ToString() == "01 ")
                    { Label0883.BackColor = Color.Red; }
                    else { Label0883.BackColor = Color.LightGray; }
                    break;

                case "5738":  // Brennerstoerung
                    if (mydataGridView1["Wert_Hex", row].Value == null) break;
                    if (mydataGridView1["Wert_Hex", row].Value.ToString() != "00 ")
                    { label29.BackColor = Color.Red; }
                    else { label29.BackColor = Color.LightGray; }
                    break;

                case "088A": // Brennerstarts
                    TextBox088A.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;
                case "08A7": // Brennerstunden
                    TextBox08A7.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;
                case "2323": // Betriebsart 
                    byte mode = byte.Parse(mydataGridView1["Wert_Val", row].Value.ToString());
                    if (mode < 5) CB_Betriebsart.SelectedIndex = mode;
                    break;
                case "2302": // Checkbox Sparbetrieb M2
                    if (mydataGridView1["Wert_Hex", row].Value == null) break;
                    if (mydataGridView1["Wert_Hex", row].Value.ToString() == "01 ")
                    { ChB_Sparbetrieb.Checked = true; }
                    else { ChB_Sparbetrieb.Checked = false; }
                    break;
                case "2303": // Checkbox Partybetrieb M2
                    if (mydataGridView1["Wert_Hex", row].Value == null) break;
                    if (mydataGridView1["Wert_Hex", row].Value.ToString() == "01 ")
                    { ChB_Partybetrieb.Checked = true; }
                    else { ChB_Partybetrieb.Checked = false; }
                    break;
                case "2308": // Raumtemperatur Party Soll
                    TextBoxRTS_Party.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;
                case "6300": // WW Soll
                    TextBoxWWS.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;
                case "27D4": // M2 Niveau
                    TextBox3304.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;
                case "27D3": // M2 Neigung
                    TextBox3305.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;
                case "2306":  // Raumtemp Tag soll
                    TextBoxRTS_Tag.Text = mydataGridView1["Wert_Val", row].Value.ToString();
                    break;

                case "2307":  // Raumtemp Nacht soll
                    TextBoxRTS_Nacht.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;

                case "27FA":  // KTS Erhoehung nach red. Betrieb
                    TB_ErhoehungKTS.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;
                case "27FB":  // KTS Erhoehungszeit nach red. Betrieb
                    TB_ErhoehungszeitKTS.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;
                case "27E7":  // Pumpenleistung min bei Normbetrieb
                    TB_PlstminbeiNorm.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;
                case "27E6":  // Pumpenleistung max bei Normbetrieb
                    TB_PlstmaxbeiNorm.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;
                case "27E8":  // Pumpenleistung bei red. Betrieb ?
                    if (mydataGridView1["Wert_Val", row].Value.ToString() == "1")
                        ChB_PlstbeiRed.Checked = true;
                    else
                        ChB_PlstbeiRed.Checked = false;
                    break;
                case "27E9":  // Pumpenleistung bei red. Betrieb
                    TB_PlstbeiRed.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;
                case "676C":  // Pumpenleistung bei WW Bereitung
                    TB_PumpebeiWW.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;

                case "6759": // WW Hysterese 
                    byte wwhysterese = byte.Parse(mydataGridView1["Wert_Val", row].Value.ToString());
                    if (wwhysterese < 11) CB_WWHysterese.SelectedIndex = wwhysterese;
                    break;

                case "27A3": // Frostschutztemp 
                    byte frostschutz = (byte)(9 + short.Parse(mydataGridView1["Wert_Val", row].Value.ToString()));
                    if (frostschutz < 25) CB_Frostschutztemp.SelectedIndex = frostschutz;
                    break;

                case "8832":  // Max. Brennerleistung bei Normheizbetrieb
                    TB_MaxBrennerNH.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;
                case "676F":  // Max. Brennerleistung bei WW Bereitung
                    TB_MaxBrennerWW.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;
                case "6760":  // Max. Delta KTS zu WWS bei WW Bereitung
                    TB_MaxDeltaKTWW.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;
                case "6762":  // Pumpennachlaufzeit bei WW Bereitung
                    TB_NachlaufWW.Text = mydataGridView1["Wert_Val", row].Value.ToString(); break;
                case "7790":  // Dämpfung AT
                    TB_DaempfungAT.Text = (int.Parse(mydataGridView1["Wert_Val", row].Value.ToString()) * 10).ToString(); break;
                case "6773": // Frequenz Zirkulationpumpe 
                    byte zirkufrequ = byte.Parse(mydataGridView1["Wert_Val", row].Value.ToString());
                    if (zirkufrequ < 8) CB_ZirkuFrequ.SelectedIndex = zirkufrequ;
                    break;
                case "27A5": // Sparschaltung HK-Pumpe 
                    sparhkpumpe = byte.Parse(mydataGridView1["Wert_Val", row].Value.ToString());
                    if (sparhkpumpe < 16)
                    {
                        CB_SparHK.SelectedIndex = sparhkpumpe;
                        SparA5 = RTStemp + 6 - sparhkpumpe;
                        if (sparhkpumpe == 0) SparA5 = -20;
                    }
                    break;
                case "27A6": // Sparschaltung Brenner und HK-Pumpe 
                    byte sparbrenner = byte.Parse(mydataGridView1["Wert_Val", row].Value.ToString());
                    if ((sparbrenner > 4) && (sparbrenner < 37))
                    {
                        CB_SparBrenner.SelectedIndex = sparbrenner - 5;
                        SparA6 = sparbrenner + 1;
                        if (sparbrenner == 36) SparA6 = -20;
                    }
                    break;
                default:
                    break;

            }
        }

        //private void Beende_Ser_Uebertragung()
        //{
        //   // MessageBox.Show("hallo ende");
        //   int Minuten_seit_Montag = 0;

        //   Ser_Uebertragungsstatus = 0;  // dann alles  stoppen
        //   Reihe = 0;
        //   gelesener_Datenpunkt = 0;

        //   this.t1.Stop();
        //   this.Text = Appname + " - nicht verbunden ";
        //   this.toolStripLabel2.BackColor = Color.Red;
        //   //if (mySerialPort.IsOpen) 
        //   //    mySerialPort.Close();

        //   // nur Selektierte speichern vielleicht RAM-Disk?
        //   //if (lese_alle_Datenpunkte == false)  //c1
        //   {


        //      Minuten_seit_Montag = Programme.myRoutinen.BerechneMinute();
        //      if (Minuten_seit_Montag_alt == Minuten_seit_Montag)
        //      {
        //         goto jump1;  // nicht speichern
        //      }

        //      //neue Datei anlegen Sonntag 0Uhr
        //      //  int Minuten_seit_Montag = 0;

        //      if (Minuten_seit_Montag == 0)
        //      {
        //         createDatafilename();
        //         speichere_daten(Minuten_seit_Montag);
        //         InitDataGraphs(); // Daten löschen etc.
        //         plotterDisplayEx1.Refresh();
        //         goto jump1;
        //      }

        //      if (File.Exists(DataFilename)) // nur wenn die Datei existiert
        //                                     // Uhrzeit + ";" schreiben, anschließende alle Werte + ";" und noch ein CRLF 
        //      {
        //         try
        //         {
        //            speichere_daten(Minuten_seit_Montag);
        //         }
        //         catch (Exception ex)
        //         {
        //            ShowInfo( "Daten können nicht in Datei " + DataFilename + "geschrieben werden!";
        //            //return false;
        //         }
        //      }
        //   }

        //   jump1:
        //   Minuten_seit_Montag_alt = Minuten_seit_Montag;
        //   //toolStripButton2.Image = Properties.Resources.Player_Play;  // Bildchen umschalten
        //   //toolStripButton2_pressed = false;      // Taster als nicht betaetigt markkieren  

        //   if (DataFilename == DataFilename_akt)
        //      CalcDataGraphs(); // Graf schieben

        //   if (toolStripComboBox1.SelectedItem.ToString() != "Stop")
        //   {
        //      t2.Start(); // Nächsten abfragezylus einschalten
        //   }

        //}

        private void Beende_Ser_Uebertragung_po()
        {
            int Minuten_seit_Montag = 0;

            this.tslblLed.BackColor = Color.Red;

            // nur Selektierte speichern vielleicht RAM-Disk?
            //if (lese_alle_Datenpunkte == false)  //c1
            {
                Minuten_seit_Montag = Programme.myRoutinen.BerechneMinute();

                if (Minuten_seit_Montag == 0)
                {
                    createDataFile();
                    speichere_daten(Minuten_seit_Montag);
                    InitGraphs(); // Daten löschen etc.
                    plotterDisplayEx1.Refresh();
                    goto jump1;
                }

                if (File.Exists(DataFilename)) // nur wenn die Datei existiert
                {
                    try
                    {
                        // Uhrzeit + ";" schreiben, anschließende alle Werte + ";" und noch ein CRLF 
                        speichere_daten(Minuten_seit_Montag);
                    }
                    catch (Exception ex)
                    {
                        //ShowInfo("Daten können nicht in Datei " + DataFilename + "geschrieben werden!"); // +csCrLf+ ex.Message;
                        ShowInfo(DataFilename + ": " + ex.Message);
                        //return false;
                    }
                }
            }

            jump1:
            Minuten_seit_Montag_alt = Minuten_seit_Montag;
            //toolStripButton2.Image = Properties.Resources.Player_Play;  // Bildchen umschalten
            //toolStripButton2_pressed = false;      // Taster als nicht betaetigt markkieren  

            if (DataFilename == DataFilename_akt)
                CalcDataGraphs(); // Graf schieben
        }

        private void ShowInfo(string msg)
        {
            //Console.WriteLine(msg);
            if (lbxInfo.Items.Count > 500)
                lbxInfo.Items.RemoveAt(0);

            lbxInfo.Items.Add(msg);
            lbxInfo.SelectedIndex = lbxInfo.Items.Count - 1;

            //DoLog(msg);
        }


        #region Communication alt
        //private void send_parameter_(ushort address, byte value)
        //{
        //   My_Serial_Output_Buffer[0] = 0x41;  // Telegrammstart
        //   My_Serial_Output_Buffer[1] = 0x06;  // Nutzdaten, hier 6
        //   My_Serial_Output_Buffer[2] = 0x00;  // Anfrage
        //   My_Serial_Output_Buffer[3] = 0x02;  // Schreiben
        //   My_Serial_Output_Buffer[4] = (byte)(address >> 8);
        //   My_Serial_Output_Buffer[5] = (byte)(address % 0x100);
        //   My_Serial_Output_Buffer[6] = 0x01; // Länge mit de hex wandlung
        //   My_Serial_Output_Buffer[7] = value;
        //   My_Serial_Output_Buffer[8] = calc_CRC(My_Serial_Output_Buffer);
        //   if (!mySerialPort.IsOpen) Open_mySerialPort();
        //   mySerialPort.Write(My_Serial_Output_Buffer, 0, 9);  // Buffer senden
        //                                                       //mySerialPort.Close();
        //   if (lese_alle_Datenpunkte) lese_alle_Datenpunkte_zweimal = true;
        //   lese_alle_Datenpunkte = true; // Beim 1. Durchlauf alle lesen
        //   t1.Interval = 50;
        //   this.t1.Start(); // Timer starten
        //}


        //private byte calc_CRC(byte[] telegram)
        //{
        //   uint CRCsum = 0;
        //   byte telestart = 1;
        //   byte teleend = (byte)(telegram[1] + 1);

        //   if (telegram[0] != 0x41)       // vielleicht noch ein 0x06 davor?
        //   {
        //      telestart++;
        //      teleend = (byte)(telegram[2] + 2);
        //      if ((telegram[0] != 0x06) & (telegram[1] != 0x41)) return (0);
        //   }
        //   for (byte i = telestart; i <= teleend; i++)
        //   {
        //      CRCsum += telegram[i];
        //   }
        //   return ((byte)(CRCsum % 0x100));
        //}

        //private bool check_CRC()
        //{
        //   return (calc_CRC(My_Serial_Input_Buffer) == My_Serial_Input_Buffer[(My_Serial_Input_Buffer[2] + 3) % 0x100]);
        //}

        //private bool Open_mySerialPort()
        //{
        //   try
        //   {
        //      if (!mySerialPort.IsOpen)
        //      {
        //         //mySerialPort.Close();
        //         mySerialPort.PortName = Convert.ToString(CoBx_Ports.SelectedItem);
        //         mySerialPort.BaudRate = Convert.ToInt32(CoBx_BaudRate.SelectedItem);
        //         mySerialPort.Parity = (Parity)Enum.Parse(typeof(Parity), CoBx_Parity.SelectedItem.ToString());
        //         mySerialPort.DataBits = Convert.ToInt32(CoBx_Datenbits.SelectedItem);
        //         mySerialPort.StopBits = (StopBits)Enum.Parse(typeof(StopBits), CoBx_Stopbits.SelectedItem.ToString());
        //         // mySerialPort.Handshake = (Handshake)Enum.Parse(typeof(Handshake), cboHandshake.SelectedItem.ToString());


        //         mySerialPort.Open();

        //      }
        //      return true;

        //   }
        //   catch (Exception ex)
        //   {
        //      ShowInfo( "Problem beim Öffnen des COM-Ports!";
        //      //t1.Interval = 1000;
        //      //this.t1.Start(); // Timer starten

        //      return false;
        //   }
        //}
        #endregion Communication alt


        #region csv stuff
        private void speichere_daten(int Minuten_seit_Montag)
        {
            using (StreamWriter Stream_Writer = new StreamWriter(new FileStream(DataFilename_akt, FileMode.Append, FileAccess.Write, FileShare.Write)))
            {
                Stream_Writer.Write(Minuten_seit_Montag + ";" + System.DateTime.Now.ToString("ddd-HH:mm:ss") + ";"); //Uhrzeit speichern
                for (int row = 0; row < mydataGridView1.RowCount; row++) //gehe zeilenweise durchs Grid
                {   // Wenn selektiert und der Wert ist nicht null dann schreiben
                    if (mydataGridView1["SP.", row].Value.ToString() == "1" & mydataGridView1["Wert_Val", row].Value != null)
                    {
                        Stream_Writer.Write(mydataGridView1["Wert_Val", row].Value.ToString() + ";");
                    }
                }
                Stream_Writer.Write(System.DateTime.Now.ToString(csCrLf)); // abschließend in der Zeile noch ein CRLF
            }  // hier wird Stream_Writer und der zugrunde liegende FileStream geschlossen
        }
        #endregion csv stuff

        #region xml stuff
        //public void Lese_Steuerungen()
        //{
        //   // Parameter aus XML lesen
        //   XmlDocument ser_config = new XmlDocument();
        //   ser_config.Load(cfg_Datei);
        //   XmlNodeList deviceliste = ser_config.GetElementsByTagName("device");
        //   int z = 0;
        //   //  string[] Device_Array = new string[deviceliste.Count];

        //   foreach (XmlNode node in deviceliste)
        //   {
        //      if (node != null) //kein node in Datei
        //      {
        //         XmlAttribute xmlAttr0 = deviceliste[z].Attributes["ID"];
        //         Device_ID_Array[z] = xmlAttr0.InnerText;
        //         XmlAttribute xmlAttr1 = deviceliste[z].Attributes["name"];
        //         Device_name_Array[z] = xmlAttr1.InnerText;
        //         XmlAttribute xmlAttr2 = deviceliste[z].Attributes["protocol"];
        //         Device_protocol_Array[z] = xmlAttr2.InnerText;
        //         z++;
        //      }
        //   }
        //}

        private void load_maxpower()
        {
            XmlDocument therme_config = new XmlDocument();
            therme_config.Load(cfg_Datei);
            XmlNodeList therme_Liste = therme_config.GetElementsByTagName("Therme");

            foreach (XmlNode node in therme_Liste)
            {
                int z = 0;
                if (node != null) //kein node in Datei
                {
                    XmlNode xmlNode1 = therme_Liste[z].SelectSingleNode("MaxPower");
                    //maxpower = float.Parse(xmlNode1.InnerText, CultureInfo.InvariantCulture);
                    maxpower = float.Parse(CorrectedDecSep(xmlNode1.InnerText));
                    XmlNode xmlNode2 = therme_Liste[z].SelectSingleNode("ZZahl");
                    zzahl = float.Parse(CorrectedDecSep(xmlNode2.InnerText));
                    XmlNode xmlNode3 = therme_Liste[z].SelectSingleNode("Brennwert");
                    brennwert = float.Parse(CorrectedDecSep(xmlNode3.InnerText));

                    gaswert = maxpower / zzahl / brennwert;
                    z++;
                }
            }
        }

        private void save_maxpower()
        {
            try
            {
                XmlDocument therme_config = new XmlDocument();
                therme_config.Load(cfg_Datei);
                XmlNodeList therme_Liste = therme_config.GetElementsByTagName("Therme");

                foreach (XmlNode node in therme_Liste)
                {
                    int z = 0;
                    if (node != null) //kein node in Datei
                    {
                        XmlNode xmlNode1 = therme_Liste[z].SelectSingleNode("MaxPower");
                        xmlNode1.InnerText = maxpower.ToString();
                        XmlNode xmlNode2 = therme_Liste[z].SelectSingleNode("ZZahl");
                        xmlNode2.InnerText = zzahl.ToString();
                        XmlNode xmlNode3 = therme_Liste[z].SelectSingleNode("Brennwert");
                        xmlNode3.InnerText = brennwert.ToString();

                        z++;
                    }
                }

                therme_config.Save(cfg_Datei);
            }
            catch (Exception ex)
            {
                //ShowInfo( "Fehler: Datei " + dp_Dateiname + " nicht vorhanden";
                MessageBox.Show(ex.Message, "update " + cfg_DateiName);
                return;
            }

        }

        private void load_tcp()
        {
            // XmlDocument zum Laden der XML-Datei verwenden
            XmlDocument doc = new XmlDocument();
            doc.Load(cfg_Datei);

            // Das TCP-Element auswählen
            XmlNode tcpNode = doc.SelectSingleNode("/settings/TCP");

            // Überprüfen, ob das TCP-Element vorhanden ist
            if (tcpNode != null)
            {
                // Auf die untergeordneten Elemente von TCP zugreifen
                bool enable = bool.Parse(tcpNode.SelectSingleNode("Enable").InnerText);
                string ipAddress = tcpNode.SelectSingleNode("IpAddress").InnerText;
                int port = int.Parse(tcpNode.SelectSingleNode("Port").InnerText);

                //Console.WriteLine("TCP Einstellungen:");
                //Console.WriteLine("Enable: " + enable);
                //Console.WriteLine("IP-Adresse: " + ipAddress);
                //Console.WriteLine("Port: " + port);

                chkTcpEnable.Checked = enable;
                tbTcpIpAddr.Text = ipAddress;
                tbTcpPort.Text = port.ToString();
            }
            else
            {
                Console.WriteLine("TCP-Element nicht gefunden.");
            }
        }

        private void save_tcp(bool enable, string ipAddress, int port)
        {
            // XmlDocument zum Laden der XML-Datei verwenden
            XmlDocument doc = new XmlDocument();
            doc.Load(cfg_Datei);

            // Das TCP-Element auswählen
            XmlNode tcpNode = doc.SelectSingleNode("/settings/TCP");

            // Überprüfen, ob das TCP-Element vorhanden ist
            if (tcpNode != null)
            {
                // Auf die untergeordneten Elemente von TCP zugreifen und aktualisieren
                tcpNode.SelectSingleNode("Enable").InnerText = enable.ToString();
                tcpNode.SelectSingleNode("IpAddress").InnerText = ipAddress;
                tcpNode.SelectSingleNode("Port").InnerText = port.ToString();

                // Änderungen in der Datei speichern
                doc.Save(cfg_Datei);

                Console.WriteLine("TCP Einstellungen erfolgreich gespeichert.");
            }
            else
            {
                Console.WriteLine("TCP-Element nicht gefunden. Änderungen konnten nicht gespeichert werden.");
            }
        }

        #endregion xml stuff

        #region garph stuff
        private void PlotGraphs(PlotterDisplayEx plotterdisp, List<CGraphInfo> grafinfo)
        {
            // es werden aus der Datendatei anhand der 1. Zeile alle Daten (Stunde seit Montag, Datum Messwerte...)
            // die Postition bestimmt
            string line;
            string[] columns;
            int lasttime = 0, timediff;
            float valdiff;

            try
            {
                using (StreamReader stream_reader = new StreamReader(DataFilename))    //, Encoding.Unicode);
                {
                    // Werte holen
                    int time;
                    float val;

                    while ((line = stream_reader.ReadLine()) != null) // ab der 2. Zeile stehen Daten
                    {
                        columns = line.Split(new char[] { ';' }, StringSplitOptions.None);

                        if (int.TryParse((columns[0]).Trim(), out time))
                        {
                            //time = time * iGraphStepsPerHour / 60;

                            for (int chan = 0; chan < grafinfo.Count; chan++)
                            {
                                //if (grafinfo[chan].active)  // darf nicht wegen stat
                                {
                                    if (float.TryParse((columns[grafinfo[chan].column]).Trim(), out val))
                                    {
                                        plotterdisp.DataSources[chan].Samples[time].x = time;  // bei mehr als 1/min wird überschrieben 
                                        plotterdisp.DataSources[chan].Samples[time].y = val;   // und nur der letzte 'bleibt'

                                        // Lücken füllen
                                        timediff = time - lasttime;
                                        if ((timediff > 1) && (timediff <= 10)) // max 10 Min
                                        {
                                            valdiff = plotterdisp.DataSources[chan].Samples[time].y - plotterdisp.DataSources[chan].Samples[lasttime].y;
                                            for (int i = lasttime + 1; i < time; i++)
                                            {
                                                plotterdisp.DataSources[chan].Samples[i].x = i;
                                                plotterdisp.DataSources[chan].Samples[i].y
                                                   = plotterdisp.DataSources[chan].Samples[lasttime].y
                                                   + valdiff * (i - lasttime) / timediff;
                                            }
                                        }
                                    }
                                }
                            }

                            lasttime = time;
                        }
                    } // End_While
                } // End_Using 
            } // end try
            catch (Exception ex)
            {
                ShowInfo("Achtung: in PlotGraphs() ist irgendwas schief gegangen:"); //  keine Daten für Graphik an folgender Adresse vorhanden: " + Graph_addr.ToString() + " - " + ex.Message);
                ShowInfo(csBlank + ex.Message);
            }
        }

        protected void InitGraphs()
        {
            #region xml einlesen
            XmlDocument configxml = new XmlDocument();
            configxml.Load(cfg_Datei);
            XmlNodeList nlgraphs = configxml.GetElementsByTagName("Graph");

            lstGraphInfo = new List<CGraphInfo>();

            foreach (XmlNode ndgr in nlgraphs)
            {
                CGraphInfo grinfo = new CGraphInfo();

                XmlAttribute attrid = ndgr.Attributes["ID"];
                grinfo.analog = (attrid.InnerText.ToLower() != "digital");

                XmlNode naddr = ndgr.SelectSingleNode("addr");
                grinfo.addr = naddr.InnerText.ToUpper();

                XmlNode ndescr = ndgr.SelectSingleNode("description");
                if ((ndescr != null) && (ndescr.InnerText != String.Empty))
                    grinfo.label = ndescr.InnerText;

                XmlNode nactive = ndgr.SelectSingleNode("active");
                grinfo.active = bool.Parse(nactive.InnerText);

                XmlNode ncolor = ndgr.SelectSingleNode("color");
                string colr = ncolor.InnerText;

                if (colr.Contains("#"))
                {
                    int argb = Int32.Parse(colr.Replace("#", String.Empty), NumberStyles.HexNumber);
                    grinfo.color = Color.FromArgb(argb);
                }
                else
                {
                    grinfo.color = Color.FromName(colr);
                }

                lstGraphInfo.Add(grinfo);
            }
            #endregion xml einlesen

            #region Stat DPs noch dazu
            for (int i = 0; i < mydataGridView2.RowCount; i++)
            {
                bool found = false;
                for (int j = 0; j < lstGraphInfo.Count; j++)
                {
                    if (mydataGridView2.Rows[i].Cells["addr"].Value.ToString().ToUpper() == lstGraphInfo[j].addr)
                    {
                        found = true;
                        break;
                    }
                }

                if (!found)
                {
                    CGraphInfo grinfo = new CGraphInfo();
                    grinfo.addr = mydataGridView2.Rows[i].Cells["addr"].Value.ToString().ToUpper();
                    grinfo.label = "hidden_" + grinfo.addr + "_" + mydataGridView2.Rows[i].Cells["name"].Value.ToString();
                    grinfo.hidden = true;
                    grinfo.active = false;
                    grinfo.analog = true;

                    lstGraphInfo.Add(grinfo);
                }
            }
            #endregion Stat DPs noch dazu

            #region init empty labels
            for (int chan = 0; chan < lstGraphInfo.Count; chan++)
            {
                if (lstGraphInfo[chan].label == String.Empty)
                {
                    // get description from list
                    foreach (DataGridViewRow row in mydataGridView1.Rows)
                    {
                        if (row.Cells["addr"].Value.ToString() == lstGraphInfo[chan].addr)
                        {
                            lstGraphInfo[chan].label = row.Cells["name"].Value.ToString();
                            break;
                        }
                    }

                    // if still empty
                    if (lstGraphInfo[chan].label == String.Empty)
                    {
                        lstGraphInfo[chan].label = "Wert " + lstGraphInfo[chan].addr;
                    }
                }
            }
            #endregion init empty labels

            #region Spalten ermitteln
            using (StreamReader stream_reader = new StreamReader(DataFilename))    //, Encoding.Unicode);
            {
                string line = stream_reader.ReadLine(); // 1.Zeile lesen aber kann weg, nur zum bestimmen Anz. der DP(semik)  

                string[] columns = line.Split(new char[] { ';' }, StringSplitOptions.None);

                for (int chan = 0; chan < lstGraphInfo.Count; chan++)
                {
                    bool found = false;
                    for (int colm = 0; colm < columns.Length; colm++)
                    {
                        if (columns[colm] == lstGraphInfo[chan].addr)
                        {
                            lstGraphInfo[chan].column = colm;
                            found = true;
                        }
                    }

                    if (!found) // && lstGraphInfo[chan].active)
                    {
                        lstGraphInfo[chan].active = false;
                        ShowInfo("Datenpunkt für Graph/Statistik nicht gespeichert: Adr. " + lstGraphInfo[chan].addr);
                    }
                }
            } // end using
            #endregion Spalten ermitteln

            SuspendLayout();

            #region //?? wird das hier nicht später überschrieben? 
            int Minuten_seit_Montag = Programme.myRoutinen.BerechneMinute(); // Der Graph soll die richtigen Anfang haben
            if (Minuten_seit_Montag < Skala_in_Min)  //po temp
            {
                plotterDisplayEx1.SetDisplayRangeX(0, Skala_in_Min); // Bereich am Montag 
            }
            else
            {
                plotterDisplayEx1.SetDisplayRangeX(Minuten_seit_Montag - Skala_in_Min, Minuten_seit_Montag); // von / bis
            }
            #endregion //?? wird das hier nicht später überschrieben? 

            plotterDisplayEx1.SetGridDistanceX(RangeX);      // z.B. alle 120 Minuten (grids) eine vert. Linie 
            plotterDisplayEx1.SetGridOriginX(0);        // linker Rand bewirkt Verschiebung des grids
            plotterDisplayEx1.PanelLayout = GraphLib.PlotterGraphPaneEx.LayoutMode.NORMAL;

            #region make datasources
            plotterDisplayEx1.DataSources.Clear();

            foreach (CGraphInfo gr in lstGraphInfo)
            {
                GraphLib.DataSource ds = new GraphLib.DataSource();

                // X-Achsen beschriftung, entweder Datensatz oder Wochentag + Zeit
                ds.OnRenderXAxisLabel = RenderXLabel;
                ds.OnRenderYAxisLabel = RenderYLabel;
                ds.AutoScaleX = false; // schiebbar
                ds.AutoScaleY = false; // Y-Achse autobereich  
                ds.Visible_Y_Skala = false;
                ds.XAutoScaleOffset = 500; // li + re Rand nur bei AutoScaleX=true
                                           // ds.VisibleDataRange_X = 1000; //??
                ds.Active = gr.active;
                ds.GraphColor = gr.color;
                ds.Name = gr.label;

                ds.Length = iGraphStepsPerHour * ciTwentyfourSeven;  // Speichertiefe, 1Min*60*24*7= Woche

                float initval = 0;

                if (gr.analog)
                {
                    ds.SetDisplayRangeY(rAnaDefault, 110); // Wertebereich
                    ds.SetGridDistanceY(10);
                    initval = rAnaDefault;
                }
                else  // digital
                {
                    ds.SetDisplayRangeY(0, 20); // Wertebereich
                    ds.SetGridDistanceY(20);
                    initval = 0;
                }

                for (int i = 0; i < ds.Length; i++) //Data_src.Length; i++)   // Werte vorbelegen
                {
                    ds.Samples[i].x = i;
                    ds.Samples[i].y = initval; // der dazugehörige Y Wert. -10=default 
                }

                plotterDisplayEx1.DataSources.Add(ds);
            }
            #endregion make datasources

            #region old
            /*
            // Analogwerte vorbereiten
            for (int j = 0; j < Anzahl_Graph_ana; j++)
            {
               plotterDisplayEx1.DataSources.Add(new GraphLib.DataSource());
               // X-Achsen beschriftung, entweder Datensatz oder Wochentag + Zeit
               plotterDisplayEx1.DataSources[j].OnRenderXAxisLabel += RenderXLabel;
               plotterDisplayEx1.DataSources[j].Visible_Y_Skala = false;
               // plotterDisplayEx1.DataSources[0].Name = "Grapheeeeee" + (0 + 1);
               plotterDisplayEx1.DataSources[j].Length = iGraphStepsPerHour * ciTwentyfourSeven;  // Speichertiefe, 1Min*60*24*7= Woche
               plotterDisplayEx1.DataSources[j].AutoScaleY = false; // Y-Achse autobereich  
               plotterDisplayEx1.DataSources[j].SetDisplayRangeY(DefaultWert_AnaDaten, 110); // Wertebereich
               plotterDisplayEx1.DataSources[j].SetGridDistanceY(10);
               plotterDisplayEx1.DataSources[j].AutoScaleX = false; // schiebbar
               plotterDisplayEx1.DataSources[j].XAutoScaleOffset = 500; // li + re Rand nur bei AutoScaleX=true
               plotterDisplayEx1.DataSources[j].OnRenderYAxisLabel = RenderYLabel;
               // plotterDisplayEx1.DataSources[0].VisibleDataRange_X = 1000; //??
               for (int i = 0; i < plotterDisplayEx1.DataSources[j].Length; i++) //Data_src.Length; i++)   // Werte vorbelegen
               { // hier eine eine Tag 1440
                  plotterDisplayEx1.DataSources[j].Samples[i].x = i;  // 0...10080 Wert
                  plotterDisplayEx1.DataSources[j].Samples[i].y = (float)(DefaultWert_AnaDaten); // der dazugehörige Y Wert. -10=default 
               }
            }

            // digitalwerte  + Laufzeit und Brennerstarts vorbereiten
            for (int j = (Anzahl_Graph_ana); j < (Anzahl_Graph_ana + Anzahl_Graph_dig + 2); j++)  // digitale Werte
            {
               plotterDisplayEx1.DataSources.Add(new GraphLib.DataSource());
               // X-Achsen beschriftung, entweder Datensatz oder Wochentag + Zeit
               plotterDisplayEx1.DataSources[j].OnRenderXAxisLabel += RenderXLabel;
               plotterDisplayEx1.DataSources[j].Visible_Y_Skala = false;
               // plotterDisplayEx1.DataSources[0].Name = "Grapheeeeee" + (0 + 1);
               plotterDisplayEx1.DataSources[j].Length = iGraphStepsPerHour * ciTwentyfourSeven;  // Speichertiefe, 1Min*60*24*7= Woche
               plotterDisplayEx1.DataSources[j].AutoScaleY = false; // Y-Achse autobereich  
               plotterDisplayEx1.DataSources[j].SetDisplayRangeY(0, 20); // Wertebereich
               plotterDisplayEx1.DataSources[j].SetGridDistanceY(20);
               plotterDisplayEx1.DataSources[j].AutoScaleX = false; // schiebbar
               plotterDisplayEx1.DataSources[j].XAutoScaleOffset = 500; // li + re Rand nur bei AutoScaleX=true
               plotterDisplayEx1.DataSources[j].OnRenderYAxisLabel = RenderYLabel;
               // plotterDisplayEx1.DataSources[0].VisibleDataRange_X = 1000; //??

               for (int i = 0; i < plotterDisplayEx1.DataSources[j].Length; i++) //Data_src.Length; i++)   // Werte in den Puffer eintragen
               {
                  plotterDisplayEx1.DataSources[j].Samples[i].x = i;  // 0...10080 Wert
                  plotterDisplayEx1.DataSources[j].Samples[i].y = (float)(0.0); // der dazugehörige Y Wert. 

               }
            }

                     // Beschriftungen zusammensammeln
            for (int row = 0; row < mydataGridView1.RowCount; row++)
            {
               for (int chan = 0; chan < arrGraphInfo.Length; chan++)
               {
                  //if (arrGraphInfo[chan].active)
                  {
                     if (mydataGridView1["addr", row].Value.ToString().ToUpper() == arrGraphInfo[chan].addr)
                     {
                        arrGraphInfo[chan].label = mydataGridView1["name", row].Value.ToString();
                        //break;
                     }
                  }
               }
            }

            int grch = 0;
            for (int chan = 0; chan < arrGraphInfo.Length; chan++)
            {
               if (arrGraphInfo[chan].active)
               {
                  plotterDisplayEx1.DataSources[grch].Active = true;
                  plotterDisplayEx1.DataSources[grch].GraphColor = arrGraphInfo[chan].color;
                  plotterDisplayEx1.DataSources[grch].Name = arrGraphInfo[chan].label;
                  plotterDisplayEx1.DataSources[grch].OnRenderYAxisLabel = RenderYLabel;
                  grch++;
               }
            }

                     ////     plotterDisplayEx1.DataSources.Add(new GraphLib.DataSource());
            ////     plotterDisplayEx1.DataSources.Add(new GraphLib.DataSource());

            //for (i = 0; i < (Anzahl_Graph_ana + Anzahl_Graph_dig + 2); i++)
            //{
            //   Graph_Daten_eintragen(plotterDisplayEx1.DataSources[i], i, DP_addr_Array[i]);
            //   plotterDisplayEx1.DataSources[i].GraphColor = DP_color_Array[i];
            //   plotterDisplayEx1.DataSources[i].Active = DP_active_Array[i];
            //}

            */
            #endregion old

            PlotGraphs(plotterDisplayEx1, lstGraphInfo);

            plotterDisplayEx1.BackgroundColorTop = Color.Black;
            plotterDisplayEx1.BackgroundColorBot = Color.Black;
            plotterDisplayEx1.SolidGridColor = Color.DarkGray;
            plotterDisplayEx1.DashedGridColor = Color.DarkGray;
            plotterDisplayEx1.DataSources[0].Visible_Y_Skala = true; // eine Skala

            ResumeLayout();
            plotterDisplayEx1.Refresh();
        }

        protected void CalcDataGraphs()
        {
            this.SuspendLayout();

            int Minuten_seit_Montag = Programme.myRoutinen.BerechneMinute(); // Der Graph soll die richtigen Anfang haben
            if (Minuten_seit_Montag < Skala_in_Min) //po temp
            {
                plotterDisplayEx1.SetDisplayRangeX(0, Skala_in_Min); // Bereich am Montag 
            }
            else
            {
                plotterDisplayEx1.SetDisplayRangeX(Minuten_seit_Montag - Skala_in_Min, Minuten_seit_Montag); // von / bis
            }

            //for (int i = 0; i < (Anzahl_Graph_ana + Anzahl_Graph_dig + 2); i++)
            //{
            //   Graph_Daten_eintragen(plotterDisplayEx1.DataSources[i], i, DP_addr_Array[i]);
            //   plotterDisplayEx1.DataSources[i].GraphColor = DP_color_Array[i];
            //   plotterDisplayEx1.DataSources[i].Active = DP_active_Array[i];
            //}
            PlotGraphs(plotterDisplayEx1, lstGraphInfo);

            this.ResumeLayout();
            plotterDisplayEx1.Refresh();
        }

        private String RenderYLabel(GraphLib.DataSource s, float value)
        {
            return String.Format("{0:0.}", value) + " -";
        }

        private String RenderXLabel(GraphLib.DataSource s, int idx)
        {
            int WT = 0;
            if (s.AutoScaleX)
            {
                //if (idx % 2 == 0)
                {
                    int Value = (int)(s.Samples[idx].x);
                    return String.Empty + Value;
                }
                // return String.Empty;
            }
            else
            {
                int Value = (int)(s.Samples[idx].x / 60);
                int Value_rest = (int)(s.Samples[idx].x % 60);

                if (Value >= 24)
                {
                    WT = Value / 24;
                    Value = Value % 24;
                }
                if (Value_rest == 0)
                {
                    String Label = Wochentag[WT % 7] + ":" + Value + ":00 ";
                    WT = 0;
                    Value_old = Value;
                    return Label;
                }
                else
                {
                    String Label = Wochentag[WT % 7] + ":" + Value + ":30 ";
                    WT = 0;
                    Value_old = Value;
                    return Label;
                }
            }
        }
        #endregion garph stuff

        #region fill procs
        private void FillComPortComboBox()
        {
            try
            {
                this.cbxPort.Items.AddRange(SerialPort.GetPortNames());   //Alles Ser. des Rechners sammeln
                this.cbxPort.SelectedItem = this.portName;
                if (this.cbxPort.SelectedItem == null)
                    this.cbxPort.SelectedIndex = 0;  // Der ehem. Port ist nicht mehr da
            }
            catch (Exception ex)
            {
                ShowInfo("Es wurde kein COM-Port gefunden!");
            }
        }

        /* alte COM cbx
        private void FillBaudRateComboBox()
        {
           this.CoBx_BaudRate.Items.AddRange(new object[] { "300", "600", "1200", "2400", "4800", "9600", "14400", "19200", "38400", "57600", "115200", "230400", "460800", "921600" });
           this.CoBx_BaudRate.SelectedItem = this.baudRate.ToString(DateTimeFormatInfo.CurrentInfo);
           //  this.CoBx_BaudRate.SelectedIndex = this.CoBx_BaudRate.Items.IndexOf("9600"); //Voreinstellung
        }

        private void FillDataBitsComboBox()
        {
           this.CoBx_Datenbits.Items.AddRange(new object[] { "5", "6", "7", "8" });
           this.CoBx_Datenbits.SelectedItem = this.dataBits.ToString(DateTimeFormatInfo.CurrentInfo);
           //       this.CoBx_Datenbits.SelectedIndex = this.CoBx_Datenbits.Items.IndexOf("8"); //Voreinstellung
        }

        private void FillParityComboBox()
        {
           this.CoBx_Parity.Items.AddRange(new object[] { Parity.Even.ToString(), Parity.Mark.ToString(), Parity.None.ToString(), Parity.Odd.ToString(), Parity.Space.ToString() });
           this.CoBx_Parity.SelectedItem = this.parity.ToString();
        }

        private void FillStopBitComboBox()
        {
           this.CoBx_Stopbits.Items.AddRange(new object[] { StopBits.None.ToString(), StopBits.One.ToString(), StopBits.OnePointFive.ToString(), StopBits.Two.ToString() });
           this.CoBx_Stopbits.SelectedItem = this.stopBits.ToString();
        }

        private void FillHandshakeComboBox()
        {
           this.CoBx_Handshake.Items.AddRange(new object[] { Handshake.None.ToString(), Handshake.RequestToSend.ToString(), Handshake.RequestToSendXOnXOff.ToString(), Handshake.XOnXOff.ToString() });
           this.CoBx_Handshake.SelectedItem = this.handshake.ToString();
        }
        */

        private void FillTimerComboBox()
        {
            //this.toolStripComboBox1.Items.AddRange(new object[] { "Stop", "20", "30", "40", "50", "60" });
            this.tscbPollInterval.Items.AddRange(new string[] { "0", "10", "20", "30", "40", "50", "60" });
            this.tscbPollInterval.SelectedIndex = this.tscbPollInterval.Items.IndexOf("30"); //Voreinstellung
        }

        private void FillGrafLaengeComboBox()
        {
            this.tscbGraphArea.Items.AddRange(new object[] { "1h", "6h", "12h", "1Tag", "2Tage", "3Tage", "4Tage", "5Tage", "6Tage", "7Tage" });
            //     this.toolStripComboBox2.SelectedIndex = this.toolStripComboBox2.Items.IndexOf("1Tag"); //Voreinstellung
        }

        private void MakeStatGrid()
        {
            //dataSet2.Dispose();
            //dataSet2 = new System.Data.DataSet();
            dataSet2.Clear();

            try
            {
                dataSet2.ReadXml(ds_Datei);
            }
            catch (Exception ex)
            {
                ShowInfo(ds_Dateiname + ": " + ex.Message);
            }

            mydataGridView2.DataSource = dataSet2;
            mydataGridView2.DataMember = "Auswertung";
            mydataGridView2.RowHeadersVisible = false;
            mydataGridView2.AllowUserToAddRows = false;
            mydataGridView2.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft; // Ausrichtung 
            mydataGridView2.Columns["ID"].Visible = false;
            mydataGridView2.Columns["addr"].Visible = false;


            //mydataGridView2.AutoResizeColumn(0);
            //mydataGridView2.AutoResizeColumn(1);
            mydataGridView2.Columns["name"].Width = 150;
            for (int i = 2; i < mydataGridView2.ColumnCount; i++)
            {
                //mydataGridView2.AutoResizeColumn(i);
                mydataGridView2.Columns[i].Width = 75;

            }
            //mydataGridView2.Refresh();

            Berechne_alle_Durchschnittwerte();
        }

        private void Berechne_alle_Durchschnittwerte()
        {
            Berechne_Durchschnittwerte(0, 0, 0);       // durchschnittliche Temperatur
            Berechne_Durchschnittwerte(1, 0, 1000);    // Min Temp
            Berechne_Durchschnittwerte(2, 0, -1000);   // Max Temp
            Berechne_Durchschnittwerte(3, 11, 0);      // Starts
            Berechne_Durchschnittwerte(4, 12, 0);    // Brenner Stunden
            Berechne_Durchschnittwerte(5, 8, 0);    // Verbrauch
        }

        private void Berechne_Durchschnittwerte(int Zeile, int DataSource1, float ZwischenWert_1)
        {
            float DP_Daten = 0;
            float ZwischenWert = 0;
            float MittelWert = 0;
            float MinWert = 100000;
            float MaxWert = -100000;

            double Gasverbrauch = 0;
            //int Minuten_pos = 1440;
            int gueltigeTage = 0;
            int grafchan = 0;
            string yy, zz;

            // find channel with data
            yy = mydataGridView2["addr", Zeile].Value.ToString();

            for (grafchan = 0; grafchan < lstGraphInfo.Count; grafchan++)
            {
                zz = lstGraphInfo[grafchan].addr;
                if (yy == zz)
                    break;
            }

            if (grafchan >= lstGraphInfo.Count)
                return;

            for (int day = 0; day < 7; day++)  //Jeder Tag der Woche
            {
                float max = 0;
                float min = 1000000;
                ZwischenWert = ZwischenWert_1;
                int Anz_DP = 1;
                //for (int DP_Posi = Minuten_pos - 1440; DP_Posi < Minuten_pos; DP_Posi++)
                for (int DP_Posi = day * 1440; DP_Posi < (day + 1) * 1440; DP_Posi++)
                {
                    if (DP_Posi == 160)
                    {; }

                    DP_Daten = plotterDisplayEx1.DataSources[grafchan].Samples[DP_Posi].y;
                    if (DP_Daten != rAnaDefault) // Defaultwert -- dann nicht
                    {
                        switch (Zeile)
                        {
                            case 0:  // durchschnit Temperatur
                                if (DP_Daten == 0) break; // kein Wert in der Tabelle
                                ZwischenWert = ZwischenWert + DP_Daten;
                                Anz_DP++;
                                break;
                            case 1:  // minimale Temperatur
                                if (DP_Daten == 0) break; // kein Wert in der Tabelle
                                if (DP_Daten < ZwischenWert)
                                { ZwischenWert = DP_Daten; }
                                break;
                            case 2:  // maximale Temperatur
                                if (DP_Daten == 0) break; // kein Wert in der Tabelle
                                if (ZwischenWert < DP_Daten)
                                { ZwischenWert = DP_Daten; }
                                break;
                            case 3:   // Schaltanzahl
                                if (DP_Daten == 0) break; // kein Wert in der Tabelle
                                if (DP_Daten < min)     // Min-Wert
                                {
                                    min = DP_Daten;
                                    ZwischenWert = DP_Daten;
                                    break;
                                }

                                if (ZwischenWert <= DP_Daten) // Max-Wert
                                {
                                    max = DP_Daten;
                                    ZwischenWert = DP_Daten;
                                    break;
                                }
                                break;
                            case 4:   // Brennerstunden
                                if (DP_Daten == 0) break;
                                if (DP_Daten < min)    // Min-Wert
                                {
                                    min = DP_Daten;
                                    ZwischenWert = DP_Daten;
                                    break;
                                }

                                if (ZwischenWert <= DP_Daten) // Max-Wert
                                {
                                    max = DP_Daten;
                                    ZwischenWert = DP_Daten;
                                    break;
                                }
                                break;
                            case 5:  // Gasverbrauch
                                if (DP_Daten == 0) break; // kein Wert in der Tabelle
                                Gasverbrauch += DP_Daten / 6000; //Summieren aller Brennerleistungen pro Minute und Prozent
                                break;

                            default: break;
                        } //switch (Zeile)
                    } //if (DP_D..
                } // for (int DP_Posi.. alle 1440 Messwerte
                  // nachdem der Durchlauf für einen Tag beendet ist Ergebnisse auswerten
                switch (Zeile)
                {
                    case 0:  // Durchschnitts-Temperatur
                        if (Anz_DP != 0)  // wenn kein Wert, dann
                        { ZwischenWert = ZwischenWert / Anz_DP; }
                        else
                        { ZwischenWert = 0; }
                        break;

                    case 1:  // minimale Temperatur
                        if (ZwischenWert == 1000)
                        { ZwischenWert = 0; }
                        break;

                    case 2:  // maximale Temperatur

                        if (DP_Daten == 0) break; // kein Wert in der Tabelle
                        if (ZwischenWert < DP_Daten)
                        { ZwischenWert = DP_Daten; }

                        if (ZwischenWert == rAnaDefault)
                        { ZwischenWert = 0; }

                        break;

                    case 3:   // Schaltanzahl
                        ZwischenWert = max - min;
                        if (ZwischenWert == -1000000)
                        { ZwischenWert = 0; }
                        break;

                    case 4:   // Brennerstunden
                        ZwischenWert = max - min;
                        if (ZwischenWert == -1000000)
                        { ZwischenWert = 0; }
                        break;

                    case 5:   // Gasverbrauch
                        Gasverbrauch *= (maxpower / zzahl); // gaswert;
                        ZwischenWert = (float)Gasverbrauch;
                        Gasverbrauch = 0;
                        break;
                    default: break;
                }

                mydataGridView2[day + 2, Zeile].Value = Math.Round(ZwischenWert, 1).ToString();  // Tages-Anzeige
                if (ZwischenWert != 0)
                {
                    MittelWert = MittelWert + ZwischenWert; // für Durchschnittswerte
                    if (ZwischenWert > MaxWert) MaxWert = ZwischenWert;
                    if (ZwischenWert < MinWert) MinWert = ZwischenWert;
                    gueltigeTage++;
                }
            }  //for (int k.. Jeder Tag der Woche

            if ((Zeile == 0) && (gueltigeTage != 0)) { MittelWert = MittelWert / gueltigeTage; } // math Mittel
            if (Zeile == 1) { if (MinWert != 100000) { MittelWert = MinWert; } else { MittelWert = 0; } }// math Min
            if (Zeile == 2) { if (MaxWert != -100000) { MittelWert = MaxWert; } else { MittelWert = 0; } }// math Max
            mydataGridView2[7 + 2, Zeile].Value = Math.Round(MittelWert, 1).ToString();  // Wochen-Anzeige
        }

        private void MakeListe()
        {
            dataSet1.Clear();
            //lese_alle_Datenpunkte = true; // Beim 1. Durchlauf alle lesen

            try
            {
                dataSet1.ReadXml(dp_Datei);
            }
            catch (Exception ex)
            {
                //ShowInfo( "Fehler: Datei " + dp_Dateiname + " nicht vorhanden";
                MessageBox.Show(ex.Message, "read " + dp_Dateiname);
                return;
            }

            //DataColumn dcol = new DataColumn("Nr", Type.GetType("System.Int32"));
            //dataSet1.Tables["datapoint"].Columns.Add(dcol);

            // all upper case
            //for (int i = 0; i < dataSet1.Tables["datapoint"].Rows.Count; i++)
            //   dataSet1.Tables["datapoint"].Rows[i]["addr"] = dataSet1.Tables["datapoint"].Rows[i]["addr"].ToString().ToUpper();
            foreach (DataRow row in dataSet1.Tables["datapoint"].Rows)
                row["addr"] = row["addr"].ToString().ToUpper();

            #region mydataGridView1 aufbauen
            mydataGridView1.DataSource = dataSet1;
            mydataGridView1.DataMember = "datapoint";
            mydataGridView1.DefaultCellStyle.NullValue = String.Empty; //"no entry";
                                                                       //        mydataGridView1.DefaultCellStyle.WrapMode =  DataGridViewTriState.True;

            //      mydataGridView1.Rows[mydataGridView1.RowCount-1].Visible = false;  // letzte blanke Zeile weg
            mydataGridView1.RowHeadersVisible = false;
            mydataGridView1.AllowUserToAddRows = false;
            mydataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft; // Ausrichtung 

            //  Anzeigereihenfolge
            //  Dabei mußt du aber alle Columns durchgehen
            //  mydataGridView1.Columns[0].DisplayIndex;
            //  Sortierung - welche Spalte und absteigend oder aufsteigend
            //DataGridViewColumn col = mydataGridView1.SortedColumn;
            //System.Windows.Forms.SortOrder order = mydataGridView1.SortOrder;

            // alle ausblenden
            foreach (DataGridViewColumn colm in mydataGridView1.Columns)
                colm.Visible = false;

            mydataGridView1.AutoGenerateColumns = false;

            // Checkbox als linke Spalte Position 0
            mydataGridView1.Columns.Remove("enable");
            DataGridViewCheckBoxColumn col_chkbox = new DataGridViewCheckBoxColumn();
            col_chkbox.ThreeState = false;
            col_chkbox.FalseValue = "0";
            col_chkbox.TrueValue = "1";
            col_chkbox.HeaderText = "Akt.";   // Ueberschrift
            col_chkbox.Name = "Akt.";           // Ansprechbarer Name   
            col_chkbox.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            col_chkbox.FlatStyle = FlatStyle.Standard;
            col_chkbox.CellTemplate.Style.BackColor = Color.Beige;
            col_chkbox.DataPropertyName = "enable";   // aus der xml lesen
            mydataGridView1.Columns.Insert(0, col_chkbox);
            mydataGridView1.Columns["Akt."].Width = 5; //Ein
            mydataGridView1.Columns["Akt."].DisplayIndex = 0;
            mydataGridView1.Columns["Akt."].ToolTipText = "Aktualisieren";

            // Checkbox als linke Spalte Position 1
            mydataGridView1.Columns.Remove("speichern");
            DataGridViewCheckBoxColumn col_chkbox1 = new DataGridViewCheckBoxColumn();
            col_chkbox1.ThreeState = false;
            col_chkbox1.FalseValue = "0";
            col_chkbox1.TrueValue = "1";
            col_chkbox1.HeaderText = "Sp.";   // Ueberschrift
            col_chkbox1.Name = "Sp.";           // Ansprechbarer Name   
            col_chkbox1.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            col_chkbox1.FlatStyle = FlatStyle.Standard;
            col_chkbox1.CellTemplate.Style.BackColor = Color.Beige;
            col_chkbox1.DataPropertyName = "speichern";   // aus der xml lesen
            mydataGridView1.Columns.Insert(1, col_chkbox1);
            mydataGridView1.Columns["Sp."].Width = 5; //Ein
            mydataGridView1.Columns["Sp."].DisplayIndex = 1;
            mydataGridView1.Columns["Sp."].ToolTipText = "speichern für Graph-History";


            // 9 = name
            mydataGridView1.Columns["name"].DisplayIndex = 2;
            mydataGridView1.Columns["name"].HeaderText = "Bezeichnung";
            mydataGridView1.Columns["name"].Visible = true;
            mydataGridView1.Columns["name"].Width = 245;

            // 1 = addr
            mydataGridView1.Columns["addr"].DisplayIndex = 3;
            mydataGridView1.Columns["addr"].HeaderText = "Adr.";
            mydataGridView1.Columns["addr"].Visible = true;
            mydataGridView1.Columns["addr"].Width = 40;

            // 11 = Wert_hex Spalte hinzufügen
            DataGridViewColumn col_wert_hex = new DataGridViewTextBoxColumn();
            col_wert_hex.Name = "Wert_Hex";  // Spaltenüberschrift
            mydataGridView1.Columns.Add(col_wert_hex);
            mydataGridView1.Columns["Wert_Hex"].DisplayIndex = 4;
            // mydataGridView1.Columns["Wert_Hex"].DefaultCellStyle.Format = "X04";

            // 12 = Wert_dez Spalte hinzufügen
            DataGridViewColumn col_wert_dez = new DataGridViewTextBoxColumn();
            col_wert_dez.Name = "Wert_Dez";  // Spaltenüberschrift
            mydataGridView1.Columns.Add(col_wert_dez);
            mydataGridView1.Columns["Wert_Dez"].DisplayIndex = 5;
            mydataGridView1.Columns["Wert_Dez"].Visible = false;

            // 13 = Wert_val Spalte hinzufügen
            DataGridViewColumn col_wert_val = new DataGridViewTextBoxColumn();
            col_wert_val.Name = "Wert_Val";  // Spaltenüberschrift
            mydataGridView1.Columns.Add(col_wert_val);
            mydataGridView1.Columns["Wert_Val"].DisplayIndex = 6;

            //14 = Nr = Datpunktanzahl Spalte hinzufügen
            DataGridViewColumn col_Datensatz = new DataGridViewTextBoxColumn();
            col_Datensatz.Name = "Nr";  // Spaltenüberschrift
            mydataGridView1.Columns.Add(col_Datensatz);
            mydataGridView1.Columns["Nr"].DisplayIndex = 8;
            mydataGridView1.Columns["Nr"].Width = 35;
            //// mydataGridView1.Columns["Nr"].HeaderText.Alignment = DataGridViewContentAlignment.MiddleRight;
            ////mydataGridView1.Columns["Nr"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //mydataGridView1.Columns["Nr"].DefaultCellStyle.Format = "000"; // Anzeige 3 stellig

            DataGridViewColumn col_Stringval = new DataGridViewTextBoxColumn();
            col_Stringval.Name = "Wert_String";  // Spaltenüberschrift
            mydataGridView1.Columns.Add(col_Stringval);
            mydataGridView1.Columns["Wert_String"].DisplayIndex = mydataGridView1.Columns.Count - 1;
            mydataGridView1.Columns["Wert_String"].Width = 235;


            int width1 = 35;
            int width2 = 50;
            //int width3 = 65;

            //mydataGridView1.Columns["len"].Visible = false;
            mydataGridView1.Columns["len"].DisplayIndex = 8;
            mydataGridView1.Columns["len"].Width = width1;

            //mydataGridView1.Columns["offset"].Visible = false;
            //mydataGridView1.Columns["offset"].DisplayIndex = 6;
            mydataGridView1.Columns["offset"].Width = width1;

            //mydataGridView1.Columns["precision"].Visible = false;
            //mydataGridView1.Columns["precision"].DisplayIndex = 7;
            mydataGridView1.Columns["precision"].Width = width1;

            //mydataGridView1.Columns["blocklen"].Visible = false;
            //     mydataGridView1.Columns["blocklen"].DisplayIndex = 8;
            mydataGridView1.Columns["blocklen"].Width = width1;

            //mydataGridView1.Columns["unit"].Visible = false;
            mydataGridView1.Columns["unit"].DisplayIndex = 7;
            mydataGridView1.Columns["unit"].Width = width2;

            //mydataGridView1.Columns["description"].Visible = false;
            //     mydataGridView1.Columns["description"].DisplayIndex = 10;

            //mydataGridView1.Columns["ID"].Visible = false;
            //     mydataGridView1.Columns["ID"].DisplayIndex = 11;

            //mydataGridView1.Columns["enable"].Width = width1;
            //mydataGridView1.Columns["enable"].DefaultCellStyle. = new DataGridColumnStyle(PropertyDescriptor
            //mydataGridView1.Columns["speichern"].Width = width1;

            /*            for (int j = 0; j < mydataGridView1.ColumnCount; j++)
                        {
                            mydataGridView1.AutoResizeColumn(j);
                        }

                      //  mydataGridView1.RowHeadersVisible = true; */

            // alle wieder anzeigen
            //for (int j = 0; j < mydataGridView1.ColumnCount; j++)
            //   mydataGridView1.Columns[j].Visible = true;
            foreach (DataGridViewColumn clmn in mydataGridView1.Columns)
            {
                clmn.Visible = true;
                // ACHTUNG! nachträglich hinzugefüget Spalten verlieren Zusammenhang!
                clmn.SortMode = DataGridViewColumnSortMode.NotSortable;
            }

            //for (int i = 1; i < mydataGridView1.Columns.Count; i++)
            //   mydataGridView1.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;


            //  mydataGridView1.RowHeadersVisible = false;

            // funktioniert hier aus unerklärlichem Grund eh nicht
            for (int i = 0; i < mydataGridView1.RowCount; i++)
            {
                mydataGridView1["Nr", i].Value = i;
                //dataSet1.Tables[0].Rows[i].Table.Columns["Nr."].
            }
            #endregion mydataGridView1 aufbauen
        }
        #endregion fill procs

        #region Zeiten Kram
        private ushort iCurrZeitenBaseAddr = 0x2000;
        private ushort iCurrHkOffset = 0;
        private bool fSemaSchreibeZeiten = false;

        private async Task Schreibe_Zeiten(ushort baseaddr)
        {
            ushort[] addrs = { 0x2000, 0x2100, 0x2200, 0x3000, 0x3100, 0x3200, 0x4000, 0x4100, 0x4200 };
            int idx = Array.IndexOf(addrs, baseaddr);
            if (idx < 0)
                return;

            if (fSemaSchreibeZeiten) return;
            fSemaSchreibeZeiten = true;

            this.UseWaitCursor = true;

            for (int day = 0; day < 7; day++)
                await Schreibe_Zeiten_Tag(day, baseaddr);

            while (fSemaBulkRead)
                await WaitAsync(100);

            //await ReadListBulk(true);
            await Lese_Zeiten(baseaddr);

            Fill_Zeiten(baseaddr);

            this.UseWaitCursor = false; ;
            fSemaSchreibeZeiten = false;
        }

        private async Task<bool> Schreibe_Zeiten_Tag(int day, ushort baseaddr)
        {
            byte stunde = 0, minute = 0, value = 0;
            int colm = 0, posdp = -1;
            Byte[] writebuff = new byte[8];
            string errmsg = String.Empty;

            for (colm = 0; colm < 8; colm++)
            {
                string tbtext = lstTbZeiten[(day * 8) + colm].Text.Trim();
                if (tbtext == "n.v.")
                {
                    errmsg = "'n.v.' Fehler";
                    goto doerrmsg;
                }
                else if (tbtext == "--:--")
                {
                    value = 0xff;
                }
                else
                {
                    posdp = tbtext.IndexOf(":");
                    if (posdp < 1)
                    {
                        errmsg = "Zeit hat falsches Format";
                        goto doerrmsg;
                    }

                    string shour = tbtext.Substring(0, posdp);
                    if (!byte.TryParse(shour, out stunde))
                    {
                        errmsg = "Zeit hat falsches Format";
                        goto doerrmsg;
                    }

                    string stenmin = tbtext.Substring(posdp + 1, 1);
                    if (!byte.TryParse(stenmin, out minute))
                    {
                        errmsg = "Zeit hat falsches Format";
                        goto doerrmsg;
                    }

                    stunde = Math.Min(stunde, (byte)24);
                    if (stunde == 24) { minute = 0; }

                    value = (byte)((byte)(stunde << 3) + (byte)(minute & 0x07));
                }

                if ((colm % 2) == 1)  // ungerade 
                {
                    if ((value != 0xFF) && (value <= writebuff[colm - 1]))
                        value = (byte)(writebuff[colm - 1] + 1); // 10 Minuten
                }

                writebuff[colm] = value;
            }

            ushort writeaddr = (ushort)(baseaddr + (day * 8));
            CCommRequReturn rr = await mycomm.WriteDataA(writeaddr, writebuff);

            //ShowInfo("written " + writeaddr.ToString("X4"));

            if (rr.Success)
                // vorher noch Listenwert updaten?!
                return true;
            else
                MessageBox.Show(Wochentag[day] + ":\r\n" + "WriteDataA failed, Addr. " + writeaddr.ToString("X4"), "Schreibe_Zeiten_Tag");

            return false;

            doerrmsg:
            MessageBox.Show(Wochentag[day] + ", Spalte " + (colm + 1).ToString() + ":\r\n" + errmsg, "Schreibe_Zeiten_Tag");
            return false;
        }

        /// <summary>
        /// liest alle Listenreihen mit addr
        /// </summary>
        /// <param name="addr"></param>
        /// <returns></returns>
        private async Task Lese_Zeiten(ushort addr)
        {
            ushort adrlst;
            fSkipBeende = true;

            for (int i = 0; i < mydataGridView1.Rows.Count; i++)
            {
                // einzelner Datensatz bzw alle Tage
                if (ushort.TryParse(mydataGridView1["addr", i].Value.ToString(), NumberStyles.AllowHexSpecifier, null, out adrlst))
                    if (adrlst == addr)
                    {
                        await ReadListDP(i);
                        //ShowInfo("gelesen: " + i.ToString() + addr.ToString("X4"));
                    }
            }

            fSkipBeende = false;
            Beende_Ser_Uebertragung_po();
        }

        private void Fill_Zeiten(ushort addr)
        {
            string bytestrg = String.Empty;

            // merken für update
            //iZeitenTabBaseAddr = Adresse;

            // find row
            int listrow = ListRowIdx(addr);
            if (listrow < 0)
            {
                MessageBox.Show("Datenpunkt nicht in Liste: 0x" + addr.ToString("X4"));
                return;  // not found
            }

            object val = mydataGridView1["Wert_hex", listrow].Value;
            if (val == null)
                return;

            bytestrg = val.ToString(); // ListenWertHex(Adresse);

            if (bytestrg.Length > (3 * 8))
            {
                // all in one line assumed
                for (int day = 0; day < 7; day++)
                {
                    for (int colm = 0; colm < 8; colm++)
                    {
                        int num = colm + (day * 8);
                        //this.tabControl1.Controls.Find("TextBox" + Convert.ToString(100 + num), true)[0].Text = ZeitText(bytestrg, num); //(pos);
                        lstTbZeiten[num].Text = ZeitText(bytestrg, num);
                    }
                }
            }
            else
            {
                // each day in one list line
                // well ordered and all existing assumed!!
                for (int day = 0; day < 7; day++)
                {
                    if (day > 0)  // 0 hatten wir ja oben schon
                    {
                        val = mydataGridView1["Wert_hex", listrow + day].Value;
                        if (val == null)
                            continue;
                        bytestrg = val.ToString(); // ListenWertHex(Adresse + (day * 8));
                    }

                    for (int colm = 0; colm < 8; colm++)
                    {
                        int num = colm + (day * 8);
                        //TextBox tb = (TextBox)tabControl1.Controls.Find("TextBox" + Convert.ToString(100 + num), true)[0];
                        lstTbZeiten[num].Text = ZeitText(bytestrg, colm);
                    }
                }
            }
        }

        private string ZeitText(string bytestrg, int pos)
        {
            string ret = "n.v."; // init return val
            byte zeit = 0xff;

            try
            {
                //bytestrg = mydataGridView1["Wert_hex", listrow].Value.ToString();
                zeit = byte.Parse(bytestrg.Substring(pos * 3, 2), NumberStyles.HexNumber);  // Substring(ab wann,länge)
            }
            catch (Exception)
            {
                return ret;
            }

            if (zeit == 0xff)
            { ret = "--:--"; }
            else
            { ret = (zeit >> 3).ToString("00") + ":" + ((zeit & 0x7) * 10).ToString("00"); }

            return ret;
        }

        private void CopyZeiten(int source, int dest)
        {
            if (source == dest) return;

            for (int i = 0; i < 8; i++)
            {
                lstTbZeiten[dest * 8 + i].Text = lstTbZeiten[source * 8 + i].Text;
            }
        }

        private void MakeZeitenTab()
        {
            int left = GroupBox2200.Left + 6;
            int top = GroupBox2200.Top + 33;

            int rowheight = Label32.Top - Label31.Top;
            int distgrp = GroupBox2202.Left - GroupBox2200.Left;
            int distsml = 59;
            int distlrg = distgrp - distsml;

            //GroupBox2204.Left = GroupBox2202.Left + distgrp;
            //GroupBox2206.Left = GroupBox2204.Left + distgrp;

            int[] arrleft = new int[8];

            for (int i = 0; i < 4; i++)
            {
                arrleft[i * 2] = left + i * distgrp;
                arrleft[i * 2 + 1] = arrleft[i * 2] + distsml;
            }

            lstTbZeiten = new List<TextBox>();

            for (int day = 0; day < 7; day++)
            {
                for (int i = 0; i < 8; i++)
                {
                    TextBox tb = new TextBox();
                    int idx = (day * 8 + i);
                    Point pos = new Point(arrleft[i], top + (day * rowheight));
                    tb.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    tb.Location = pos;  // new System.Drawing.Point(6, 33);
                    tb.Name = "TextBox" + (100 + idx).ToString();
                    tb.Size = new System.Drawing.Size(46, 25);
                    tb.TabIndex = 340 + idx;
                    tb.Text = "n.v."; //+ idx.ToString();
                    tb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;

                    lstTbZeiten.Add(tb);
                    this.tabPage3.Controls.Add(tb);
                    lstTbZeiten[idx].BringToFront();
                }


                // btnCopyZeiten
                Button btn = new Button();

                btn.Location = new System.Drawing.Point(GroupBox2206.Right + 15, 49 + (day * rowheight));
                btn.Name = "btnCopyZeiten" + day.ToString();
                btn.Size = new System.Drawing.Size(80, 23);
                btn.TabIndex = 320 + day;
                btn.Text = "Übertragen...";
                btn.Tag = day;
                btn.UseVisualStyleBackColor = true;
                btn.Click += new System.EventHandler(btnCopyZeiten_Click);

                lstBtnCopy.Add(btn);
                this.tabPage3.Controls.Add(btn);


                // btnWriteDay
                btn = new Button();

                btn.Location = new System.Drawing.Point(lstBtnCopy[0].Right + 15, 49 + (day * rowheight));
                btn.Name = "btnWriteDay" + day.ToString();
                btn.Size = new System.Drawing.Size(80, 23);
                btn.TabIndex = 330 + day;
                btn.Text = "Schreibe Tag";
                btn.Tag = day;
                btn.UseVisualStyleBackColor = true;
                btn.Click += new System.EventHandler(btnWriteDay_Click);

                lstBtnWriteDay.Add(btn);
                this.tabPage3.Controls.Add(btn);
            }

        }

        #endregion Zeiten Kram

        #region Phil's Karm
        private string uiDecSep = CultureInfo.CurrentUICulture.NumberFormat.NumberDecimalSeparator;

        private string CorrectedDecSep(string value)
        {
            string ret = value;

            if (uiDecSep == ".")
                ret = value.Replace(",", uiDecSep);
            else
                ret = value.Replace(".", uiDecSep);

            return ret;
        }

        public static async Task WaitAsync(int milliseconds)
        {
            if (milliseconds > 0)
            {
                try
                {
                    await Task.Delay(milliseconds, ctsWait.Token);
                }
                catch (TaskCanceledException) { }
                catch (Exception) { }
            }
        }

        #region cancel
        private static CancellationTokenSource ctsWait = new CancellationTokenSource();
        public static bool fCancel = false;

        private void Cancel()
        {
            tmrPoll.Stop();
            fCancelBulk = true;
            fCancel = true;
            ctsWait.Cancel();
        }
        #endregion cancel

        #region bulk read stuff
        private bool fSkipBeende = false; // !! danach Beende_Ser_Uebertragung_po()
        private bool fSemaBulkRead = false;
        private bool fCancelBulk = false;

        private async Task ReadListBulk(bool readall)
        {
            if (fSemaBulkRead)
            {
                Console.Beep();
                return;
            }
            fSemaBulkRead = true;

            fCancelBulk = false;
            await ReadListDPs(readall, -1);

            fSemaBulkRead = false;
        }

        /// <summary>
        /// reads a single DP
        /// </summary>
        /// <param name="row">list index</param>
        private async Task ReadListDP(int row)
        {
            if (row < 0)
                return;

            await ReadListDPs(true, row);
        }

        /// <summary>
        /// reads list DPs
        /// </summary>
        /// <param name="readall">all DPs, if false: only 'Akt.' selected</param>
        /// <param name="rowidx">if >= 0 only the one DP be read</param>
        private async Task ReadListDPs(bool readall, int rowidx)
        {
            if (fCancel || mycomm.fCancel || !mycomm.PortIsOpen())
            {
                Console.Beep();
                return;
            }

            ushort addr, readaddr, offset;  // offset dezimal!!
            byte len, blklen, readlen, bytesread;
            byte[] recdata;
            double r;
            Int64 ival;
            string s, sval, fmt;
            int numread = 0;
            bool signed = false;
            CCommRequReturn rr; // = new CReadReturn();

            bool singlerow = (rowidx >= 0);
            int stoprow = mydataGridView1.RowCount;

            if (rowidx >= stoprow)
                return;

            if (singlerow)
                stoprow = rowidx + 1;
            else
                rowidx = 0;

            // erstmal...
            tmrPoll.Stop();
            tslblLed.BackColor = Color.LightGreen;

            //try
            //{
            for (int row = rowidx; row < stoprow; row++)
            {
                //mycomm.DoLog("row " + row.ToString());
                len = blklen = readlen = bytesread = 0;
                //readaddr = 0;

                #region get values
                if (fCancelBulk)
                    goto doexit;

                if (!readall && (mydataGridView1["Akt.", row].Value.ToString() == "0"))
                    continue; // next row

                if (!byte.TryParse(mydataGridView1["len", row].Value.ToString(), out len))
                    continue;

                if (len < 1)
                    continue;

                if (!ushort.TryParse(mydataGridView1["addr", row].Value.ToString(), NumberStyles.AllowHexSpecifier, null, out addr))
                    continue;

                if (!ushort.TryParse(mydataGridView1["offset", row].Value.ToString(), out offset))  // dezimal!!
                    offset = 0;

                if (!byte.TryParse(mydataGridView1["blocklen", row].Value.ToString(), out blklen))
                    blklen = 0;
                #endregion get values

                // prepare
                recdata = new byte[len];
                addr += offset;

                // now do read
                tstbReadRow.Text = row.ToString();

                doreadblock:
                if (blklen > 0)
                {
                    readlen = blklen;
                    readaddr = (ushort)(addr + bytesread);
                }
                else
                {
                    readlen = len;
                    readaddr = addr;
                }

                // now really do read
                rr = await mycomm.ReadDataA(readaddr, readlen);

                //mycomm.DoLog(addr.ToString("X4") + " read succ " + rr.Success.ToString());

                if (rr.Success)
                {
                    // enable Bulk for next read
                    mycomm.fKWBulk = true;

                    for (int i = 0; i < readlen; i++)
                        recdata[i + bytesread] = rr.Data[i];

                    bytesread += readlen;

                    int remain = len - bytesread;
                    if (blklen > (byte)remain)
                        blklen = (byte)remain;

                    if (blklen > 0)
                        goto doreadblock;


                    #region update list
                    // Wert_Hex
                    s = String.Empty;
                    for (int j = 0; j < recdata.Length; j++)
                        s += (recdata[j].ToString("X2")) + csBlank;

                    mydataGridView1["Wert_Hex", row].Value = s;

                    // Wert_Dez
                    s = String.Empty;
                    for (int j = 0; j < recdata.Length; j++)
                        s += (recdata[j].ToString("000")) + csBlank;

                    mydataGridView1["Wert_Dez", row].Value = s;

                    // Wert_Val
                    s = sval = String.Empty;
                    switch (addr)
                    {
                        case 0x088E:
                            // Datum und Uhrzeit formatieren
                            s = Wochentag[(recdata[4] + 6) % 7] + csBlank;
                            s += recdata[3].ToString("X2") + "." + recdata[2].ToString("X2") + "."; // Tag.Monat.
                            s += recdata[0].ToString("X2") + recdata[1].ToString("X2") + csBlank;   // Jahr
                            s += recdata[5].ToString("X2") + ":" + recdata[6].ToString("X2") + ":" + recdata[7].ToString("X2"); // h:m:s

                            sval = s;
                            break;

                        #region old
                        //case 0x0800:
                        //case 0x5523:
                        //case 0x5525:
                        //case 0x5527:
                        //   // Temperaturen, ggf neg, 2 Bytes
                        //   val = recdata[0] + (recdata[1] << 8);
                        //   val = (short)val;

                        //   s = CorrectedDecSep(mydataGridView1["precision", row].Value.ToString());
                        //   r = float.Parse(s);
                        //   fmt = GetFormat(r);
                        //   r *= val;

                        //   sval = r.ToString(fmt);
                        //   break;

                        //case 0x27D3:
                        //   // Neigung, 1 Byte, ggf 1 dec
                        //   val = recdata[0];

                        //   s = CorrectedDecSep(mydataGridView1["precision", row].Value.ToString());
                        //   r = float.Parse(s);
                        //   fmt = GetFormat(r);
                        //   r *= val;

                        //   sval = r.ToString(fmt);
                        //   break;

                        //case 0x27D4:
                        //   // Nniveau, ggf neg, 1 Byte
                        //   val = recdata[0];
                        //   val = (sbyte)val;

                        //   sval = val.ToString();
                        //   break;

                        //case 0x08A7:
                        //   // Brennerstungen xml Prec "3600"
                        //   val = 0;
                        //   for (int i = 0; i < recdata.Length; i++)
                        //      val += (recdata[i] << (i * 8));

                        //   r = (float)val;
                        //   r /= 3600;
                        //   sval = r.ToString("0.0");
                        //   break;
                        #endregion old

                        default:
                            s = CorrectedDecSep(mydataGridView1["precision", row].Value.ToString());
                            r = 1;
                            double.TryParse(s, out r);

                            signed = (r < 0);
                            r = Math.Abs(r);
                            fmt = GetFormat(r);
                            //len = (byte)recdata.Length;  // s.o.

                            if (len < 8)
                            {
                                // geht immer mit Int64
                                ival = 0;
                                for (int i = 0; i < len; i++)
                                    ival += ((Int64)recdata[i] << (i * 8));

                                if (signed)
                                    if ((recdata[len - 1] & 0x80) > 0)
                                        ival -= ((Int64)1 << (len * 8));

                                if (len < 7)
                                {
                                    // double only 15 digits granted
                                    r *= ival;
                                    sval = r.ToString(fmt);
                                }
                                else if (r == 1d)
                                {
                                    // 7 bytes
                                    sval = ival.ToString();
                                }
                                else
                                    sval = "<too large>";
                            }
                            else if ((len == 8) & (r == 1d))
                            {
                                if (signed)
                                    sval = (BitConverter.ToInt64(recdata, 0)).ToString(fmt);
                                else
                                    sval = (BitConverter.ToUInt64(recdata, 0)).ToString(fmt);
                            }
                            else
                                sval = "<too large>";

                            break;
                    }

                    mydataGridView1["Wert_Val", row].Value = sval;

                    // wert_string
                    int utf16 = 0;
                    //try
                    //{
                    s = String.Empty;
                    for (int i = 0; i < recdata.Length - 1; i += 2)
                    {
                        utf16 = recdata[i] + (recdata[i + 1] << 8);
                        utf16 &= 0xFFFF;

                        if (!((utf16 <= 0x001F)
                           | ((0x007F <= utf16) & (utf16 <= 0x009F))
                           | ((0xD800 <= utf16) & (utf16 <= 0xDFFF))))  // no ctrl etc
                            s += char.ConvertFromUtf32(utf16);
                        else
                            s += (char)(0xBF);
                    }
                    mydataGridView1["Wert_String", row].Value = s;
                    //}
                    //catch (Exception ex)
                    //{
                    //   MessageBox.Show(utf16.ToString("X4") + csCrLf + ex.Message + csCrLf + ex.StackTrace.ToString());
                    //}
                    #endregion update list

                    UpdateScreen(row);

                    // update toolstrip
                    numread++;
                    tstbNumRead.Text = numread.ToString();
                }
                else
                    mydataGridView1["Wert_Hex", row].Value = mydataGridView1["Wert_Dez", row].Value = mydataGridView1["Wert_Val", row].Value = mydataGridView1["Wert_String", row].Value = "<Error>";

                // etwas warten... schon in LineGotFree()
                //await WaitAsync(50);
            }
            //mycomm.DoLog("loop done");

            // und noch (übernommen)...

            if (!fSkipBeende)
                // csv schreiben, Graph update und so
                Beende_Ser_Uebertragung_po();

            //}
            //catch (Exception ex)
            //{
            //   string msg = ex.Message + csCrLf;
            //   msg += ex.Source + csCrLf;
            //   msg += ex.StackTrace;
            //   MessageBox.Show(msg);
            //   this.toolStripLabel2.BackColor = Color.Red;
            //}

            if (iPollDelay > 0)
            {
                tmrPoll.Interval = iPollDelay;
                tmrPoll.Start();
            }

            doexit:
            mycomm.fKWBulk = false;
            //return;
        }
        #endregion bulk read stuff

        private async Task WriteListDp()
        {
            ushort addr, offset;
            byte len;
            byte[] data;
            string msg, err = "Fehler Write DP";
            int row = mydataGridView1.CurrentCell.RowIndex;

            if (!byte.TryParse(mydataGridView1["len", row].Value.ToString(), out len))
            {
                msg = "Converting Data Lenght failed.";
                MessageBox.Show(msg, err);
                return;
            }

            if (len < 1)
            {
                msg = "Data Lenght < 1 - nothing to write.";
                MessageBox.Show(msg, err);
                return;
            }

            if (!ushort.TryParse(mydataGridView1["addr", row].Value.ToString(), NumberStyles.AllowHexSpecifier, null, out addr))
            {
                msg = "Converting Address failed.";
                MessageBox.Show(msg, err);
                return;
            }

            if (!ushort.TryParse(mydataGridView1["offset", row].Value.ToString(), out offset))
                offset = 0;

            addr += offset;

            string val = string.Empty;
            msg = "ACHTUNG! Die Write-Funktion nur benutzen, wenn du wirklich weisst, was du tust!!" + csCrLf;
            msg += "Hier muss der zu schreibende Raw-Wert (dezimale Ganzzahl) eingegeben werden!";
            DialogResult res = ShowInputDialog(ref val, msg, "WARNUNG! - Write 0x" + addr.ToString("X4"), 350);

            if (res != DialogResult.OK)
                return;

            val = val.Trim();
            if (val.Length < 1)
                return;

            if (val.Substring(0, 1) == "-")
            {
                Int64 ival;
                if (!Int64.TryParse(val, out ival))
                    goto convfailed;

                data = BitConverter.GetBytes(ival);
            }
            else
            {
                UInt64 ival;
                if (!UInt64.TryParse(val, out ival))
                    goto convfailed;

                data = BitConverter.GetBytes(ival);
            }

            ClearRowVals(row);

            byte[] wrdata = new byte[len];

            Array.Copy(data, wrdata, len);

            tslblLed.BackColor = Color.LightGreen;

            CCommRequReturn rr = await mycomm.WriteDataA(addr, wrdata);

            tslblLed.BackColor = Color.Red;

            msg = "Writing 0x" + addr.ToString("X4");
            if (rr.Success)
                msg += " - Success";
            else
                msg += " - Failed";

            MessageBox.Show(msg, "Write DP");

            return;
            convfailed:
            msg = "Converting Value failed.";
            MessageBox.Show(msg, err);
        }

        private async Task LoadWW()
        {
            if (!await mycomm.Write1ByteValueA(0x65F5, 1))
                return;

            await WaitAsync(1000);

            await mycomm.Write1ByteValueA(0x65F5, 0);
        }

        public string GetFormat(double precision)
        {
            return "0.###";

            precision *= 1.01d; // to be safe - float...

            if (precision > 1)
                return "0";

            for (int i = 1; i < 10; i++)
            {
                if (precision > Math.Pow(10, -i))
                    return "0." + new string('0', i);
            }

            return String.Empty;
        }

        private void ClearRowVals(int row)
        {
            mydataGridView1["Wert_Hex", row].Value = String.Empty; // null;
            mydataGridView1["Wert_Val", row].Value = String.Empty; // null;
            mydataGridView1["Wert_Dez", row].Value = String.Empty; //  null;
        }

        private bool fSemaStartStop = false;
        private async Task StartStopPressed()
        {
            if (fSemaStartStop)
            {
                Console.Beep();
                return;
            }
            fSemaStartStop = true;

            if (chkTcpEnable.Checked)
            {
                #region tcpip
                if (mycomm.PortIsOpen())
                {
                    // stop comm ++++++++++++
                    tmrPoll.Stop();
                    fCancel = true;

                    mycomm.DisconnectTcp();
                    ShowConnected(false);
                }
                else
                {
                    bool succ = false;
                    try
                    {
                        succ = mycomm.ConnectTcp(tbTcpIpAddr.Text, int.Parse(tbTcpPort.Text));
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "ConnectTcp");
                    }

                    if (succ)
                    {
                        succ = false;
                        for (int i = 0; i < 10; i++)
                        {
                            await WaitAsync(500);
                            if (mycomm.PortIsOpen())
                            {
                                succ = true;
                                break;
                            }
                        }
                        if (succ)
                        {
                            // VS2 protocol expected/assumed!
                            await ReadDeviceIdent();
                            ShowConnected(true);
                            await ReadListBulk(true);  // startet den t1 wenn fertig und macht grün
                        }
                        else
                        {
                            mycomm.DisconnectTcp();
                            MessageBox.Show("Failed to connect TCP client");
                            fSemaStartStop = false;
                            return;
                        }
                    }
                }
                #endregion tcpip
            }
            else
            {
                #region com
                if (!mycomm.PortIsOpen())
                {
                    // start comm ++++++++

                    tslblLed.BackColor = Color.Yellow;
                    this.Text = Appname + ", connecting ...";

                    if (!mycomm.OpenPort(cbxPort.Text))  // portName
                    {
                        MessageBox.Show("Error opening " + cbxPort.Text);
                        //toolStripLabel2.BackColor = Color.Red;
                        //this.Text = Appname;
                        goto docloseport;
                    }

                    // check 300 protocol by init'ing 
                    if (!await mycomm.Init300ProtocolA())
                    {
                        // if no success, try KW protocol
                        if (!await mycomm.DoSyncV1())
                        {
                            // if fails no comm...
                            //toolStripLabel2.BackColor = Color.Red;
                            string msg = "Weder VS2/300 noch VS1/KW Protokoll gefunden." + csCrLf + "GWG Geräte (noch) nicht unterstützt.";
                            MessageBox.Show(msg, "Pech :-(");
                            goto docloseport; // doexit;
                        }
                    }

                    await ReadDeviceIdent();
                    ShowConnected(true);
                    await ReadListBulk(true);  // startet den t1 wenn fertig und macht grün
                }
                else
                {
                    // stop comm ++++++++++++
                    tmrPoll.Stop();

                    // ggf Bulk abbrechen
                    fCancelBulk = true;
                    // comm Kram abbrechen
                    mycomm.Cancel();

                    // warten bis communikationen beendet/abgebrochen
                    //do
                    await WaitAsync(100);
                    //while (!fBulkRead);

                    // Comm wieder erlauben
                    mycomm.UnCancel();

                    //// re-init KW Protokoll - kann glaubich auch bei KW nicht schaden
                    // passiert schon in mycomm.ClosePort()
                    //mycomm.SendBytes(new byte[1] { mycomm.EOT });

                    goto docloseport;
                }
                #endregion com
            }

            doexit:
            fSemaStartStop = false;

            return;
            docloseport:
            mycomm.ClosePort();
            ShowConnected(false);
            goto doexit;
        }

        private async Task ReadDeviceIdent()
        {
            if (!fDeviceReadDone)
            {
                CHeatingDevice hd = new CHeatingDevice();

                if (hd.ReadCsv(Path.Combine(Applikation_Pfad, "Devices.csv")))
                {
                    CCommRequReturn rr = await mycomm.ReadDataA(0xF8, 4);
                    if (rr.Success)
                    {
                        byte[] sysid = rr.Data;
                        byte idf0 = 0;

                        rr = await mycomm.ReadDataA(0xF0, 1);
                        if (rr.Success)
                            idf0 = rr.Data[0];

                        hd.GetDevice(sysid, idf0, out currDevice);
                    }
                }

                fDeviceReadDone = true;
            }
        }

        private void ShowConnected(bool on)
        {
            if (on)
            {
                fCancel = false;
                grpComSettings.Enabled = false;
                grpTcpIp.Enabled = false;

                this.Text = Appname + ", verbunden, Protokoll: " + mycomm.Protocol.ToString() + ", Gerät: " + currDevice.Description;

                tscbPollInterval.Text = (iPollDelay / 1000).ToString();
                tsbtnStartStop.Image = Properties.Resources.Player_Stop;

                btnFlushCsv.Enabled = chkTcpEnable.Checked;
            }
            else
            {
                tmrPoll.Stop(); // sicherheitshalber nochmal
                fCancel = true;

                grpComSettings.Enabled = true;
                grpTcpIp.Enabled = true;

                this.Text = Appname;

                tslblLed.BackColor = Color.Red;
                tscbPollInterval.Text = "Stop";
                tsbtnStartStop.Image = Properties.Resources.Player_Play;  // Bildchen umschalten

                btnFlushCsv.Enabled = false;
            }
        }

        /// <summary>
        /// replaces the original send_parameter. wirtes 1 byte value
        /// </summary>
        /// <param name="addr">DP adress</param>
        /// <param name="val">value to be written to the DP</param>
        /// <returns></returns>
        private async Task send_parameter(ushort addr, byte val)
        {
            string msg = "writing 0x" + addr.ToString("X4") + " to " + val.ToString();

            if (await mycomm.Write1ByteValueA(addr, val))
                msg += " - success.";
            else
                msg += " - failed!";

            MessageBox.Show(msg, "Write DP");
        }

        private string ListenWertHex(ushort addr)
        {
            string ret = string.Empty;

            // Reihe finden
            int listrow = ListRowIdx(addr);
            if (listrow < 0)
                return ret; // not found

            try
            {
                ret = mydataGridView1["Wert_hex", listrow].Value.ToString();
            }
            catch (Exception) { }

            return ret;
        }

        private int ListRowIdx(ushort addr)
        {
            int listrow = -1;
            ushort adrlst;

            // Reihe finden
            for (listrow = 0; listrow < mydataGridView1.Rows.Count; listrow++)
            {
                if (ushort.TryParse(mydataGridView1["addr", listrow].Value.ToString(), NumberStyles.AllowHexSpecifier, null, out adrlst))
                    if (adrlst == addr)
                        break;
            }

            if (listrow == mydataGridView1.Rows.Count)
                listrow = -1;

            return listrow;
        }

        private void InitPathsAndFiles()  //po
        {
            Applikation_Pfad = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);

            cfg_Datei = Path.Combine(Applikation_Pfad, cfg_DateiName);
            dp_Datei = Path.Combine(Applikation_Pfad, dp_Dateiname);
            ds_Datei = Path.Combine(Applikation_Pfad, ds_Dateiname);
        }

        public static DialogResult ShowInputDialog(ref string input, string message, string caption, int width)
        {
            int boxesleft = 5;

            //System.Drawing.Size size = new System.Drawing.Size(width, 70);
            Form inputBox = new Form();

            inputBox.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            //inputBox.ClientSize = size;
            inputBox.Text = caption;
            inputBox.MaximizeBox = false;
            inputBox.MinimizeBox = false;
            inputBox.ControlBox = false;
            inputBox.StartPosition = FormStartPosition.CenterParent;

            // 
            // label1
            // 
            System.Windows.Forms.Label label1 = new Label();
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label1.Location = new System.Drawing.Point(boxesleft, 10);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(width - 10, 70);
            label1.TabIndex = 0;
            label1.Text = message;
            inputBox.Controls.Add(label1);

            System.Windows.Forms.TextBox textBox = new TextBox();
            label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            textBox.Size = new System.Drawing.Size(width - 10, 25);
            textBox.Location = new System.Drawing.Point(boxesleft, label1.Top + label1.Height + 5);
            textBox.Text = input;
            textBox.TextAlign = HorizontalAlignment.Right;
            inputBox.Controls.Add(textBox);

            int btntop = textBox.Top + textBox.Height + 5;

            Button okButton = new Button();
            okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            okButton.Name = "okButton";
            okButton.Size = new System.Drawing.Size(75, 25);
            okButton.Text = "&OK";
            okButton.Location = new System.Drawing.Point(width - 80 - 80, btntop);
            inputBox.Controls.Add(okButton);

            Button cancelButton = new Button();
            cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            cancelButton.Name = "cancelButton";
            cancelButton.Size = new System.Drawing.Size(75, 25);
            cancelButton.Text = "&Cancel";
            cancelButton.Location = new System.Drawing.Point(width - 80, btntop);
            inputBox.Controls.Add(cancelButton);

            inputBox.AcceptButton = okButton;
            inputBox.CancelButton = cancelButton;

            System.Drawing.Size size = new System.Drawing.Size(width, btntop + okButton.Height + 5);
            inputBox.ClientSize = size;

            DialogResult result = inputBox.ShowDialog();
            input = textBox.Text;
            return result;
        }
        #endregion Phil's Karm

        #region dynamische Zuordnung 
        private bool FindTextbox(ushort addr, out TextBox tb)
        {
            ushort ctladdr;

            for (int i = 0; i < this.tabPage1.Controls.Count; i++)
            {
                Control ctl = this.tabPage1.Controls[i];
                if (ctl is TextBox)
                    if ((ctl.Tag != null) && (ushort.TryParse(ctl.Tag.ToString(), NumberStyles.HexNumber, null, out ctladdr)))
                        if (addr == ctladdr)
                        {
                            tb = (TextBox)ctl;
                            return true;
                        }
            }

            tb = null;
            return false;
        }

        private void Test()
        {
            TextBox mytb;
            if (FindTextbox(0x0800, out mytb))
                mytb.Text = "123";
        }

        #endregion dynamische Zuordnung 

        #region TcpIp
        private bool fTcpIp = false;

        private void SwitchTcp(bool enable)
        {
            fTcpIp = enable;

            if (fTcpIp)
            {

                //mycomm.ClosePort();
                ////chkProtocol.Checked = true;
                ////mycomm.Protocol = PROTOCOL.VS2_300;

                //bool ret = mycomm.ConnectTcp(tbIP.Text, int.Parse(tbPort.Text));
                //ShowInfo("TCP connected: " + ret.ToString());

            }

        }

        #endregion TcpIp

        #region control events
        #region MainForm Event-Handler
        private void tabControl1_SelectedIndexChanged(Object sender, System.EventArgs e)
        {
            //bool done = false;
            switch (tabControl1.SelectedIndex)
            {
                case 0:// wozu das hier gut ist habe ich keine Ahnung
                       //int i = 3;
                       //i++;
                    break;
                case 1:
                    //int j = 3;
                    //j++;
                    //if (!done)
                    //{
                    //   for (int i = 0; i < mydataGridView1.RowCount; i++)
                    //      mydataGridView1["Nr", i].Value = i;
                    //   done = true;
                    //}
                    break;
                case 2:  //zeiten
                         //int k = 3;
                         //k++;
                    if (rbnZirkuZeiten.Checked) Fill_Zeiten(0x2200); // { radioButton1.Checked = false; radioButton1.Checked = true; }
                    else if (rbnWwZeiten.Checked) Fill_Zeiten(0x2100); // { radioButton2.Checked = false; radioButton2.Checked = true; }
                    else { rbnHeizZeiten.Checked = false; rbnHeizZeiten.Checked = true; }
                    break;
                case 3:   // Grafik
                          //int l = 3;   // müssen noch die Zeiten eingetragen werden hier 
                          //l++;
                    break;
                case 4:   // Statistik
                          //MakeStatGrid();
                    Berechne_alle_Durchschnittwerte();
                    break;
                default:
                    break;
            }
        }

        private void tscbPollInterval_SelectedIndexChanged(object sender, EventArgs e)
        {
            int tm;
            if (int.TryParse(tscbPollInterval.Text, out tm))
                iPollDelay = tm * 1000;

            //return; //po

            //switch (toolStripComboBox1.SelectedItem.ToString())
            //{
            //   case "Stop":
            //      tsbtnStartStop.Image = Properties.Resources.Player_Play;  // Bildchen umschalten
            //      toolStripButton2_pressed = false;
            //      t2.Stop();
            //      TimerAbfrage = 0;

            //      return;

            //   case "20 Sek":

            //      t2.Interval = 20000; //20s
            //      pollinterval = 20000;
            //      TimerAbfrage = 1;
            //      break;

            //   case "30 Sek":

            //      t2.Interval = 30000; //30s
            //      pollinterval = 30000;
            //      TimerAbfrage = 1;
            //      break;

            //   case "40 Sek":

            //      t2.Interval = 40000; //40s
            //      pollinterval = 40000;
            //      TimerAbfrage = 1;
            //      break;

            //   case "50 Sek":

            //      t2.Interval = 50000; //50s
            //      pollinterval = 50000;
            //      TimerAbfrage = 1;
            //      break;

            //   default:
            //      break;
            //}

        }

        private void tscbPollInterval_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            int value;
            if (!int.TryParse(tscbPollInterval.Text, out value))
                return;

            iPollDelay = value * 1000;
        }

        private void tscbGraphArea_SelectedIndexChanged(object sender, EventArgs e)
        {
            float stepwidth = iGraphStepsPerHour / 60f;

            switch (tscbGraphArea.SelectedItem.ToString())
            {
                case "1h":
                    Skala_in_Min = 60; // iGraphStepsPerHour;  // 60
                    RangeX = 30;  // Minutenabstand zwischen 2 senkr. Strichen
                    break;

                case "6h":
                    Skala_in_Min = 360;
                    RangeX = 30;  // Minutenabstand zwischen 2 senkr. Strichen
                    break;

                case "12h":
                    Skala_in_Min = 720;
                    RangeX = 60;   // (1h) Minutenabstand zwischen 2 senkr. Strichen
                    break;

                case "1Tag":
                    Skala_in_Min = 1440;
                    RangeX = 120;  // (2h) Minutenabstand zwischen 2 senkr. Strichen
                    break;

                case "2Tage":
                    Skala_in_Min = 2880;
                    RangeX = 360;   // (6h) Minutenabstand zwischen 2 senkr. Strichen
                    break;

                case "3Tage":
                    Skala_in_Min = 4320;
                    RangeX = 720;   // (6h) Minutenabstand zwischen 2 senkr. Strichen
                    break;

                case "4Tage":
                    Skala_in_Min = 5760;
                    RangeX = 720;   // (6h) Minutenabstand zwischen 2 senkr. Strichen
                    break;

                case "5Tage":
                    Skala_in_Min = 7200;
                    RangeX = 720;   // (6h) Minutenabstand zwischen 2 senkr. Strichen
                    break;

                case "6Tage":
                    Skala_in_Min = 8640;
                    RangeX = 720;   // (6h) Minutenabstand zwischen 2 senkr. Strichen
                    break;

                case "7Tage":
                    Skala_in_Min = iGraphStepsPerHour * 24 * 7; // 10080;
                    RangeX = 1440 * iGraphStepsPerHour / 60;   // (6h) Minutenabstand zwischen 2 senkr. Strichen
                    break;

                default:
                    break;
            }

            plotterDisplayEx1.Skala_in_Min = Skala_in_Min;
            InitGraphs();
            plotterDisplayEx1.Refresh();
        }

        private void tsbtnSaveAll_Click(object sender, EventArgs e)
        {
            try
            {
                dataSet1.WriteXml(dp_Datei);
                dataSet1.Clear();
                dataSet1.ReadXml(dp_Datei);
            }
            catch (Exception ex)
            {
                //ShowInfo( "Fehler: Datei " + dp_Dateiname + " nicht vorhanden";
                MessageBox.Show(ex.Message, "write/read " + dp_Dateiname);
                return;
            }

            try
            {
                // Speicherung der Grapheneinstellung
                XmlDocument ser_config1 = new XmlDocument();
                ser_config1.Load(cfg_Datei);
                XmlNodeList Graphen_Liste = ser_config1.GetElementsByTagName("Graph");
                XmlNode xmlNode1 = Graphen_Liste[0].SelectSingleNode("color");
                for (int i = 0; i < lstGraphInfo.Count; i++)   // (Anzahl_Graph_ana + Anzahl_Graph_dig + 2); i++)
                {
                    if (lstGraphInfo[i].hidden) continue;
                    lstGraphInfo[i].color = plotterDisplayEx1.DataSources[i].GraphColor;
                    XmlNode xmlNode2 = Graphen_Liste[i].SelectSingleNode("color");
                    xmlNode2.InnerText = "#" + lstGraphInfo[i].color.ToArgb().ToString("X4");

                    lstGraphInfo[i].active = plotterDisplayEx1.DataSources[i].Active;
                    XmlNode xmlNode3 = Graphen_Liste[i].SelectSingleNode("active");
                    xmlNode3.InnerText = lstGraphInfo[i].active.ToString();
                }

                ser_config1.Save(cfg_Datei);


                // hier werden sie Parameter der Ser.SS gespeichert
                XmlDocument ser_config = new XmlDocument();
                ser_config.Load(cfg_Datei);
                XmlNodeList ser_Liste = ser_config.GetElementsByTagName("Port");

                foreach (XmlNode node in ser_Liste) // ist eh nur einer drin
                {
                    int z = 0;
                    if (node != null) //kein node in Datei
                    {
                        XmlAttribute xmlAttr1 = ser_Liste[z].Attributes["name"];
                        xmlAttr1.InnerText = this.portName;

                        //XmlNode xmlNode4 = ser_Liste[z].SelectSingleNode("BaudRate");
                        //xmlNode4.InnerText = this.baudRate.ToString();

                        //xmlNode4 = ser_Liste[z].SelectSingleNode("Parity");
                        //xmlNode4.InnerText = this.parity.ToString();

                        //xmlNode4 = ser_Liste[z].SelectSingleNode("DataBits");
                        //xmlNode4.InnerText = this.dataBits.ToString();

                        //xmlNode4 = ser_Liste[z].SelectSingleNode("StopBits");
                        //xmlNode4.InnerText = this.stopBits.ToString();

                        //xmlNode4 = ser_Liste[z].SelectSingleNode("Handshake");
                        //xmlNode4.InnerText = this.handshake.ToString();

                        z++;
                    }
                }

                ser_config.Save(cfg_Datei);

                save_tcp(chkTcpEnable.Checked, tbTcpIpAddr.Text, int.Parse(tbTcpPort.Text));
            }
            catch (Exception ex)
            {
                //ShowInfo( "Fehler: Datei " + dp_Dateiname + " nicht vorhanden";
                MessageBox.Show(ex.Message, "update " + cfg_DateiName);
                return;
            }

            save_maxpower();
        }

        private void tsbtnCancel_Click(object sender, EventArgs e)
        {
            //fCancel = true;
            fCancelBulk = true;
        }

        private void tsbtnStartStop_Click(object sender, EventArgs e)
        {  // Play-Button

            StartStopPressed();
            //return; //po

            //toolStripButton2_pressed = !toolStripButton2_pressed;  //negiere
            //if (toolStripButton2_pressed)
            //{
            //   toolStripComboBox1.SelectedItem = (pollinterval / 1000).ToString("00") + " Sek"; // jetzt automatisch
            //   tsbtnStartStop.Image = Properties.Resources.Player_Stop;
            //   // schnittstelle öffnen und auf das 05h warten
            //   this.Text = Appname + " - verbinde";
            //   toolStripLabel2.BackColor = Color.Yellow;
            //   Ser_Uebertragungsstatus = 0;
            //   gelesener_Datenpunkt = 0;

            //   if (!mySerialPort.IsOpen) Open_mySerialPort();
            //   t1.Start();
            //   t2.Start();

            //}
            //else // wenn gestartet war und ich will stoppen
            //{
            //   tsbtnStartStop.Image = Properties.Resources.Player_Play; // kann wieder starten
            //   toolStripComboBox1.SelectedItem = "Stop";
            //   t2.Stop();
            //}

        }

        private void tsbtnReadAll_Click(object sender, EventArgs e)
        {
            ReadListBulk(true);

            //if (lese_alle_Datenpunkte)
            //   lese_alle_Datenpunkte_zweimal = true;
            //lese_alle_Datenpunkte = true;
        }

        private void tsbtnReadSel_Click(object sender, EventArgs e)
        {
            ReadListBulk(false);
        }

        private void tsbtnInfo_Click(object sender, EventArgs e)
        {
            //Test();
            //return;
            //CHeatingDevice hd = new CHeatingDevice();
            //hd.ReadCsv(Path.Combine(Applikation_Pfad, "Devices.csv"));
            string msg = currDevice.DataPoint + ":" + csCrLf + currDevice.Description;
            MessageBox.Show(msg, "Device");
        }

        private void t1_Tick(object sender, EventArgs e)
        {
            ReadListBulk(false);

            #region old
            //// es kam eine bestimmte Zeit kein Zeichen mehr. Timer1 ist abgelaufen
            //string zeichen1 = String.Empty;

            //t1.Stop(); // definierten Zustand des Timers
            //t2.Stop(); // Automatic=zyklische Abfrage  stop
            //int M_S_I_B_Z = My_Serial_Input_Buffer_Zeiger;  // wie viele Zeichen waren es?
            //My_Serial_Input_Buffer_Zeiger = 0;      // Für das nächste Telegramm  

            //int z = 0;

            //if (!mySerialPort.IsOpen)
            //{
            //   t2.Start();
            //   return;
            //}

            //switch (Ser_Uebertragungsstatus)
            //{
            //   case 0:   // 0 = Empfangsbereit
            //      if (M_S_I_B_Z == 0) My_Serial_Input_Buffer[0] = 0x04;
            //      switch (My_Serial_Input_Buffer[0])  // Empfang im Ruhezustand 05h
            //      {
            //         case 0x05:
            //            // 300 Protokoll initialisieren - 'sync' senden
            //            My_Serial_Output_Buffer[0] = 0x16;
            //            My_Serial_Output_Buffer[1] = 0x00;
            //            My_Serial_Output_Buffer[2] = 0x00;
            //            mySerialPort.Write(My_Serial_Output_Buffer, 0, 3); // Buffer, ab 0, von 0 bis 2, = 3 Bytes senden
            //            t1.Interval = 50;
            //            this.t1.Start(); // Timer starten
            //            break;
            //         case 0x06:
            //            // Device Identifier / Anlagenkennung lesen
            //            My_Serial_Output_Buffer[0] = 0x41;
            //            My_Serial_Output_Buffer[1] = 0x05;
            //            My_Serial_Output_Buffer[2] = 0x00;
            //            My_Serial_Output_Buffer[3] = 0x01;
            //            My_Serial_Output_Buffer[4] = 0x00;
            //            My_Serial_Output_Buffer[5] = 0xF8;
            //            My_Serial_Output_Buffer[6] = 0x02; // Ich erwarte 2 Zeichen 
            //            My_Serial_Output_Buffer[7] = calc_CRC(My_Serial_Output_Buffer);
            //            Ser_Uebertragungsstatus = 1;
            //            mySerialPort.Write(My_Serial_Output_Buffer, 0, 8);
            //            t1.Interval = 50;
            //            this.t1.Start(); // Timer starten
            //            break;
            //         default:
            //            // zurückschalten auf KW Protokoll
            //            My_Serial_Output_Buffer[0] = 0x04;
            //            mySerialPort.Write(My_Serial_Output_Buffer, 0, 1); // Buffer, ab 0, 1 Byte senden
            //            t1.Interval = 50;
            //            this.t1.Start(); // Timer starten
            //            break;
            //      }
            //      break;

            //   case 1:    // 1 = ich wartete auf Anlagenkennung 
            //      if ((My_Serial_Input_Buffer[0] != 0x06) | (M_S_I_B_Z == 0) | (!(check_CRC())))
            //      {
            //         Ser_Uebertragungsstatus = 0;  // zurück auf Los
            //         break;
            //      }
            //      if (My_Serial_Input_Buffer[7] == My_Serial_Output_Buffer[6])// erwartete Anzahl war korrekt
            //      {
            //         // in xml hinterlegtes Device suchen und anzeigen, aber ansonsten passiert da nix mit 
            //         for (z = 0; z < 35; z++)
            //         {
            //            if (!(String.IsNullOrEmpty(Device_ID_Array[z])) & (Device_ID_Array[z].Contains(My_Serial_Input_Buffer[8].ToString("X2") + My_Serial_Input_Buffer[9].ToString("X2"))))
            //            {
            //               this.Text = Appname + " - verbunden mit:  " + Device_name_Array[z] + "   Protokoll:  " + Device_protocol_Array[z];
            //               this.toolStripLabel2.BackColor = Color.LightGreen;
            //               Ser_Uebertragungsstatus = 2;
            //               break;
            //            }
            //         }
            //         if (Ser_Uebertragungsstatus != 2)
            //         {
            //            // nochmal das Gleiche?!?
            //            this.Text = Appname + " - verbunden mit Device: " + My_Serial_Input_Buffer[8].ToString("X2") + My_Serial_Input_Buffer[9].ToString("X2");
            //            this.toolStripLabel2.BackColor = Color.LightGreen;
            //            Ser_Uebertragungsstatus = 2;
            //         }

            //         // +++++++++++++++++++++++++++++++
            //         // jetzt zu lesenden DP identifizieren und Anfrage schicken
            //         // +++++++++++++++++++++++++++++++


            //         // bis zum 1. selektierten springen
            //         if (Reihe >= mydataGridView1.RowCount) Reihe = 0;

            //         if (lese_alle_Datenpunkte == false)
            //         {
            //            // +++++++++++++++++++++++++++++++
            //            // nur gewählte lesen
            //            // +++++++++++++++++++++++++++++++

            //            //string ttt = mydataGridView1["Akt.", Reihe].Value.ToString();
            //            while (Reihe < (mydataGridView1.RowCount))
            //            {
            //               if ((mydataGridView1["Akt.", Reihe].Value.ToString() == "0") || (mydataGridView1["len", Reihe].Value.ToString() == "0"))
            //                  Reihe++; //Checkbox = 0 dann Reihe überspringen
            //               else
            //                  break;
            //            }
            //            // Abfrage ob es die letzte Reihe war und die war ebenfalls deaktiviert
            //            if (Reihe >= (mydataGridView1.RowCount))
            //            {
            //               ShowInfo( "Achtung! keine Datenpunkte selektiert";
            //               Ser_Uebertragungsstatus = 0;  // dann alles  stoppen
            //               Reihe = 0;
            //               gelesener_Datenpunkt = 0;
            //               this.Text = Appname + " - nicht verbunden ";
            //               this.toolStripLabel2.BackColor = Color.Red;
            //               return;
            //            }

            //         }
            //         else
            //         {
            //            // +++++++++++++++++++++++++++++++
            //            // alle lesen mit len > 0
            //            // +++++++++++++++++++++++++++++++

            //            while (Reihe < (mydataGridView1.RowCount))
            //            {
            //               if ((mydataGridView1["len", Reihe].Value.ToString() == "0"))
            //                  Reihe++; //len = 0 dann Reihe überspringen
            //               else
            //                  break;
            //            }

            //            // Abfrage ob es die letzte Reihe war und die war ebenfalls deaktiviert
            //            if (Reihe >= (mydataGridView1.RowCount))
            //            {
            //               Beende_Ser_Uebertragung();
            //               return;
            //            }

            //         }

            //         // +++++++++++++++++++++++++++++++
            //         // jetzt Reihe 'gefunden'
            //         // +++++++++++++++++++++++++++++++

            //         // wenn einer selektiert war, dann wird er hier angefordert 
            //         My_Serial_Output_Buffer[0] = 0x41;  // Telegrammstart
            //         My_Serial_Output_Buffer[1] = 0x05;  // Nutzdaten, hier immer 5
            //         My_Serial_Output_Buffer[2] = 0x00;  // Anfrage
            //         My_Serial_Output_Buffer[3] = 0x01;  // Lesen
            //         My_Serial_Output_Buffer[4] = byte.Parse(mydataGridView1["addr", Reihe].Value.ToString().Substring(0, 2), System.Globalization.NumberStyles.HexNumber);
            //         My_Serial_Output_Buffer[5] = byte.Parse(mydataGridView1["addr", Reihe].Value.ToString().Substring(2, 2), System.Globalization.NumberStyles.HexNumber);
            //         My_Serial_Output_Buffer[6] = byte.Parse(mydataGridView1["len", Reihe].Value.ToString()); // Länge mit de hex wandlung
            //         My_Serial_Output_Buffer[7] = calc_CRC(My_Serial_Output_Buffer);
            //         mySerialPort.Write(My_Serial_Output_Buffer, 0, 8);  // Buffer senden
            //         t1.Interval = 50;
            //         this.t1.Start(); // Timer starten
            //         gelesener_Datenpunkt++;  //Zähler für Textbox

            //      }
            //      else  // wenn die Anzahl der vorangegangenen Antwort nicht korrekt war 
            //      {
            //         Ser_Uebertragungsstatus = 0;
            //      }
            //      break;

            //   case 2:
            //      // +++++++++++++++++++++++++++++++
            //      // Antwort wurde empfangen -> hier auswerten und in Liste anzeigen
            //      // +++++++++++++++++++++++++++++++

            //      // hier kommt Wert für Wert rein
            //      if ((My_Serial_Input_Buffer[0] == 0x06) // Status ok
            //                                              //& (My_Serial_Input_Buffer[3] == 0x01)  //Antwort ohne Fehler
            //          & (My_Serial_Input_Buffer[7] == My_Serial_Output_Buffer[6]) // erwartete Anzahl war korrekt
            //          & (M_S_I_B_Z == 9 + My_Serial_Output_Buffer[6])
            //          & (check_CRC()))
            //      {
            //         toolStripTextBox1.Text = Reihe.ToString();  // Anzeige der ausgelesenen Reihe
            //         toolStripTextBox2.Text = gelesener_Datenpunkt.ToString();


            //         for (int i = 0; i < My_Serial_Output_Buffer[6]; i++) // Anzeige der HEX-Werte
            //         {
            //            string zeichen = My_Serial_Input_Buffer[8 + i].ToString("X2");
            //            zeichen1 = zeichen1 + zeichen + " ";
            //         }
            //         mydataGridView1["Wert_Hex", Reihe].Value = zeichen1;

            //         zeichen1 = String.Empty;

            //         for (int i = 0; i < My_Serial_Output_Buffer[6]; i++) // Anzeige der dez-Werte
            //         {
            //            string zeichen = My_Serial_Input_Buffer[8 + i].ToString("000");
            //            zeichen1 = zeichen1 + zeichen + " ";
            //         }
            //         mydataGridView1["Wert_Dez", Reihe].Value = zeichen1;

            //         // Datum und Uhrzeit formatieren
            //         if (mydataGridView1["addr", Reihe].Value.ToString() == "088E") // Anzeige der Value (umgerechneten Werte)
            //         {
            //            string myString;
            //            myString = Wochentag[(My_Serial_Input_Buffer[12] + 6) % 7] + " " +
            //            My_Serial_Input_Buffer[11].ToString("X2") + "." + My_Serial_Input_Buffer[10].ToString("X2") + "." +
            //            My_Serial_Input_Buffer[8].ToString("X2") + My_Serial_Input_Buffer[9].ToString("X2") + " " +
            //            My_Serial_Input_Buffer[13].ToString("X2") + ":" + My_Serial_Input_Buffer[14].ToString("X2") + ":" + My_Serial_Input_Buffer[15].ToString("X2");
            //            mydataGridView1["Wert_Val", Reihe].Value = myString;
            //         }


            //         // wenn precision nicht leer ist            
            //         if (mydataGridView1["precision", Reihe].Value.ToString() != String.Empty) // Anzeige der Value (umgerechneten Werte)
            //         {
            //            float myValue = 0;

            //            switch (mydataGridView1["len", Reihe].Value.ToString())
            //            {
            //               case "1":
            //                  if (mydataGridView1["addr", Reihe].Value.ToString() == "27d4") // Neigung evtl. negativ
            //                  {
            //                     int myValue1 = (My_Serial_Input_Buffer[8]);

            //                     if (myValue1 > 0x80)
            //                     {
            //                        myValue1 = (256 - myValue1);
            //                        myValue = myValue1 * float.Parse(mydataGridView1["precision", Reihe].Value.ToString(), CultureInfo.InvariantCulture);
            //                        myValue = -myValue;
            //                     }
            //                     else
            //                     {
            //                        myValue = myValue1 * float.Parse(mydataGridView1["precision", Reihe].Value.ToString(), CultureInfo.InvariantCulture);
            //                     }

            //                     mydataGridView1["Wert_Val", Reihe].Value = Math.Round(myValue, 2);

            //                  }
            //                  else
            //                  {
            //                     myValue = My_Serial_Input_Buffer[8] * float.Parse(mydataGridView1["precision", Reihe].Value.ToString(), CultureInfo.InvariantCulture);
            //                     mydataGridView1["Wert_Val", Reihe].Value = Math.Round(myValue, 2);
            //                  }
            //                  break;
            //               case "2":
            //                  // negative Temperaturen behandeln
            //                  // Die können nur bei den u. g. Datenpunkten auftreten
            //                  if (mydataGridView1["addr", Reihe].Value.ToString() == "0800" |
            //                      mydataGridView1["addr", Reihe].Value.ToString() == "5523" |
            //                      mydataGridView1["addr", Reihe].Value.ToString() == "5525" |
            //                      mydataGridView1["addr", Reihe].Value.ToString() == "5527") // Aussentemp negativ
            //                  {
            //                     int myValue1 = ((My_Serial_Input_Buffer[9] << 8) + My_Serial_Input_Buffer[8]);
            //                     if (myValue1 > 0x8000)
            //                     {

            //                        myValue1 = myValue1 ^ 0xFFFF;
            //                        myValue = myValue1 * float.Parse(mydataGridView1["precision", Reihe].Value.ToString(), CultureInfo.InvariantCulture);
            //                        myValue = -myValue;
            //                        mydataGridView1["Wert_Val", Reihe].Value = Math.Round(myValue, 2);

            //                     }
            //                     else
            //                     {
            //                        myValue = ((My_Serial_Input_Buffer[9] << 8) + My_Serial_Input_Buffer[8]) * float.Parse(mydataGridView1["precision", Reihe].Value.ToString(), CultureInfo.InvariantCulture);
            //                        mydataGridView1["Wert_Val", Reihe].Value = Math.Round(myValue, 2);
            //                     }
            //                     break;
            //                  }
            //                  // hier sind normale Werte, Temperaturen etc.
            //                  myValue = ((My_Serial_Input_Buffer[9] << 8) + My_Serial_Input_Buffer[8]) * float.Parse(mydataGridView1["precision", Reihe].Value.ToString(), CultureInfo.InvariantCulture);

            //                  mydataGridView1["Wert_Val", Reihe].Value = Math.Round(myValue, 2);
            //                  break;
            //               case "4":
            //                  myValue = ((My_Serial_Input_Buffer[11] << 24) + (My_Serial_Input_Buffer[10] << 16)
            //                            + (My_Serial_Input_Buffer[9] << 8) + (My_Serial_Input_Buffer[8])); // * double.Parse(mydataGridView1["precision", Reihe].Value.ToString());
            //                  mydataGridView1["Wert_Val", Reihe].Value = Math.Round(myValue / float.Parse(mydataGridView1["precision", Reihe].Value.ToString(), CultureInfo.InvariantCulture), 2);

            //                  break;
            //               default:
            //                  break;
            //            }
            //         }

            //         // +++++++++++++++++++++++++++++++
            //         // hier nicht-Liste Tabs aktualisieren
            //         // +++++++++++++++++++++++++++++++
            //         Screen_Update(Reihe);
            //         // Bis hier ist die letzte Anforderung verarbeitet worden 



            //         // +++++++++++++++++++++++++++++++
            //         // ab hier wieder das Gleiche wie oben??? was für ein Chaos...
            //         // +++++++++++++++++++++++++++++++

            //         Reihe++; // Nächste Reihe vorbereiten
            //         if (Reihe >= (mydataGridView1.RowCount)) // wenn der letzte Datensatz eingelesen war beende Abfrage
            //         {
            //            Beende_Ser_Uebertragung();
            //            if (lese_alle_Datenpunkte)
            //            {
            //               t2.Interval = 1;
            //            }
            //            else
            //            {
            //               t2.Interval = pollinterval;
            //            }

            //            if (lese_alle_Datenpunkte)
            //            {
            //               lese_alle_Datenpunkte = false;  // Nach den 1. Duchlauf beenden
            //               // was soll das?? CheckedChanged Events auslösen vielleicht?
            //               if (radioButton1.Checked) { radioButton1.Checked = false; radioButton1.Checked = true; }
            //               if (radioButton2.Checked) { radioButton2.Checked = false; radioButton2.Checked = true; }
            //               if (radioButton3.Checked) { radioButton3.Checked = false; radioButton3.Checked = true; }

            //            }
            //            if (lese_alle_Datenpunkte_zweimal)
            //            {
            //               lese_alle_Datenpunkte_zweimal = false;
            //               lese_alle_Datenpunkte = true;
            //            }
            //            return;
            //         }

            //         // bis zum naechsten selektierten springen
            //         if (lese_alle_Datenpunkte == false)
            //         {
            //            while ((Reihe < mydataGridView1.RowCount) &&
            //                    (mydataGridView1["Akt.", Reihe].Value.ToString() == "0" ||
            //                    mydataGridView1["len", Reihe].Value.ToString() == "0"))
            //            {
            //               Reihe++; //Checkbox = 0 dann Reihe überspringen
            //            }
            //            // hier kommt das Prog nur hin, wenn es innnerhalb des Grid ist 
            //            if (Reihe >= (mydataGridView1.RowCount)) // und letzter Datensatz aber nicht zum Lesen markiert
            //            {
            //               Beende_Ser_Uebertragung();
            //               if (lese_alle_Datenpunkte)
            //               {
            //                  t2.Interval = 1;
            //               }
            //               else
            //               {
            //                  t2.Interval = pollinterval;
            //               }

            //               lese_alle_Datenpunkte = false;  // Nach den 1. Duchlauf beenden
            //               if (lese_alle_Datenpunkte_zweimal)
            //               {
            //                  lese_alle_Datenpunkte_zweimal = false;
            //                  lese_alle_Datenpunkte = true;
            //               }
            //               return;
            //            }
            //         }
            //         else
            //         {
            //            while ((Reihe < mydataGridView1.RowCount) && (mydataGridView1["len", Reihe].Value.ToString() == "0"))
            //            {
            //               Reihe++; //Checkbox = 0 dann Reihe überspringen
            //            }   // hier kommt das Prog nur hin, wenn es innnerhalb des Grid ist 
            //            if (Reihe >= (mydataGridView1.RowCount)) // und letzter Datensatz aber nicht zum Lesen markiert
            //            {
            //               Beende_Ser_Uebertragung();
            //               if (lese_alle_Datenpunkte)
            //               {
            //                  t2.Interval = 1;
            //               }
            //               else
            //               {
            //                  t2.Interval = pollinterval;
            //               }

            //               lese_alle_Datenpunkte = false;  // Nach den 1. Duchlauf beenden
            //               if (lese_alle_Datenpunkte_zweimal)
            //               {
            //                  lese_alle_Datenpunkte_zweimal = false;
            //                  lese_alle_Datenpunkte = true;
            //               }
            //               return;
            //            }

            //         }

            //         if (Reihe >= (mydataGridView1.RowCount)) // und letzter Datensatz aber nicht zum Lesen markiert
            //         {
            //            Beende_Ser_Uebertragung();
            //            if (lese_alle_Datenpunkte)
            //            {
            //               t2.Interval = 1;
            //            }
            //            else
            //            {
            //               t2.Interval = pollinterval;
            //            }

            //            lese_alle_Datenpunkte = false;  // Nach den 1. Duchlauf beenden
            //            if (lese_alle_Datenpunkte_zweimal)
            //            {
            //               lese_alle_Datenpunkte_zweimal = false;
            //               lese_alle_Datenpunkte = true;
            //            }
            //            return;
            //         }

            //         My_Serial_Output_Buffer[0] = 0x41;  // Telegrammstart
            //         My_Serial_Output_Buffer[1] = 0x05;  // Nutzdaten, hier immer 5
            //         My_Serial_Output_Buffer[2] = 0x00;  // Anfrage
            //         My_Serial_Output_Buffer[3] = 0x01;  // Lesen
            //         My_Serial_Output_Buffer[4] = byte.Parse(mydataGridView1["addr", Reihe].Value.ToString().Substring(0, 2), System.Globalization.NumberStyles.HexNumber);
            //         My_Serial_Output_Buffer[5] = byte.Parse(mydataGridView1["addr", Reihe].Value.ToString().Substring(2, 2), System.Globalization.NumberStyles.HexNumber);
            //         My_Serial_Output_Buffer[6] = byte.Parse(mydataGridView1["len", Reihe].Value.ToString()); // Länge mit de hex wandlung
            //         My_Serial_Output_Buffer[7] = calc_CRC(My_Serial_Output_Buffer);
            //         mySerialPort.Write(My_Serial_Output_Buffer, 0, 8);  // Buffer senden
            //         t1.Interval = 50;
            //         this.t1.Start(); // Timer starten
            //         gelesener_Datenpunkt++;  //Zähler für Textbox


            //      }  //end if wenn es nicht die Zeichenanzahl war
            //      else
            //      {
            //         My_Serial_Output_Buffer[0] = 0x41;  // Telegrammstart
            //         My_Serial_Output_Buffer[1] = 0x05;  // Nutzdaten, hier immer 5
            //         My_Serial_Output_Buffer[2] = 0x00;  // Anfrage
            //         My_Serial_Output_Buffer[3] = 0x01;  // Lesen
            //         My_Serial_Output_Buffer[4] = byte.Parse(mydataGridView1["addr", Reihe].Value.ToString().Substring(0, 2), System.Globalization.NumberStyles.HexNumber);
            //         My_Serial_Output_Buffer[5] = byte.Parse(mydataGridView1["addr", Reihe].Value.ToString().Substring(2, 2), System.Globalization.NumberStyles.HexNumber);
            //         My_Serial_Output_Buffer[6] = byte.Parse(mydataGridView1["len", Reihe].Value.ToString()); // Länge mit de hex wandlung
            //         My_Serial_Output_Buffer[7] = calc_CRC(My_Serial_Output_Buffer);
            //         mySerialPort.Write(My_Serial_Output_Buffer, 0, 8);  // Buffer senden
            //         t1.Interval = 50;
            //         this.t1.Start(); // Timer starten


            //      }

            //      break;


            //   default:
            //      break;   // alles andere interessiert uns nicht
            //}  //switch
            #endregion old
        }

        #region old
        //private void t2_Tick(object sender, EventArgs e)
        //{
        //   t2.Stop();

        //   Ser_Uebertragungsstatus = 0;
        //   gelesener_Datenpunkt = 0;
        //   if (!mySerialPort.IsOpen) { Open_mySerialPort(); };
        //   // starte Abfragezyklus
        //   if (mySerialPort.IsOpen)
        //      t1.Start();
        //   else
        //      t2.Start();
        //}

        //private void mySerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        //{
        //   // wird aufgerufen, wenn ein oder mehrere Zeichen im Puffer sind
        //   try
        //   {
        //      Zeichenanzahl1 = this.mySerialPort.BytesToRead; // puffern, da BytesToRead nach lesen = 0
        //      this.mySerialPort.Read(My_Serial_Input_Buffer, My_Serial_Input_Buffer_Zeiger, Zeichenanzahl1);
        //      My_Serial_Input_Buffer_Zeiger = My_Serial_Input_Buffer_Zeiger + Zeichenanzahl1;
        //      this.Invoke(new EventHandler(Timer1_Trigger));  // Timer triggern solange Daten ankommen
        //   }
        //   catch (Exception ex)
        //   {
        //      //MessageBox.Show(ex.Message);
        //   }
        //}

        //private void Timer1_Trigger(object sender, EventArgs e)
        //{
        //   // solange Zeichen reinkommen wird der Timer1 getriggert. Kommt kein Zeichen mehr wird 
        //   // nach Ablauf der Zeit der Int. ausgelöst 
        //   t1.Stop();
        //   t1.Interval = 50;
        //   t1.Start();
        //}
        #endregion old


        private void Main_Form_Load(object sender, EventArgs e)
        {
            //notico = new NotifyIcon();
            //notico.Icon = new Icon("vitodens300w.ico"); // Eigenes Icon in der Taskleiste einsetzen
            //notico.Visible = true;
            //notico.Text = Appname;
            this.Text = Appname;
            //ShowInfo(String.Empty);

            //t1.Interval = 50; // Intervall festlegen, hier 15 ms
            tmrPoll.Tick += new EventHandler(t1_Tick); // Eventhandler ezeugen der beim Timerablauf aufgerufen wird

            //t2.Interval = 25; // Intervall festlegen, hier 15 ms
            //pollinterval = 25;
            //t2.Tick += new EventHandler(t2_Tick); // Eventhandler ezeugen der beim Timerablauf aufgerufen wird

            this.Size = new Size(1024, 600);

            MakeZeitenTab();

            MakeListe();

            MakeStatGrid();

            // Aktivieren der Datenseite ist anscheinend zum Initialisieren von mydatagrid notwendig, sonst wird beim ersten Wechsel auf dieses Tab no entry angezeigt
            this.tabControl1.SelectedIndex = 1;
            for (int i = 0; i < mydataGridView1.RowCount; i++)
            {
                mydataGridView1["Nr", i].Value = i;
                //dataSet1.Tables[0].Rows[i].Table.Columns["Nr."].
            }
            this.tabControl1.SelectedIndex = 0; // 1. Seite

            //radioButton2.Checked = true; // Muss unten stehen, da Datagrid geladen sein muss

            // po: jetzt in Deklarationen
            //Applikation_Pfad = Programme.myDatei_handling.Get_Applikation_Path();
            //cfg_Dateipfad = Applikation_Pfad; // Programme.myDatei_handling.Get_Applikation_Path();

            createDataFile();

            // UpdateGraphCountMenu();

            // UpdateColorSchemaMenu();

            #region init COM
            XmlDocument ser_config = new XmlDocument();
            ser_config.Load(cfg_Datei);
            XmlNodeList nodeListe = ser_config.GetElementsByTagName("Port");

            foreach (XmlNode node in nodeListe)
            {
                int z = 0;
                if (node != null) //kein node in Datei
                {
                    XmlAttribute xmlAttr1 = nodeListe[z].Attributes["name"];
                    this.portName = xmlAttr1.InnerText;

                    //XmlNode xmlNode1 = ser_Liste[z].SelectSingleNode("BaudRate");
                    //this.baudRate = Convert.ToInt32(xmlNode1.InnerText);

                    //xmlNode1 = ser_Liste[z].SelectSingleNode("Parity");
                    //this.parity = (Parity)Enum.Parse(typeof(Parity), xmlNode1.InnerText);

                    //xmlNode1 = ser_Liste[z].SelectSingleNode("DataBits");
                    //this.dataBits = Convert.ToInt32(xmlNode1.InnerText);

                    //xmlNode1 = ser_Liste[z].SelectSingleNode("StopBits");
                    //this.stopBits = (StopBits)Enum.Parse(typeof(StopBits), xmlNode1.InnerText);

                    //xmlNode1 = ser_Liste[z].SelectSingleNode("Handshake");
                    //this.handshake = (Handshake)Enum.Parse(typeof(Handshake), xmlNode1.InnerText);
                    z++;
                }

            }
            #endregion init COM

            load_tcp();

            #region init controls
            this.FillComPortComboBox();  // Alle verfügbaren Portnamen einsacken
                                         //this.FillParityComboBox();
                                         //this.FillStopBitComboBox();
                                         //this.FillDataBitsComboBox();
                                         //this.FillBaudRateComboBox();
                                         //this.FillHandshakeComboBox();

            this.FillTimerComboBox();

            this.FillGrafLaengeComboBox();


            //      this.toolStripLabel2.TextAlign = HorizontalAlignment.Center;
            this.tslblLed.Font = new System.Drawing.Font("Arial", 7, FontStyle.Regular);

            //this.numUpDown_von.Font = new System.Drawing.Font("Arial", 11, FontStyle.Regular);
            //this.numUpDown_bis.Font = new System.Drawing.Font("Arial", 11, FontStyle.Regular);


            tslblLed.Text = String.Empty;
            toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System; // Damit die Hintergrundfarbe geändert werden kann
            tslblLed.BackColor = Color.Red;

            CB_Betriebsart.Items.Add("Abschaltbetrieb");
            CB_Betriebsart.Items.Add("Nur Warmwasser");
            CB_Betriebsart.Items.Add("Heizen und WW");
            CB_Betriebsart.Items.Add("Dauernd Reduziert");
            CB_Betriebsart.Items.Add("Dauernd Normal");

            CB_WWHysterese.Items.Add("2.5");
            for (int i = 1; i < 11; i++)
                CB_WWHysterese.Items.Add(i.ToString());

            for (int i = -9; i < 16; i++)
            {
                CB_Frostschutztemp.Items.Add(i.ToString());
            }

            CB_ZirkuFrequ.Items.Add("Ein nach Prog.");
            CB_ZirkuFrequ.Items.Add("1 mal/Std. n.P.");
            CB_ZirkuFrequ.Items.Add("2 mal/Std. n.P.");
            CB_ZirkuFrequ.Items.Add("3 mal/Std. n.P.");
            CB_ZirkuFrequ.Items.Add("4 mal/Std. n.P.");
            CB_ZirkuFrequ.Items.Add("5 mal/Std. n.P.");
            CB_ZirkuFrequ.Items.Add("6 mal/Std. n.P.");
            CB_ZirkuFrequ.Items.Add("Dauernd Ein");


            CB_SparHK.Items.Add("Inaktiv");
            for (int i = 1; i < 6; i++)
            {
                CB_SparHK.Items.Add("AT > RTS + " + (6 - i).ToString("0") + "K");
            }
            CB_SparHK.Items.Add("AT > RTS");
            for (int i = 7; i < 16; i++)
            {
                CB_SparHK.Items.Add("AT > RTS - " + (i - 6).ToString("0") + "K");
            }

            for (int i = 0; i <= 30; i++)
            {
                CB_SparBrenner.Items.Add("AT ged. > " + (6 + i).ToString("0") + "°");
            }
            CB_SparBrenner.Items.Add("Inaktiv");

            Label0842.BackColor = Color.Yellow;  // Brenner
            Label0846.BackColor = Color.Yellow;  // WW-Zirkulationspumpe
            Label0845.BackColor = Color.Yellow;  // Speicherladepumpe
            Label3906.BackColor = Color.Yellow;  // Speicherladepumpe
            Label0883.BackColor = Color.Yellow;  // Sammelstoerung 0 = ok
            label29.BackColor = Color.Yellow;  // Brennerstoerung 0 = ok
            Frostgefahr.BackColor = Color.Yellow;  // Frostgefahr 
            Label_SparA5.BackColor = Color.Yellow;  // SparA5 
            Label_SparA6.BackColor = Color.Yellow;  // SparA6 
            #endregion init controls


            load_maxpower();
            tbNennLeistung.Text = maxpower.ToString("0.0");
            tbZZahl.Text = zzahl.ToString("0.0000");
            tbBrennwert.Text = brennwert.ToString("0.0000");



            //numUpDown_von.LostFocus += new EventHandler(numUpDown_von_Leave);  // Interrupthaendler anlegen
            //numUpDown_bis.LostFocus += new EventHandler(numUpDown_bis_Leave);  // Interrupthaendler anlegen



            //numUpDown_von.Hexadecimal = true;
            //numUpDown_bis.Hexadecimal = true;

            //numUpDown_von.Minimum = 0x0;
            //numUpDown_von.Maximum = 0xFFFF;
            //numUpDown_von.Value = 0;


            //numUpDown_bis.Minimum = 0x1;
            //numUpDown_bis.Maximum = 0xFFFF;
            //numUpDown_bis.Value = 0x1000;

            tsbtnStartStop.Image = Properties.Resources.Player_Play;


            //   InitDataGraphs();
            //   plotterDisplayEx1.Refresh();
            this.tscbGraphArea.SelectedIndex = this.tscbGraphArea.Items.IndexOf("1Tag"); //Voreinstellung

            //lese_alle_Datenpunkte = true; // Beim 1. Durchlauf alle lesen
            //Lese_Steuerungen(); // Tabelle mit den bekannten Steuerungen lesen

            // 'init'
            rbnHeizZeiten.Checked = true;

        }

        private void Main_Form_Shown(object sender, EventArgs e)
        {
            if (auto_start) tsbtnStartStop_Click(tsbtnStartStop, null);
        }

        private void Main_Form_Closing(object sender, FormClosingEventArgs e)
        {
            Cancel();

            mycomm.CleanExit();

            //try
            //{
            //   //comport.DiscardOutBuffer();
            //   //comport.DiscardInBuffer();
            //   //comport.Dispose();
            //   if (!mySerialPort.IsOpen) Open_mySerialPort();
            //   My_Serial_Output_Buffer[0] = 0x04;    // 0x04 senden, um KW Protokoll zu initialisieren
            //   mySerialPort.Write(My_Serial_Output_Buffer, 0, 1);
            //   if (mySerialPort.IsOpen)
            //   {
            //      mySerialPort.ReadExisting();
            //      try { mySerialPort.Close(); }
            //      catch { };
            //   }
            //}
            //catch (Exception ex)
            //{
            //   //MessageBox.Show(ex.Message);
            //}

            //save_maxpower();
            //Application.Exit();
        }
        #endregion MainForm Event-Handler

        #region tabPage0 Event-Handler Übersicht
        private void btnLoadWW_Click(object sender, EventArgs e)
        {
            LoadWW();
        }

        #region tb_leave procs
        // _Leave code has been moved to _KeyUp(KeyReturn) events

        private void CB_Betriebsart_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            int value = ((ComboBox)sender).SelectedIndex;
            if ((value >= 0) & (value < 5))
                send_parameter(0x2323, (byte)value);
        }

        private void ChB_Party_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            if (((CheckBox)sender).Checked)
                send_parameter(0x2330, 1);
            else
                send_parameter(0x2330, 0);
        }

        private void ChB_Spar_Leave(object sender, KeyEventArgs e) //_Leave(object sender, MouseEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            if (((CheckBox)sender).Checked)
                send_parameter(0x2331, 1);
            else
                send_parameter(0x2331, 0);
        }

        private void TextBoxRTS_Tag_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            byte value;
            if (!byte.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value >= 3) & (value <= 37))
                send_parameter(0x2306, value);
        }

        private void TextBoxRTS_Nacht_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            byte value;
            if (!byte.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value >= 3) & (value <= 37))
                send_parameter(0x2307, value);
        }

        private void TextBoxRTS_Party_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            byte value;
            if (!byte.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value >= 3) & (value <= 37))
                send_parameter(0x2308, value);
        }

        private void TextBoxWWS_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            byte value;
            if (!byte.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value >= 10) & (value < 80))
                send_parameter(0x6300, value);
        }

        private void TextBoxHKLNiveau_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            sbyte value;
            if (!sbyte.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value >= -15) & (value <= 40))
                send_parameter(0x27d4, (byte)value);
        }

        private void TextBoxHKLNeigung_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            float valuef;
            if (!float.TryParse(CorrectedDecSep(((TextBox)sender).Text), out valuef))
                return;

            byte value = (byte)(valuef * 10 + 0.5);
            if ((value >= 2) & (value <= 35))
                send_parameter(0x27d3, value);
        }

        private void TB_ErhoehungKTS_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            byte value;
            if (!byte.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value >= 0) & (value <= 50))
                send_parameter(0x27FA, value);
        }

        private void TB_ErhoehungszeitKTS_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            byte value;
            if (!byte.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value >= 0) & (value <= 150))
                send_parameter(0x27FB, value);
        }


        private void TB_PlstminbeiNorm_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            byte value;
            if (!byte.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value >= 0) & (value <= 100))
                send_parameter(0x27E7, value);
        }

        private void TB_PlstmaxbeiNorm_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            byte value;
            if (!byte.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value >= 0) & (value <= 100))
                send_parameter(0x27E6, value);
        }

        private void ChB_PlstbeiRed_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            if (((CheckBox)sender).Checked)
                send_parameter(0x27E8, 1);
            else
                send_parameter(0x27E8, 0);
        }

        private void TB_PlstbeiRed_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            byte value;
            if (!byte.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value >= 0) & (value <= 100))
                send_parameter(0x27E9, value);
        }

        private void TB_PumpebeiWW_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            byte value;
            if (!byte.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value > 0) & (value <= 100))
                send_parameter(0x676C, value);
        }

        private void CB_WWHysterese_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            int value = ((ComboBox)sender).SelectedIndex;
            if ((value >= 0) & (value < 11))
                send_parameter(0x6759, (byte)value);
        }

        private void CB_Frostschutztemp_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            int value = ((ComboBox)sender).SelectedIndex - 9;
            if ((value >= -9) & (value < 16))
            {
                send_parameter(0x27A3, (byte)value);
            }

        }



        private void TB_MaxBrennerHK_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            byte value;
            if (!byte.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value >= 8) & (value <= 100))
                send_parameter(0x8832, value);
        }

        private void TB_MaxBrennerWW_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            byte value;
            if (!byte.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value > 0) & (value <= 100))
                send_parameter(0x676F, value);
        }

        private void TB_MaxDeltaKTWW_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            byte value;
            if (!byte.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value >= 5) & (value <= 25))
                send_parameter(0x6760, value);
        }

        private void TB_NachlaufWW_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            byte value;
            if (!byte.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value >= 0) & (value <= 15))
                send_parameter(0x6762, value);
        }

        private void TB_DaempfungAT_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            int ival;
            if (!int.TryParse(((TextBox)sender).Text, out ival))
                return;

            byte value = (byte)(ival / 10);
            if ((value >= 1) & (value <= 199))
                send_parameter(0x7790, value);
        }

        private void CB_ZirkuFrequ_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            int value = ((ComboBox)sender).SelectedIndex;
            if ((value >= 0) & (value < 8))
                send_parameter(0x6773, (byte)value);
        }

        private void CB_SparHK_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            int value = ((ComboBox)sender).SelectedIndex;
            if (value < 16)
                send_parameter(0x27A5, (byte)value);
        }

        private void CB_SparBrenner_Leave(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Return)
                return;

            int value = ((ComboBox)sender).SelectedIndex + 5;
            if ((value > 4) && (value < 37))
                send_parameter(0x27A6, (byte)value);
        }

        private void tbNennLeistung_Leave(object sender, EventArgs e)
        {
            double value;
            if (!double.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value > 5) & (value <= 50))
            {
                maxpower = value;
                gaswert = maxpower / zzahl / brennwert;
            }

        }

        private void tbZZahl_Leave(object sender, EventArgs e)
        {
            double value;
            if (!double.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value > 0.5) & (value <= 1.5))
            {
                zzahl = value;
                gaswert = maxpower / zzahl / brennwert;
            }

        }

        private void tbBrennwert_Leave(object sender, EventArgs e)
        {
            double value;
            if (!double.TryParse(((TextBox)sender).Text, out value))
                return;

            if ((value > 5) & (value <= 15))
            {
                brennwert = value;
                gaswert = maxpower / zzahl / brennwert;
            }

        }
        #endregion tb_leave procs

        #endregion tabPage0 Event-Handler Übersicht

        #region tabPage1 Event-Handler Liste
        private void btnNewCsv_Click(object sender, EventArgs e)
        {
            string msg = String.Empty;

            if (fSemaBulkRead)
            {
                msg = "Bitte Lesevorgang abwarten und zykl. Lesen stoppen!";
                MessageBox.Show(msg, "Abbruch");
                return;
            }

            tmrPoll.Stop();

            // Wenn die Datei vorhanden war ggf. sichern, anschließend mit 1. Zeile neu erstellen
            try
            {
                string bkpfile = String.Empty;
                int i = 0;

                if (File.Exists(DataFilename_akt))
                {
                    // confirm
                    msg = "csv sichern und neue beginnen?";
                    DialogResult result1 = MessageBox.Show(msg, "Graph etc neu beginnen", MessageBoxButtons.YesNo);
                    if (result1 != DialogResult.Yes)
                        return;

                    // find new bkp file
                    while (true)
                    {
                        bkpfile = DataFilename_akt.Substring(0, DataFilename_akt.Length - 4) + "_bkp" + i.ToString() + ".csv";
                        if (File.Exists(bkpfile))
                            i++;
                        else
                            break;
                    }

                    // backup file
                    File.Copy(DataFilename_akt, bkpfile);

                    File.Delete(DataFilename_akt);
                }

                // create new file...
                using (StreamWriter Stream_Writer = new StreamWriter(new FileStream(DataFilename_akt, FileMode.Create, FileAccess.Write, FileShare.None)))
                {
                    Stream_Writer.Write(System.DateTime.Now.ToString(";" + "yyyy-MM-dd") + ";");
                    for (int j = 0; j < mydataGridView1.RowCount; j++)
                    {
                        if (mydataGridView1["Sp.", j].Value.ToString() == "1")  // Wenn selektiert dann..
                        {
                            Stream_Writer.Write(mydataGridView1["addr", j].Value.ToString() + ";");
                        }
                    }
                    Stream_Writer.Write(csCrLf); // \r=return \n=newline
                }  // hier wird Stream_Writer und der zugrunde liegende FileStream geschlossen

                // neues File 'verarbeiten'
                btnLoadCurrCsv_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "csCrLf" + DataFilename_akt, "Fehler");
                //ShowInfo( "Fehler beim Löschen der Datei " + DataFilename;
            }

        }

        private void btn_select_alle_Click(object sender, EventArgs e)
        {
            // selektiere alle
            for (int i = 0; i < mydataGridView1.RowCount; i++)
            {
                mydataGridView1["Akt.", i].Value = "1";
            }
        }

        private void btn_select_kein_Click(object sender, EventArgs e)
        {
            // selektiere kein
            for (int i = 0; i < mydataGridView1.RowCount; i++)
            {
                mydataGridView1["Akt.", i].Value = "0";
                mydataGridView1["Sp.", i].Value = "0";
            }
        }

        private void btnClearChart_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < mydataGridView1.RowCount; i++)
            {
                mydataGridView1["Wert_Val", i].Value = 0; // null;
                mydataGridView1["Wert_Hex", i].Value = 0; // null;
                mydataGridView1["Wert_Dez", i].Value = 0; //  null;
            }
        }

        private void btnClearRowVal_Click(object sender, EventArgs e)
        {
            int row = mydataGridView1.CurrentCell.RowIndex;
            ClearRowVals(row);
        }

        private void btnReadDp_Click(object sender, EventArgs e)
        {
            int row = mydataGridView1.CurrentCell.RowIndex;
            ReadListDP(row);
        }

        private void btnWriteDp_Click(object sender, EventArgs e)
        {
            WriteListDp();
        }

        private void btnReloadXml_Click(object sender, EventArgs e)
        {
            if (fSemaBulkRead)
            {
                Console.Beep();
                return;
            }

            bool on = tmrPoll.Enabled;
            tmrPoll.Stop();

            dataSet1.Clear();
            dataSet1.ReadXml(dp_Datei);

            for (int i = 0; i < mydataGridView1.RowCount; i++)
            {
                mydataGridView1["Nr", i].Value = i;
            }

            if (on)
                tmrPoll.Start();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //string s = dataSet1.Tables["datapoint"].Rows[2].ItemArray[8].ToString();

            // Klick in eine Zelle auswerten
            //string msg = String.Format("Row: {0}, Column: {1} Checked: {2}", mydataGridView1.CurrentCell.RowIndex, mydataGridView1.CurrentCell.ColumnIndex, mydataGridView1.CurrentCell.Value);
            //     MessageBox.Show(msg, "Current Cell");

            //// wenn die Daten gespeichert werden sollen und es wurde ein Selectfeld verändert, muss eine neue Dateie erstellt werden
            //if (mydataGridView1.CurrentCell.ColumnIndex == 0)  // Wenn selektiert dann..
            //{
            //   checkBox1.Checked = false;
            //   //if (mydataGridView1.Columns["Akt."].State == true) mydataGridView1["Akt.", mydataGridView1.CurrentCell.RowIndex].Value = "0";
            //}
        }
        #endregion tabPage1 Event-Handler

        #region tabPage2 Event-Handler Zeiten
        private void rbnHeizZeiten_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnHeizZeiten.Checked)
            {
                //rbnZirkuZeiten.Checked = false; rbnWwZeiten.Checked = false;
                //GroupBox2200.Text = GroupBox2202.Text = GroupBox2204.Text = GroupBox2206.Text = "A1M1 Zeit 1";
                GroupBox2200.Text = "Heizung Zeit 1";
                GroupBox2202.Text = "Heizung Zeit 2";
                GroupBox2204.Text = "Heizung Zeit 3";
                GroupBox2206.Text = "Heizung Zeit 4";
                iCurrZeitenBaseAddr = 0x2000;
                Fill_Zeiten((ushort)(iCurrZeitenBaseAddr + iCurrHkOffset));
            }
        }

        private void rbnWwZeiten_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnWwZeiten.Checked)
            {
                //rbnZirkuZeiten.Checked = false; rbnHeizZeiten.Checked = false;
                GroupBox2200.Text = "Warmwasser Zeit 1";
                GroupBox2202.Text = "Warmwasser Zeit 2";
                GroupBox2204.Text = "Warmwasser Zeit 3";
                GroupBox2206.Text = "Warmwasser Zeit 4";
                iCurrZeitenBaseAddr = 0x2100;
                Fill_Zeiten((ushort)(iCurrZeitenBaseAddr + iCurrHkOffset));
            }
        }

        private void rbnZirkuZeiten_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnZirkuZeiten.Checked)
            {
                //rbnHeizZeiten.Checked = false; rbnWwZeiten.Checked = false;
                GroupBox2200.Text = "Zirkulationsp. Zeit 1";
                GroupBox2202.Text = "Zirkulationsp. Zeit 2";
                GroupBox2204.Text = "Zirkulationsp. Zeit 3";
                GroupBox2206.Text = "Zirkulationsp. Zeit 4";
                iCurrZeitenBaseAddr = 0x2200;
                Fill_Zeiten((ushort)(iCurrZeitenBaseAddr + iCurrHkOffset));
            }
        }

        private void rbnHk1_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnHk1.Checked)
            {
                iCurrHkOffset = 0;
                Fill_Zeiten((ushort)(iCurrZeitenBaseAddr + iCurrHkOffset));
            }
        }

        private void rbnHk2_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnHk2.Checked)
            {
                iCurrHkOffset = 0x1000;
                Fill_Zeiten((ushort)(iCurrZeitenBaseAddr + iCurrHkOffset));
            }
        }

        private void rbnHk3_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnHk3.Checked)
            {
                iCurrHkOffset = 0x2000;
                Fill_Zeiten((ushort)(iCurrZeitenBaseAddr + iCurrHkOffset));
            }
        }


        private void btnCopyZeiten_Click(object sender, EventArgs e)
        {
            Button btnsrc = (Button)sender;
            int src = (int)btnsrc.Tag;
            bool[] dests = new bool[7];

            FCopyZeiten frm = new FCopyZeiten(src, ref dests);
            frm.StartPosition = FormStartPosition.CenterParent;

            DialogResult res = frm.ShowDialog(this);

            if (res != DialogResult.OK) return;

            for (int i = 0; i < 7; i++)
                if (dests[i])
                    CopyZeiten(src, i);
        }

        private void btnClearAllZeiten_Click(object sender, EventArgs e)
        {
            string msg = "Wirklich die Zeiten löschen?";
            if (DialogResult.OK != MessageBox.Show(msg)) return;

            for (int i = 0; i < 56; i++)
                lstTbZeiten[i].Text = "--:--";
        }

        private async void btnSendTimeTable_Click(object sender, EventArgs e)
        {
            await Schreibe_Zeiten((ushort)(iCurrZeitenBaseAddr + iCurrHkOffset));
        }

        private async void btnWriteDay_Click(object sender, EventArgs e)
        {
            Button btnsrc = (Button)sender;
            int day = (int)btnsrc.Tag;

            await Schreibe_Zeiten_Tag(day, (ushort)(iCurrZeitenBaseAddr + iCurrHkOffset));
            await Lese_Zeiten((ushort)(iCurrZeitenBaseAddr + iCurrHkOffset));
            Fill_Zeiten((ushort)(iCurrZeitenBaseAddr + iCurrHkOffset));
        }
        #endregion

        #region tabPage3 Event-Handler Grafik

        #endregion

        #region tabPage4 Event-Handler Statistik
        private void btnRefreshData_Click(object sender, EventArgs e)
        {
            /*  Montag 0-1439
                Dienstag 1440-2879
                Mittwoch 2880-4319
                Donnerstag 4320-5759
                Freitag 5780-7199
                Samstag 7200-8459
                Sonntag 8460-10079  */

            Berechne_alle_Durchschnittwerte();

            //   Erzeugen und Ändern von XML-Dokumenten über das Document Object Model
            /* XmlDocument xmlDoc = new XmlDocument();
                XmlNode rootNode = xmlDoc.CreateElement("buecher");
                xmlDoc.AppendChild(rootNode);
                XmlDeclaration xmlDeclaration = xmlDoc.CreateXmlDeclaration("1.0", "utf-8", "yes");
                xmlDoc.InsertBefore(xmlDeclaration, rootNode);
                xmlDoc.Save("domtest.xml");

             // Node hinzufügen
             XmlNode newNode = xmlDoc.CraeteElement( buch ); 

            // Attribut hinzufügen
              XmlAttribute isbnAttr = xmlDoc.CreateAttribute( isbn );
             isbnAttr.Value = 34345645398 ;
             newNode.Attributes.Append(isbnAttr);

            //  Node hinzufügen
              XmlNode titelNode = xmlDoc.CreateElement( titel );
              titelNode.InnerText = Der Titel des Buches ;
              newNode.AppendChild(titelNode);

              ändern 
             * XmlDocument xmlDoc = new XmlDocument();
              xmlDoc.Load("beispiel.xml");
               XmlNamespaceManager nsManager = new XmlNamespaceManager(xmlDoc.NameTable);
              string xpathquery = "/buecher/buch[attribute::isbn='3453061187']";
               XmlNode theNode = xmlDoc.SelectSingleNode(xpathquery, nsManager);
              theNode.ChildNodes[2].InnerText = "22.90";
              xmlDoc.Save("beispiel.xml");

             * h++p://it-republik.de/dotnet/artikel/XML-mit-.NET-0628.html
             */
        }

        private void chkTcpEnable_CheckedChanged(object sender, EventArgs e)
        {
            SwitchTcp(chkTcpEnable.Checked);
        }

        private void btnLoadOtherCsv_Click(object sender, EventArgs e)
        {
            OpenDataFile();
            InitGraphs();
            tbDataFile.Text = DataFilename;
            tbCurrDataFile.Text = DataFilename_akt;
            Berechne_alle_Durchschnittwerte();
        }

        private void btnLoadCurrCsv_Click(object sender, EventArgs e)
        {
            DataFilename = DataFilename_akt;
            InitGraphs();
            CalcDataGraphs();

            tbDataFile.Text = DataFilename;
            tbCurrDataFile.Text = DataFilename_akt;
            Berechne_alle_Durchschnittwerte();
            this.ResumeLayout();
            plotterDisplayEx1.Refresh();
        }

        private void btnClearErrMsg_Click(object sender, EventArgs e)
        {
            //ShowInfo( String.Empty;
            lbxInfo.Items.Clear();
        }

        private void btnFlushCsv_Click(object sender, EventArgs e)
        {
            mycomm.SendTcpRaw("FlushCsv");
        }
        #endregion

        #region not used
        //private void btn_exit_Click(object sender, EventArgs e)
        //{
        //   if (mySerialPort.IsOpen)
        //      mySerialPort.Close();

        //   save_maxpower();

        //   Application.Exit();
        //   //    Environment.Exit(0); 
        //}

        //public void button5_Click(object sender, EventArgs e)
        //{
        //   Lese_Steuerungen();
        //   int z = 0;

        //   //My_Serial_Input_Buffer[0] = 0x20;
        //   //My_Serial_Input_Buffer[1] = 0xcb;

        //   for (z = 0; z < Device_ID_Array.Count(); z++)

        //      if (!(String.IsNullOrEmpty(Device_ID_Array[z])) & (Device_ID_Array[z].Contains(My_Serial_Input_Buffer[0].ToString() + My_Serial_Input_Buffer[1].ToString())))
        //      {
        //         this.Text = Appname + " - verbunden mit:  " + Device_name_Array[z] + "   Protokoll:  " + Device_protocol_Array[z];
        //         this.toolStripLabel2.BackColor = Color.LightGreen;
        //         Ser_Uebertragungsstatus = 2;
        //         break;
        //      }
        //}

        //private void toolStripButton5_Click(object sender, EventArgs e)
        //{
        //   //if (mySerialPort.IsOpen) 
        //   try { mySerialPort.Close(); }
        //   catch { };
        //   save_maxpower();

        //   Application.Exit();
        //   //    Environment.Exit(0); 
        //}

        //private void button5_Click_1(object sender, EventArgs e)
        //{
        //   XmlDocument ser_config = new XmlDocument();
        //   ser_config.Load(cfg_Datei);
        //   XmlNodeList ser_Liste = ser_config.GetElementsByTagName("Port");

        //   foreach (XmlNode node in ser_Liste)
        //   {
        //      int z = 0;
        //      if (node != null) //kein node in Datei
        //      {
        //         XmlAttribute xmlAttr1 = ser_Liste[z].Attributes["name"];
        //         xmlAttr1.InnerText = this.portName;

        //         XmlNode xmlNode1 = ser_Liste[z].SelectSingleNode("BaudRate");
        //         xmlNode1.InnerText = this.baudRate.ToString();

        //         xmlNode1 = ser_Liste[z].SelectSingleNode("Parity");
        //         xmlNode1.InnerText = this.parity.ToString();

        //         xmlNode1 = ser_Liste[z].SelectSingleNode("DataBits");
        //         xmlNode1.InnerText = this.dataBits.ToString();

        //         xmlNode1 = ser_Liste[z].SelectSingleNode("StopBits");
        //         xmlNode1.InnerText = this.stopBits.ToString();

        //         xmlNode1 = ser_Liste[z].SelectSingleNode("Handshake");
        //         xmlNode1.InnerText = this.handshake.ToString();

        //         z++;
        //      }
        //   }

        //   ser_config.Save(cfg_Datei);
        //}
        #endregion not used


        #endregion control events

    }  // end class
} // end_namespace

