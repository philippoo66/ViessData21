using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

/* Copyright (c) 2008,2009 DI Zimmermann Stephan (stefan.zimmermann@tele2.at)
*   
* Permission is hereby granted, free of charge, to any person obtaining a copy 
* of this software and associated documentation files (the "Software"), to 
* deal in the Software without restriction, including without limitation the 
* rights to use, copy, modify, merge, publish, distribute, sublicense, and/or 
* sell copies of the Software, and to permit persons to whom the Software is 
* furnished to do so, subject to the following conditions:
* 
* The above copyright notice and this permission notice shall be included in 
* all copies or substantial portions of the Software. 
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
* THE SOFTWARE.
*/

namespace GraphLib
{
    public partial class PlotterGraphPaneEx : UserControl
    {
        #region MEMBERS

        public enum LayoutMode
        {
            NORMAL,
            STACKED,
            VERTICAL_ARRANGED,
            TILES_VER,
            TILES_HOR,
        }

        private BackBuffer memGraphics;
        private int ActiveSources = 0;
        private int mit_Y_Skala = 0;
        private int ohne_Y_Sakla = 0;

        public LayoutMode layout = LayoutMode.NORMAL;

        public Color MajorGridColor = Color.DarkGray;
        public Color MinorGridColor = Color.DarkGray;
        public Color GraphColor = Color.DarkGreen;
        public Color BgndColorTop = Color.White;
        public Color BgndColorBot = Color.White;
        public Color LabelColor = Color.White;
        public Color GraphBoxColor = Color.White;
        public bool useDoubleBuffer = false;
        public Font legendFont = new Font(FontFamily.GenericSansSerif, 7.25f);

        public int Skala_in_Min;

        private List<DataSource> sources = new List<DataSource>();

        public SmoothingMode smoothing = SmoothingMode.None;

        public bool hasMovingGrid = true;
        public bool hasBoundingBox = true;

        private Point mousePos = new Point();
        private bool mouseDown = false;

        public float DP_Nummer = 0;
        public float CurrentGraphWith;
        public int source_Samples_Length = 0;

        public string DP_Zeit = "";
        public float starting_idx = 0;
        public float DP_x_start = -10;  // Startwert des Datenpunktes auf der X-Skala
        public float DP_x_end = 100;    // Endwert auf der X-Skala
        public float DP_Bereich = 0;    // Datenwertebereich der X-Achse 
        public float off_X = 0;
        public float CurX_START = 0;
        public float CurX_END = 0;

        public float grid_distance_x = 200;       // grid distance in x_y_data ( draw a vertical line every 200 x_y_data )
        public float grid_off_x = 0;
        public float GraphCaptionLineHeight = 28;

        public float pad_inter = 4;         // padding between graphs
        public float pad_left = 5;         // left padding
        public float pad_right = 5;        // right padding
        public float pad_top = 5;          // top
        public float pad_bot = 5;          // bottom padding
        public float pad_label = 25;        // y-label area width
        public float pad_xlabel = 8;        // x-label padding ( bottom area left and right were x labels are still visible )

        public float[] MinorGridPattern = new float[] { 2, 4 };
        public float[] MajorGridPattern = new float[] { 2, 2 };

        DashStyle MinorGridDashStyle = DashStyle.Custom;
        DashStyle MajorGridDashStyle = DashStyle.Custom;
        public bool MoveMinorGrid = true;

        #endregion

        #region CONSTRUCTOR

        public PlotterGraphPaneEx()
        {
            memGraphics = new BackBuffer();

            InitializeComponent();

            this.Resize += new System.EventHandler(this.OnResizeForm);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(OnMouseDown);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(OnMouseUp);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(OnMouseMove);
            this.MouseWheel += new System.Windows.Forms.MouseEventHandler(OnMouseWheel);
            this.MouseHover += new System.EventHandler(OnMouseHover);


        }

        #endregion

        public List<DataSource> Sources
        {
            get
            {
                return sources;
            }
        }

        private void OnLoadControl(object sender, EventArgs e)
        {
            memGraphics.Init(this.CreateGraphics(), this.ClientRectangle.Width, this.ClientRectangle.Height);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            if (ParentForm == null)
            {
                // paint background when control is used in editor
                base.OnPaintBackground(e);

            }
            else
            {
                // do not repaint background to avoid flickering
            }
        }

        private void OnResizeForm(object sender, System.EventArgs e)
        {
            memGraphics.Init(this.CreateGraphics(), ClientRectangle.Width, ClientRectangle.Height);
            Invalidate();
        }

        private void OnMouseHover(object sender, System.EventArgs e)
        {

        }

        private void OnMouseWheel(object sender, MouseEventArgs e)
        {

        }

        private void OnMouseUp(object sender, MouseEventArgs e)
        {
            if (mouseDown == true)
            {
                mouseDown = false;
                Cursor = Cursors.Default;
            }
        }

        private void OnMouseDown(object sender, MouseEventArgs e)
        {
            if (mouseDown == false)
            {
                mouseDown = true;
                mousePos = e.Location;
                Cursor = Cursors.Hand;
            }
        }

        private void OnMouseMove(object sender, MouseEventArgs e)
        {
            return; //TODO
            if (mouseDown)
            {
                float mouse_dx = mousePos.X - e.Location.X; // Verschiebung Mousezeiger; links positiv
                mousePos = e.Location; // Geht �ber den kopl. Bildschirm nicht Fensterbezogen
                float CurX_Bereich = CurX_END - CurX_START;  // meist Datenpunktbereich
                off_X = mouse_dx * CurX_Bereich / this.Width;

                if (Math.Abs(off_X) > 0) // egal ob links oder rechts bewegt
                {
                    starting_idx += off_X;

                }
            }
            Refresh();
            // Invalidate();
            //    int testc = this.ClientRectangle.Height;
            Graphics g = this.CreateGraphics();

            //rotes senkrechtes Lineal
            g.DrawLine(Pens.Red, Convert.ToInt16(e.Location.X), pad_top, Convert.ToInt16(e.Location.X), this.ClientRectangle.Height - pad_bot);

            //  label1.Text = Convert.ToInt16(e.Location.X).ToString();
            // label2.Text = Convert.ToInt16(e.Location.Y).ToString();


            float mult_x = CurrentGraphWith / DP_Bereich; // Pixel pro Datenpunkt


            float coff_x = (off_X / mult_x - starting_idx);  // Datenpunktnummer

            // linker Bereich ausserhalb der Daten
            if (coff_x < 0)
            {
                DP_Nummer = Math.Abs(coff_x) + (e.Location.X - 35) / mult_x; // im normalen Bereich
            }
            else
            {  // hier nur wenn Bereich irgendwo anf�ngt
                DP_Nummer = (-coff_x + (e.Location.X - 35) / mult_x);
                if (DP_Nummer < 0)
                { DP_Nummer = 0; }
            }

            // rechter Bereich ausserhalb der Daten
            if (coff_x > source_Samples_Length | DP_Nummer > source_Samples_Length)
            {
                DP_Nummer = source_Samples_Length - 1;

            }
            else
            {
            }

            float test1 = DP_Nummer / 1440;
            int Tag = Convert.ToInt16(Math.Floor(test1));
            test1 = (test1 - Tag) * 24;
            int Stunde = Convert.ToInt16(Math.Floor(test1));
            test1 = (test1 - Stunde) * 60;
            int Minute = Convert.ToInt16(Math.Floor(test1));


            string test = "";
            switch (Tag)
            {
                case 0:
                    test = "Mo ";
                    break;

                case 1:
                    test = "Di ";
                    break;
                case 2:
                    test = "Mi ";
                    break;
                case 3:
                    test = "Do ";
                    break;
                case 4:
                    test = "Fr ";
                    break;
                case 5:
                    test = "Sa ";
                    break;
                case 6:
                    test = "So ";
                    break;
            }

            DP_Zeit = test + Stunde.ToString("00") + ":" + Minute.ToString("00");

        }

        public void PaintGraphs(Graphics CurGraphics, float CurWidth, float CurHeight, float OFFX, float OFFY)
        {
            // hier wird noch der kompette Grafikbereich �bergeben (640x434)
            int CurGraphIdx = 0;
            int CurGraphIdx1 = 0;
            int VertTileCount = 1;
            int HorTileCount = 1;

            float curOffY = 0;
            float CurOffX = 0;

            if ((layout == LayoutMode.TILES_VER || layout == LayoutMode.TILES_HOR) && ActiveSources >= 1)
            {
                // calculate number of tiles                                   
                if (layout == LayoutMode.TILES_VER)
                {
                    VertTileCount = 1;
                    HorTileCount = 1;
                    while (true)
                    {
                        if (VertTileCount * HorTileCount >= ActiveSources) break;
                        VertTileCount++;
                        if (VertTileCount * HorTileCount >= ActiveSources) break;
                        HorTileCount++;
                    }
                }
                else if (layout == LayoutMode.TILES_HOR)
                {
                    VertTileCount = 1;
                    HorTileCount = 1;
                    while (true)
                    {
                        if (VertTileCount * HorTileCount >= ActiveSources) break;
                        HorTileCount++;
                        if (VertTileCount * HorTileCount >= ActiveSources) break;
                        VertTileCount++;
                    }
                }
            }

            foreach (DataSource source in sources)
            {
                source.Cur_YD0 = source.YD0;
                source.Cur_YD1 = source.YD1;

                // Maximale H�he des Anzeigenbereichs
                source.CurGraphHeight = CurHeight;

                // maximale Weite des Anzeigenbereichs
                if (mit_Y_Skala == 0)
                {
                    source.CurGraphWidth = CurWidth - pad_left - pad_right; // R�nder - zumindest 1 Skale
                }
                else
                {
                    source.CurGraphWidth = CurWidth - pad_left - pad_label - pad_right; // R�nder - zumindest 1 Skale
                }
                CurrentGraphWith = source.CurGraphWidth;
                if (source.yFlip) // umschaltung des Bereiches ??
                {
                    DP_Bereich = DP_x_end - DP_x_start;
                }
                else
                {
                    DP_Bereich = DP_x_end - DP_x_start;
                }

                CurX_START = DP_x_start;
                CurX_END = DP_x_end;

                if (source.AutoScaleX && source.Samples.Length > 0)
                {
                    CurX_START = source.XMin - source.XAutoScaleOffset;
                    CurX_END = source.XMax + source.XAutoScaleOffset;
                    DP_Bereich = CurX_END - CurX_START;
                }

                if (source.Active)
                {
                    if (source.AutoScaleY == true)
                    {
                        int idx_start = -1;
                        int idx_stop = -1;
                        float ymin = 0.0f;
                        float ymax = 0.0f;
                        float ymin_range = 0;
                        float ymax_range = 0;

                        int DownSample = source.Downsampling;
                        cPoint[] data = source.Samples;
                        float mult_y = source.CurGraphHeight / source.DY;
                        float mult_x = source.CurGraphWidth / DP_Bereich;
                        float coff_x = off_X - starting_idx * mult_x;

                        if (source.AutoScaleX)
                        {
                            coff_x = off_X;
                        }

                        for (int i = 0; i < data.Length - 1; i += DownSample)
                        {
                            float x = data[i].x * mult_x + coff_x;

                            if (data[i].y > ymax) ymax = data[i].y;
                            if (data[i].y < ymin) ymin = data[i].y;

                            if (x > 0 && x < (source.CurGraphWidth))
                            {
                                if (idx_start == -1) idx_start = i;
                                idx_stop = i;

                                if (data[i].y > ymax_range) ymax_range = data[i].y;
                                if (data[i].y < ymin_range) ymin_range = data[i].y;
                            }
                        }

                        if (idx_start >= 0 && idx_stop >= 0)
                        {
                            float data_range = ymax - ymin;              // this is range in the data
                            float delta_range = ymax_range - ymin_range; // this is the visible data range -> might be smaller

                            source.Cur_YD0 = ymin_range;
                            source.Cur_YD1 = ymax_range;
                        }
                    }  //end  if(source.AutoScaleY == true)

                    if (layout == LayoutMode.VERTICAL_ARRANGED && ActiveSources >= 1)
                    {
                        if (ActiveSources > 1)
                        {
                            source.CurGraphHeight = (float)(CurHeight - pad_top - pad_bot) / ActiveSources - GraphCaptionLineHeight;
                            float Diff = ((ActiveSources - 1) * pad_inter) / ActiveSources;
                            source.CurGraphHeight -= Diff;
                        }
                        else
                        {
                            source.CurGraphHeight = (float)(CurHeight - pad_top - pad_bot) - GraphCaptionLineHeight;
                        }
                    }
                    else if (layout == LayoutMode.STACKED && ActiveSources >= 1)
                    {
                        if (ActiveSources > 1)
                        {
                            source.CurGraphHeight = (float)(CurHeight - pad_top - pad_bot) / ActiveSources - GraphCaptionLineHeight;
                        }
                        else
                        {
                            source.CurGraphHeight = (float)(CurHeight - pad_top - pad_bot) - GraphCaptionLineHeight;
                        }
                    }
                    else if ((layout == LayoutMode.TILES_VER || layout == LayoutMode.TILES_HOR) && ActiveSources >= 1)
                    {
                        if (ActiveSources > 1)
                        {
                            source.CurGraphHeight = (float)(CurHeight - pad_top - pad_bot) / VertTileCount - GraphCaptionLineHeight;
                            float Diff = ((ActiveSources - 1) * pad_inter) / VertTileCount;
                            source.CurGraphHeight -= Diff;
                            source.CurGraphWidth = (float)(CurWidth - pad_left - pad_right) / HorTileCount - pad_label;
                        }
                        else
                        {
                            source.CurGraphHeight = (float)(CurHeight - pad_top - pad_bot) - GraphCaptionLineHeight;
                        }
                    }
                    else
                    {
                        source.CurGraphHeight = (float)(CurHeight - pad_top - pad_bot) - GraphCaptionLineHeight;
                        //CHW hier wird die Breite der graphfenster berechnet. wenn ActiveSources-2 dann rechter Rand nicht da 
                        if ((ActiveSources - ohne_Y_Sakla) > 0)
                        {
                            source.CurGraphWidth = CurWidth - pad_left - pad_label * (ActiveSources - ohne_Y_Sakla) - pad_right;
                        }
                        else
                        {

                        }
                    }

                    if (source.yFlip)
                    {
                        source.DY = source.Cur_YD0 - source.Cur_YD1;

                        if (DP_Bereich != 0 && source.DY != 0)
                        {
                            source.off_Y = -source.Cur_YD1 * source.CurGraphHeight / source.DY;
                            off_X = -CurX_START * source.CurGraphWidth / DP_Bereich;
                        }
                    }
                    else
                    {
                        source.DY = source.Cur_YD1 - source.Cur_YD0;

                        if (DP_Bereich != 0 && source.DY != 0)
                        {
                            source.off_Y = -source.Cur_YD0 * source.CurGraphHeight / source.DY;
                            off_X = -CurX_START * source.CurGraphWidth / DP_Bereich;
                        }
                    }

                    if ((layout == LayoutMode.TILES_VER || layout == LayoutMode.TILES_HOR))
                    {
                        if (ActiveSources > 1)
                        {
                            if (layout == LayoutMode.TILES_VER)
                            {
                                // TODO: calc curOffX and CurrOffY for CurGraphIdx!!
                                int CurIdxY = CurGraphIdx % VertTileCount;
                                int CurIdxX = CurGraphIdx / VertTileCount;

                                curOffY = OFFY + pad_top + CurIdxY * (source.CurGraphHeight + GraphCaptionLineHeight);
                                CurOffX = OFFX + pad_label + pad_left + CurIdxX * (pad_label + source.CurGraphWidth);
                            }
                            else
                            {
                                int CurIdxX = CurGraphIdx % HorTileCount;
                                int CurIdxY = CurGraphIdx / HorTileCount;

                                curOffY = OFFY + pad_top + CurIdxY * (source.CurGraphHeight + GraphCaptionLineHeight);
                                CurOffX = OFFX + pad_label + pad_left + CurIdxX * (pad_label + source.CurGraphWidth);
                            }

                        }
                        else
                        {
                            // one active source
                            curOffY = OFFY + pad_top + CurGraphIdx * (source.CurGraphHeight + GraphCaptionLineHeight);
                            CurOffX = OFFX + pad_left + pad_label;
                        }
                    }
                    else if (layout == LayoutMode.VERTICAL_ARRANGED)
                    {
                        if (ActiveSources > 1)
                        {
                            curOffY = OFFY + pad_top + CurGraphIdx * (source.CurGraphHeight + GraphCaptionLineHeight + pad_inter);
                        }
                        else
                        {
                            curOffY = OFFY + pad_top + CurGraphIdx * (source.CurGraphHeight + GraphCaptionLineHeight);
                        }

                        CurOffX = OFFX + pad_left + pad_label;
                    }
                    else if (layout == LayoutMode.STACKED)  // alles untereinander
                    {
                        if (ActiveSources > 1)
                        {
                            curOffY = OFFY + pad_top + CurGraphIdx * (source.CurGraphHeight);
                        }
                        else
                        {
                            curOffY = OFFY + pad_top + CurGraphIdx * (source.CurGraphHeight);
                        }

                        CurOffX = OFFX + pad_left + pad_label;
                    }
                    else
                    {
                        // CurOffX = Anfangspunkt fuer die Graphen in x //CHW
                        CurOffX = OFFX + pad_left + pad_label * (ActiveSources - ohne_Y_Sakla);
                        curOffY = OFFY + pad_top;
                    }

                    DrawGrid(CurGraphics, source, CurOffX, curOffY + GraphCaptionLineHeight / 2);

                    List<int> marker_pos = DrawGraphCurve(CurGraphics, source, CurOffX, curOffY + GraphCaptionLineHeight / 2);


                    if (layout == LayoutMode.NORMAL)
                    {
                        //Namen der Graphen         
                        DrawGraphCaption(CurGraphics, source, marker_pos, CurOffX + CurGraphIdx * (50 + pad_label), curOffY);

                        if (CurGraphIdx == 0)
                        {
                            DrawXLabels(CurGraphics, source, marker_pos, CurOffX, curOffY);  // x-Skalenwerte
                        }

                        if (source.Visible_y_Skala)
                        {
                            // Y Skalenwerte
                            DrawYLabels(CurGraphics, source, marker_pos, CurOffX + pad_label * (CurGraphIdx1 - mit_Y_Skala + 1), curOffY);
                            CurGraphIdx1++;
                        }
                    }
                    else
                    {
                        DrawGraphCaption(CurGraphics, source, marker_pos, CurOffX, curOffY);

                        DrawXLabels(CurGraphics, source, marker_pos, CurOffX, curOffY);

                        DrawYLabels(CurGraphics, source, marker_pos, CurOffX, curOffY);
                    }

                    if (hasBoundingBox)
                    {
                        // Umrandung mit wesser Linie
                        DrawGraphBox(CurGraphics, source, CurOffX, curOffY, GraphCaptionLineHeight);

                    }
                    CurGraphIdx++;
                }
            }
        }

        private void PaintStackedGraphs(Graphics CurGraphics, float CurWidth, float CurHeigth, float OFFX, float OFFY)
        {
            int CurGraphIdx = 0;
            float curOffY = 0;
            float CurOffX = 0;

            foreach (DataSource source in sources)
            {
                source.Cur_YD0 = source.YD0;
                source.Cur_YD1 = source.YD1;

                source.CurGraphHeight = CurHeigth;
                source.CurGraphWidth = CurWidth - pad_left - pad_label - pad_right;

                DP_Bereich = DP_x_end - DP_x_start;

                if (source.AutoScaleX && source.Samples.Length > 0)
                {
                    DP_Bereich = source.Samples[source.Samples.Length - 1].x;
                }

                CurX_START = DP_x_start;
                CurX_END = DP_x_end;

                if (source.Active)
                {
                    if (source.AutoScaleY == true)
                    {
                        int idx_start = -1;
                        int idx_stop = -1;
                        float ymin = 0.0f;
                        float ymax = 0.0f;
                        float ymin_range = 0;
                        float ymax_range = 0;

                        int DownSample = source.Downsampling;
                        cPoint[] data = source.Samples;
                        float mult_y = source.CurGraphHeight / source.DY;
                        float mult_x = source.CurGraphWidth / DP_Bereich;
                        float coff_x = off_X - starting_idx * mult_x;

                        if (source.AutoScaleX)
                        {
                            coff_x = off_X;     // avoid dragging in x-autoscale mode
                        }

                        for (int i = 0; i < data.Length - 1; i += DownSample)
                        {
                            float x = data[i].x * mult_x + coff_x;

                            if (data[i].y > ymax) ymax = data[i].y;
                            if (data[i].y < ymin) ymin = data[i].y;

                            if (x > 0 && x < (source.CurGraphWidth))
                            {
                                if (idx_start == -1) idx_start = i;
                                idx_stop = i;

                                if (data[i].y > ymax_range) ymax_range = data[i].y;
                                if (data[i].y < ymin_range) ymin_range = data[i].y;
                            }
                        }

                        if (idx_start >= 0 && idx_stop >= 0)
                        {
                            float data_range = ymax - ymin;              // this is range in the data
                            float delta_range = ymax_range - ymin_range; // this is the visible data range -> might be smaller

                            source.Cur_YD0 = ymin_range;
                            source.Cur_YD1 = ymax_range;
                        }
                    }

                    if (ActiveSources > 1)
                    {
                        source.CurGraphHeight = (float)(CurHeigth - GraphCaptionLineHeight - pad_top - pad_bot) / ActiveSources;
                    }
                    else
                    {
                        source.CurGraphHeight = (float)(CurHeigth - GraphCaptionLineHeight - pad_top - pad_bot);
                    }

                    if (source.yFlip)
                    {
                        source.DY = source.Cur_YD0 - source.Cur_YD1;

                        if (DP_Bereich != 0 && source.DY != 0)
                        {
                            source.off_Y = -source.Cur_YD1 * source.CurGraphHeight / source.DY;
                            off_X = -CurX_START * source.CurGraphWidth / DP_Bereich;
                        }
                    }
                    else
                    {
                        source.DY = source.Cur_YD1 - source.Cur_YD0;

                        if (DP_Bereich != 0 && source.DY != 0)
                        {
                            source.off_Y = -source.Cur_YD0 * source.CurGraphHeight / source.DY;
                            off_X = -CurX_START * source.CurGraphWidth / DP_Bereich;
                        }
                    }

                    if (ActiveSources > 1)
                    {
                        curOffY = OFFY + pad_top + CurGraphIdx * (source.CurGraphHeight);
                    }
                    else
                    {
                        curOffY = OFFY + pad_top + CurGraphIdx * (source.CurGraphHeight);
                    }

                    CurOffX = OFFX + pad_left + pad_label;

                    DrawGrid(CurGraphics, source, CurOffX, curOffY + GraphCaptionLineHeight / 2);

                    List<int> marker_pos = DrawGraphCurve(CurGraphics, source, CurOffX, curOffY + GraphCaptionLineHeight / 2);

                    DrawGraphCaption(CurGraphics, source, marker_pos, CurOffX + CurGraphIdx * (10 + pad_label), pad_top);

                    DrawYLabels(CurGraphics, source, marker_pos, CurOffX, curOffY);

                    if (hasBoundingBox && CurGraphIdx == ActiveSources - 1)
                    {
                        DrawGraphBox(CurGraphics, source.CurGraphWidth, CurHeigth - pad_top - GraphCaptionLineHeight, pad_left + pad_label, pad_top, GraphCaptionLineHeight);
                    }

                    if (CurGraphIdx == ActiveSources - 1)
                    {
                        DrawXLabels(CurGraphics, source, marker_pos, pad_left, Height - pad_top - GraphCaptionLineHeight - source.CurGraphHeight);
                    }

                    CurGraphIdx++;
                }


            }
        }

        public void PaintControl(Graphics CurGraphics, float CurWidth, float CurHeight, float OffX, float OffY, bool PaintBgnd)
        {
            if (PaintBgnd)
            {
                DrawBackground(CurGraphics, CurWidth, CurHeight, OffX, OffY);
            }

            ActiveSources = 0;

            foreach (DataSource source in sources)
            {
                if (source.Samples != null &&
                    source.Samples.Length > 0 &&
                    source.Active == true)
                {
                    ActiveSources++;
                }
            }

            ohne_Y_Sakla = 0;

            foreach (DataSource source in sources)
            {
                if (source.Samples != null &&
                    source.Samples.Length > 0 &&
                    source.Visible_Y_Skala == false &&
                    source.Active == true)
                {
                    ohne_Y_Sakla++;
                }
            }
            mit_Y_Skala = ActiveSources - ohne_Y_Sakla;


            switch (layout)
            {
                case LayoutMode.NORMAL:

                case LayoutMode.TILES_HOR:
                case LayoutMode.TILES_VER:
                case LayoutMode.VERTICAL_ARRANGED:


                    PaintGraphs(CurGraphics, CurWidth, CurHeight, OffX, OffY);

                    break;

                case LayoutMode.STACKED:

                    // alles untereinander
                    PaintStackedGraphs(CurGraphics, CurWidth, CurHeight, OffX, OffY);

                    break;
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            try
            {
                if (ParentForm != null)
                {
                    Graphics CurGraphics = e.Graphics;

                    if (memGraphics.g != null && useDoubleBuffer == true)
                    {
                        CurGraphics = memGraphics.g;
                    }

                    CurGraphics.SmoothingMode = smoothing;

                    PaintControl(CurGraphics, this.Width, this.Height, 0, 0, true);  // CurWidth=this.With CurHeight=this.Height

                    if (memGraphics.g != null && useDoubleBuffer == true)
                    {
                        memGraphics.Render(e.Graphics);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.Write("exception : " + ex.Message);
            }

            base.OnPaint(e);
        }

        private void DrawBackground(Graphics g, float CurWidth, float CurHeight, float CurOFFX, float CurOFFY)
        {
            Rectangle rbgn = new Rectangle((int)CurOFFX, (int)CurOFFY, (int)CurWidth, (int)CurHeight);

            if (BgndColorTop != BgndColorBot)
            {
                using (LinearGradientBrush lb1 = new LinearGradientBrush(new Point((int)0, (int)0),
                                                                         new Point((int)0, (int)(CurHeight)),
                                                                         BgndColorTop,
                                                                         BgndColorBot))
                {
                    g.FillRectangle(lb1, rbgn);
                }
            }
            else
            {
                using (SolidBrush sb1 = new SolidBrush(BgndColorTop))
                {
                    g.FillRectangle(sb1, rbgn);
                }
            }
        }

        private void DrawGrid(Graphics g, DataSource source, float CurrOffX, float CurOffY)
        {
            int Idx = 0;
            float mult_x = source.CurGraphWidth / DP_Bereich;
            float coff_x = off_X - starting_idx * mult_x;

            if (source.AutoScaleX)
            {
                coff_x = off_X;     // avoid dragging in x-autoscale mode
            }

            Color CurGridColor = MajorGridColor;
            Color CurMinGridClor = MinorGridColor;

            if (layout == LayoutMode.NORMAL && source.AutoScaleY)
            {
                CurGridColor = source.GraphColor;
                CurMinGridClor = source.GraphColor;
            }

            using (Pen minorGridPen = new Pen(CurMinGridClor))
            {
                minorGridPen.DashPattern = MinorGridPattern;
                minorGridPen.DashStyle = MinorGridDashStyle;


                using (Pen p2 = new Pen(CurGridColor))
                {
                    p2.DashPattern = MajorGridPattern;
                    p2.DashStyle = MajorGridDashStyle;

                    if (DP_Bereich != 0)
                    {
                        while (true)
                        {
                            float x = Idx * grid_distance_x * source.CurGraphWidth / DP_Bereich + grid_off_x * source.CurGraphWidth / DP_Bereich;

                            if (MoveMinorGrid)
                            {
                                x += coff_x;
                            }

                            if (x > 0 && x < source.CurGraphWidth) // senktrechte Linien vom Grid
                            {
                                g.DrawLine(minorGridPen, new Point((int)(x + CurrOffX + 4.8f), (int)(CurOffY)),
                                                         new Point((int)(x + CurrOffX + 4.8f), (int)(CurOffY + source.CurGraphHeight)));
                            }
                            if (x > source.CurGraphWidth)
                            {
                                break;
                            }

                            Idx++;
                        }
                    }

                    if (source.DY != 0)
                    {
                        float y0 = (float)(source.grid_off_y * source.CurGraphHeight / source.DY + source.off_Y);

                        // draw horizontal zero grid lines
                        g.DrawLine(p2, new Point((int)CurrOffX, (int)(CurOffY + y0 + 0.5f)), new Point((int)(CurrOffX + source.CurGraphWidth + 0.5f), (int)(CurOffY + y0 + 0.5f)));

                        // draw horizontal grid lines
                        for (Idx = (int)(source.grid_off_y); Idx > (int)(source.YD0); Idx -= (int)source.grid_distance_y)
                        {
                            float y = (float)(Idx * source.CurGraphHeight) / source.DY + source.off_Y;

                            if (y >= 0 && y < source.CurGraphHeight)
                            {
                                g.DrawLine(minorGridPen,
                                            new Point((int)CurrOffX, (int)(CurOffY + y + 0.5f)),
                                            new Point((int)(CurrOffX + source.CurGraphWidth + 0.5f), (int)(0.5f + CurOffY + y)));
                            }
                        }

                        // draw horizontal grid lines
                        for (Idx = (int)(source.grid_off_y); Idx < (int)(source.YD1); Idx += (int)source.grid_distance_y)
                        {
                            float y = (float)Idx * source.CurGraphHeight / source.DY + source.off_Y;

                            if (y >= 0 && y < source.CurGraphHeight)
                            {
                                g.DrawLine(minorGridPen,
                                           new Point((int)CurrOffX, (int)(CurOffY + y + 0.5f)),
                                           new Point((int)(CurrOffX + source.CurGraphWidth + 0.5f), (int)(0.5f + CurOffY + y)));
                            }
                        }
                    }
                }
            }
        }

        private List<int> DrawGraphCurve(Graphics g, DataSource source, float offset_x, float offset_y)
        {
            source_Samples_Length = source.Samples.Length;
            List<int> marker_positions = new List<int>();

            if (DP_Bereich != 0 && source.DY != 0)
            {
                List<Point> ps = new List<Point>();

                if (source.Samples != null && source.Samples.Length > 1)
                {

                    int DownSample = source.Downsampling;
                    cPoint[] data = source.Samples;
                    float mult_y = source.CurGraphHeight / source.DY;
                    float mult_x = source.CurGraphWidth / DP_Bereich;
                    float coff_x = off_X - starting_idx * mult_x;

                    if (source.AutoScaleX)
                    {
                        coff_x = off_X;     // avoid dragging in x-autoscale mode
                    }

                    for (int i = 0; i < data.Length - 1; i += DownSample)
                    {
                        float x = data[i].x * mult_x + coff_x;
                        float y = data[i].y * mult_y + source.off_Y;

                        int xi = (int)(data[i].x);

                        if (xi % grid_distance_x == 0)
                        {
                            if (x >= (0 - pad_xlabel) && x <= (source.CurGraphWidth + pad_xlabel))
                            {
                                marker_positions.Add(i);
                            }
                        }

                        if (x > 0 && x < (source.CurGraphWidth))
                        {
                            ps.Add(new Point((int)(x + offset_x + 4.8f), (int)(y + offset_y + 0.5f)));
                        }
                        else if (x > source.CurGraphWidth)
                        {
                            break;
                        }
                    }

                    using (Pen p = new Pen(source.GraphColor))
                    {
                        if (ps.Count > 0)
                        {
                            g.DrawLines(p, ps.ToArray());
                        }
                    }
                }
            }
            return marker_positions;
        }

        private void DrawGraphCaption(Graphics g, DataSource source, List<int> marker_pos, float offset_x, float offset_y)
        {
            using (Brush b = new SolidBrush(source.GraphColor))
            {
                using (Pen pen = new Pen(b))
                {
                    pen.DashPattern = new float[] { 2, 2 };

                    g.DrawString(source.Name, legendFont, b, new PointF(offset_x + 12, offset_y + 2));
                    g.DrawString(source.Samples[Convert.ToInt16(DP_Nummer)].y.ToString("0.0"), legendFont, b, new PointF(offset_x + 12, offset_y + 12));


                }
            }
        }

        private void DrawXLabels(Graphics g, DataSource source, List<int> marker_pos, float offset_x, float offset_y)
        {
            Color XLabColor = source.GraphColor;

            if (layout == LayoutMode.NORMAL || layout == LayoutMode.STACKED)
            {
                XLabColor = GraphBoxColor;
            }

            using (Brush b = new SolidBrush(XLabColor))
            {
                using (Pen pen = new Pen(b))
                {
                    pen.DashPattern = new float[] { 2, 2 };

                    if (DP_Bereich != 0 && source.DY != 0)
                    {
                        if (source.Samples != null && source.Samples.Length > 1)
                        {
                            cPoint[] data = source.Samples;

                            float mult_y = source.CurGraphHeight / source.DY;
                            float mult_x = source.CurGraphWidth / DP_Bereich;

                            float coff_x = off_X - starting_idx * mult_x;

                            if (source.AutoScaleX)
                            {
                                coff_x = off_X;     // avoid dragging in x-autoscale mode
                            }

                            foreach (int i in marker_pos)
                            {
                                int xi = (int)(data[i].x);

                                if (xi % grid_distance_x == 0)
                                {
                                    float x = data[i].x * mult_x + coff_x;

                                    String value = "" + data[i].x;

                                    if (source.OnRenderXAxisLabel != null)
                                    {
                                        value = source.OnRenderXAxisLabel(source, i);
                                    }

                                    if (MoveMinorGrid == false)
                                    {
                                        g.DrawLine(pen, x, GraphCaptionLineHeight + offset_y + source.CurGraphHeight - 14, x, GraphCaptionLineHeight + offset_y + source.CurGraphHeight);
                                        g.DrawString(value, legendFont, b, new PointF((int)(0.5f + x + offset_x + 4), GraphCaptionLineHeight + offset_y + source.CurGraphHeight - 14));
                                    }
                                    else
                                    {
                                        SizeF dim = g.MeasureString(value, legendFont);
                                        // X-Achsenbeschriftung value ist der Wert der Beschriftung, x=aktuelle Pos
                                        g.DrawString(value, legendFont, b, new PointF((int)(0.5f + x + offset_x + 4 - dim.Width / 2), GraphCaptionLineHeight + offset_y + source.CurGraphHeight - 14));
                                        // Uhrzeit des Datenpunktes als Text links oben
                                        g.DrawString(DP_Zeit, legendFont, b, new PointF(offset_x + 1, offset_y + 30));  //GraphCaptionLineHeight + offset_y + source.CurGraphHeight - 345

                                    }
                                }
                            }
                        }
                    }


                }
            }
        }

        private void DrawYLabels(Graphics g, DataSource source, List<int> marker_pos, float offset_x, float offset_y)
        {
            using (Brush b = new SolidBrush(source.GraphColor))
            {
                using (Pen pen = new Pen(b))
                {
                    pen.DashPattern = new float[] { 2, 2 };

                    // draw labels for horizontal lines
                    if (source.DY != 0)
                    {
                        float Idx = 0;

                        float y0 = (float)(source.grid_off_y * source.CurGraphHeight / source.DY + source.off_Y);

                        String value = "" + Idx;

                        if (source.OnRenderYAxisLabel != null)
                        {
                            value = source.OnRenderYAxisLabel(source, Idx);
                        }

                        SizeF dim = g.MeasureString(value, legendFont);
                        g.DrawString(value, legendFont, b, new PointF((int)offset_x - dim.Width, (int)(offset_y + y0 + 0.5f + dim.Height / 2)));

                        float GridDistY = source.grid_distance_y;

                        if (source.AutoScaleY)
                        {
                            // calculate a matching grid distance                            
                            GridDistY = -Utilities.MostSignificantDigit(source.DY);

                            if (GridDistY == 0)
                            {
                                GridDistY = source.grid_distance_y;

                            }
                        }

                        for (Idx = (source.grid_off_y); Idx > (source.Cur_YD0); Idx -= GridDistY)
                        {
                            if (Idx != 0)
                            {
                                float y1 = (float)((Idx) * source.CurGraphHeight) / source.DY + source.off_Y;

                                value = "" + (Idx);

                                if (source.OnRenderYAxisLabel != null)
                                {
                                    value = source.OnRenderYAxisLabel(source, Idx);
                                }

                                dim = g.MeasureString(value, legendFont);
                                g.DrawString(value, legendFont, b, new PointF((int)offset_x - dim.Width, (int)(offset_y + y1 + 0.5f + dim.Height / 2)));
                            }
                        }

                        for (Idx = (source.grid_off_y); Idx < (source.Cur_YD1); Idx += GridDistY)
                        {
                            if (Idx != 0)
                            {
                                float y2 = (float)((Idx) * source.CurGraphHeight) / source.DY + source.off_Y;

                                value = "" + (Idx);

                                if (source.OnRenderYAxisLabel != null)
                                {
                                    value = source.OnRenderYAxisLabel(source, Idx);
                                }

                                dim = g.MeasureString(value, legendFont);
                                g.DrawString(value, legendFont, b, new PointF((int)offset_x - dim.Width, (int)(offset_y + y2 + 0.5f + dim.Height / 2)));
                            }
                        }
                    }
                }
            }
        }

        private void DrawGraphBox(Graphics g, float w, float h,
                                    float offset_x,
                                     float offset_y,
                                    float GraphCaptionLineHeight)
        {
            using (Pen p2 = new Pen(GraphBoxColor))
            {
                g.DrawLine(p2, new Point((int)(offset_x + 0.5f), (int)(offset_y + 0.5f)),
                              new Point((int)(offset_x + w - 0.5f), (int)(offset_y + 0.5f)));

                g.DrawLine(p2, new Point((int)(offset_x + w - 0.5f), (int)(offset_y + 0.5f)),
                             new Point((int)(offset_x + w - 0.5f), (int)(offset_y + h + 0.5f)));

                g.DrawLine(p2, new Point((int)(offset_x + w - 0.5f), (int)(offset_y + h + 0.5f)),
                           new Point((int)(offset_x + 0.5f), (int)(offset_y + h + 0.5f)));

                g.DrawLine(p2, new Point((int)(offset_x + 0.5f), (int)(offset_y + h + 0.5f)),
                          new Point((int)(offset_x + 0.5f), (int)(offset_y + 0.5f)));
            }
        }

        private void DrawGraphBox(Graphics g, DataSource source,
                                    float offset_x,
                                     float offset_y,
                                    float GraphCaptionLineHeight)
        {
            using (Pen p2 = new Pen(GraphBoxColor))
            {
                // Linie oben
                g.DrawLine(p2, new Point((int)(offset_x + 0.5f), (int)(offset_y + 0.5f)),
                              new Point((int)(offset_x + source.CurGraphWidth - 0.5f), (int)(offset_y + 0.5f)));

                // Linie rechts
                g.DrawLine(p2, new Point((int)(offset_x + source.CurGraphWidth - 0.5f), (int)(offset_y + 0.5f)),
                             new Point((int)(offset_x + source.CurGraphWidth - 0.5f), (int)(offset_y + source.CurGraphHeight + GraphCaptionLineHeight / 2 + 0.5f)));

                // Linie unten 
                g.DrawLine(p2, new Point((int)(offset_x + source.CurGraphWidth - 0.5f), (int)(offset_y + source.CurGraphHeight + GraphCaptionLineHeight / 2 + 0.5f)),
                           new Point((int)(offset_x + 0.5f), (int)(offset_y + source.CurGraphHeight + GraphCaptionLineHeight / 2 + 0.5f)));

                // Linie links
                g.DrawLine(p2, new Point((int)(offset_x + 0.5f), (int)(offset_y + source.CurGraphHeight + GraphCaptionLineHeight / 2 + 0.5f)),
                          new Point((int)(offset_x + 0.5f), (int)(offset_y + 0.5f)));
            }
        }



    }
}
