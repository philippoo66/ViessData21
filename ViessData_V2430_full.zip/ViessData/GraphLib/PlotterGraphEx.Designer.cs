namespace GraphLib
{
    partial class PlotterDisplayEx
    {
       
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

      

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.selectGraphsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ShowPrintViewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gPane = new GraphLib.PlotterGraphPaneEx();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.selectGraphsToolStripMenuItem,
            this.toolStripSeparator1,
            this.ShowPrintViewToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(133, 54);
            // 
            // selectGraphsToolStripMenuItem
            // 
            this.selectGraphsToolStripMenuItem.Name = "selectGraphsToolStripMenuItem";
            this.selectGraphsToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.selectGraphsToolStripMenuItem.Text = "Options";
            this.selectGraphsToolStripMenuItem.Click += new System.EventHandler(this.selectGraphsToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(129, 6);
            // 
            // ShowPrintViewToolStripMenuItem
            // 
            this.ShowPrintViewToolStripMenuItem.Name = "ShowPrintViewToolStripMenuItem";
            this.ShowPrintViewToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.ShowPrintViewToolStripMenuItem.Text = "Print View";
            this.ShowPrintViewToolStripMenuItem.Click += new System.EventHandler(this.ShowPrintViewToolStripMenuItem_Click);
            // 
            // gPane
            // 
            this.gPane.AutoSize = true;
            this.gPane.BackColor = System.Drawing.Color.Chartreuse;
            this.gPane.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gPane.Location = new System.Drawing.Point(0, 0);
            this.gPane.Name = "gPane";
            this.gPane.Size = new System.Drawing.Size(291, 263);
            this.gPane.TabIndex = 1;
            // 
            // PlotterDisplayEx
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.gPane);
            this.Name = "PlotterDisplayEx";
            this.Size = new System.Drawing.Size(291, 263);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem selectGraphsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private PlotterGraphPaneEx gPane;
        private System.Windows.Forms.ToolStripMenuItem ShowPrintViewToolStripMenuItem;

    }
}
