using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.ComponentModel.Design;
using System.Drawing.Drawing2D;


/* Copyright (c) 2008,2009 DI Zimmermann Stephan (stefan.zimmermann@tele2.at)
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy 
 * of this software and associated documentation files (the "Software"), to 
 * deal in the Software without restriction, including without limitation the 
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or 
 * sell copies of the Software, and to permit persons to whom the Software is 
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in 
 * all copies or substantial portions of the Software. 
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
 * THE SOFTWARE.
 */


namespace GraphLib
{
    public partial class PlotterDisplayEx : UserControl
    {
        #region MEMBERS

        delegate void InvokeVoidFuncDelegate();

        PlotterGraphSelectCurvesForm GraphPropertiesForm = null;
        PrintPreviewForm printPreviewForm = null;





        private bool paused = false;
        private bool isRunning = false;

        #endregion

        #region CONSTRUCTOR

        public PlotterDisplayEx()
        {
            InitializeComponent();

        }

        void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            String text = e.ClickedItem.Text;
            foreach (DataSource s in gPane.Sources)
            {
                if (s.Name == text)
                {
                    s.Active ^= true;
                    gPane.Invalidate();
                    break;
                }
            }
        }

        #endregion

        #region PROPERTIES

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Editor(typeof(System.ComponentModel.Design.CollectionEditor),
               typeof(System.Drawing.Design.UITypeEditor))]
        public List<DataSource> DataSources
        {
            get { return gPane.Sources; }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Editor(typeof(System.ComponentModel.Design.CollectionEditor),
                typeof(System.Drawing.Design.UITypeEditor))]
        public PlotterGraphPaneEx.LayoutMode PanelLayout
        {
            get { return gPane.layout; }
            set { gPane.layout = value; }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Editor(typeof(System.ComponentModel.Design.CollectionEditor),
                typeof(System.Drawing.Design.UITypeEditor))]
        public SmoothingMode Smoothing
        {
            get { return gPane.smoothing; }
            set { gPane.smoothing = value; }
        }



        [Category("Playback")]
        [DefaultValue(typeof(bool), "true")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public bool ShowMovingGrid
        {
            get { return gPane.hasMovingGrid; }
            set { gPane.hasMovingGrid = value; }
        }


        [Category("Properties")]
        [DefaultValue(typeof(Color), "")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public Color BackgroundColorTop
        {
            get { return gPane.BgndColorTop; }
            set { gPane.BgndColorTop = value; }
        }

        [Category("Properties")]
        [DefaultValue(typeof(Color), "")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public Color BackgroundColorBot
        {
            get { return gPane.BgndColorBot; }
            set { gPane.BgndColorBot = value; }
        }

        [Category("Properties")]
        [DefaultValue(typeof(Color), "")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public Color DashedGridColor
        {
            get { return gPane.MinorGridColor; }
            set { gPane.MinorGridColor = value; }
        }

        [Category("Properties")]
        [DefaultValue(typeof(Color), "")]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public Color SolidGridColor
        {
            get { return gPane.MajorGridColor; }
            set { gPane.MajorGridColor = value; }
        }


        public bool DoubleBuffering
        {
            get { return gPane.useDoubleBuffer; }
            set { gPane.useDoubleBuffer = value; }
        }

        public int Skala_in_Min
        {
            get { return gPane.Skala_in_Min; }
            set { gPane.Skala_in_Min = value; }
        }


        #endregion

        #region PUBLIC METHODS

        public void SetDisplayRangeX(float dp_x_start, float dp_x_end)
        {
            gPane.DP_x_start = dp_x_start;
            gPane.DP_x_end = dp_x_end;
            gPane.CurX_START = gPane.DP_x_start;
            gPane.CurX_END = gPane.DP_x_end;
        }

        public void SetGridDistanceX(float grid_dist_x_samples)
        {
            gPane.grid_distance_x = grid_dist_x_samples;
        }

        public void SetGridOriginX(float off_x)
        {
            gPane.grid_off_x = off_x;
        }


        #endregion

        #region PRIVATE METHODS

        protected override void Dispose(bool disposing)  //Bereinigen von nicht verwalteten Ressourcen
        {
            paused = true;


            base.Dispose(disposing);
        }

        public void Start()
        {
            if (isRunning == false && paused == false)
            {
                gPane.starting_idx = 0;
                paused = false;
                isRunning = true;
                // mTimer.Start();                

            }
            else
            {
                if (paused == false)
                {
                    //mTimer.Stop();
                    paused = true;
                }
                else
                {
                    // mTimer.Start();
                    paused = false;
                }

                if (paused)
                {


                }
                else
                {


                }
            }
        }

        public void Stop()
        {
            if (isRunning)
            {
                // mTimer.Stop();
                isRunning = false;
                paused = false;


            }
        }



        private void tb1_ButtonClick(object sender, ToolBarButtonClickEventArgs e)
        {
            bool pushed = e.Button.Pushed;
            switch (e.Button.Tag.ToString().ToLower())
            {
                case "play":

                    Start();

                    break;

                case "stop":

                    Stop();

                    break;

                case "print":

                    // // todo implement print preview
                    ShowPrintPreview();

                    break;
            }
        }

        private void SetPlayPanelVisible()
        {


        }

        private void SetPlayPanelInvisible()
        {


        }

        private void UpdateControl()
        {
            try
            {
                bool AllAutoscaled = true;

                foreach (DataSource s in gPane.Sources)
                {
                    AllAutoscaled &= s.AutoScaleX;
                }



            }
            catch
            {
            }
        }

        private void UpdatePlayback()
        {
            if (!paused && isRunning == true)
            {
                try
                {

                    UpdateScrollBar();
                    gPane.Invalidate();
                }
                catch { }
            }
        }

        private void OnTimerTick(object sender, EventArgs e)
        {
            UpdateControl();

            UpdatePlayback();
        }

        private void UpdateScrollBar()
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(UpdateScrollBar));
            }
            else
            {
                if (gPane.Sources.Count > 0)
                {
                    if (gPane.starting_idx > gPane.Sources[0].Length)
                    {

                    }
                    else if (gPane.starting_idx >= 0)
                    {

                    }
                    else
                    {

                    }
                }
                else
                {

                }
            }
        }

        private void OnScrollbarScroll(object sender, ScrollEventArgs e)
        {
            if (gPane.Sources.Count > 0) // Anzahl der Diagramme
            {


                gPane.Invalidate();
            }
        }



        #endregion

        private void ShowPrintPreview()
        {
            if (printPreviewForm == null)
            {
                printPreviewForm = new PrintPreviewForm();
            }

            printPreviewForm.GraphPanel = this.gPane;
            printPreviewForm.Show();
            printPreviewForm.TopMost = true;
            printPreviewForm.Invalidate();
        }

        private void selectGraphsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (GraphPropertiesForm == null)
            {
                GraphPropertiesForm = new PlotterGraphSelectCurvesForm();
            }

            GraphPropertiesForm.GraphPanel = this.gPane;
            GraphPropertiesForm.Show();
            //  GraphPropertiesForm.BringToFront();
        }

        private void ShowPrintViewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowPrintPreview();
        }


    }
}
