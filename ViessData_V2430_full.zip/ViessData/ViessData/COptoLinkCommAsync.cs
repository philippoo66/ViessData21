﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Timers;
using System.Windows.Forms;
using System.Xml;
using System.IO.Ports;


namespace OptoLinkCommAsyncLib
{
   /* Communication implemeted according to VitosoftCommunication.md 
   https://github.com/sarnau/InsideViessmannVitosoft
   Besten Dank @ 'sarnau' Markus Fritze! 

   # Viessmann Communication

   ## Hardware Layer

   ### Communication via OptoLink/USB Serial

   A simple serial port with a baud rate of 4800 8E2.


   ## Software Layer

   Communication is a package based serial communication. In pseudo-code it works like this:
   ```
      sendPackage()
      for retry=0 to RETRYCOUNT
         if hasReply() then
            receiveReplyPackage()
            return
         sleep(RETRYDELAY)
   ```

   In the following section I write `RETRYCOUNT x RETRYDELAY ms`, e.g. `10x50ms` to define the delays.

   ### GWG

   The GWG protocol is only used for old "Gas Wand Geräte" (Gas Wall Units). It is detected, but no longer supported by the Vitosoft 300 application. It only supports 8-bit addresses with several function codes, allowing a slightly larger address space.

   The detection works as follows: wait up to 10x50ms for an `ENQ` (0x05). Then send `0xC7,0xF8,0x04` (Virtual Read 0xF8, 4 bytes). The reply should be `0x20,0x53` or `0x20,0x54` to detect the GWG hardware. `0x20` is the "Gruppenidentifikation" (group identification) and `0x53` or `0x54` are the "Regleridentifikation" (controller unit identification)

   ### VS1

   Version 1 of the Vitotronic protocol, supported by the KW units from Viessmann. It supports 16-bit addresses plus several function codes.

   Because the whole communication is timing based, a timer is called every 50ms to check the current state of the connection and does the following:

   1. after opening the serial port or in case of an error, a connection is created by waiting for up to 30x100ms for an `ENQ` (0x05). It then immediately is confirmed by sending a `0x01`. In case an `VS2_ACK` (`0x06`) or `VS2_NACK` (`0x15`) was received, the VS2 protocol is also supported.
   2. If there is a pending message to be send, the message is written out and for up to 20x50ms serial data is read. Once the number of expected bytes have been received, the data is then processed. If within the giving time, not enough data was received, a connection reset it triggered (see step #1)
   3. If nothing needs to be send to the unit, every 500ms the connection is kept alive, by sending a check connection message (Virtual Read: 0xF8, 2 bytes), which expects a 2-byte reply within 20x50ms.

   #### VS1 Message Format

   The message is a simply list of bytes:

   1. Command/Function Code (`Virtuell_Write` = `0xF4`, `Virtuell_Read` = `0xF7`, `GFA_Read` = `0x6B`, `GFA_Write` = `0x68`, `PROZESS_WRITE` = `0x78`, `PROZESS_READ` = `0x7B`)
   2. Address High Byte
   3. Address Low Byte
   4. Block Length
   5. For write functions: Block Length additional bytes

   Read functions send a reply containing of the number of bytes in the block. All write functions send a single byte `vs1_data`, which is `0x00` in case the write was successful, any other value is undefined and is a failure.


   ### VS2

   Version 2 of the Vitotronic protocol. It is supported by all modern Viessmann units. These modern units also seem to be backward compatible with the VS1 protocol. It is an extension of the VS1 protocol, mostly to be faster and more reliable – thanks to checksums. But it is also more complex, because of hand-shaking requirements.

   To initiate the connection, after the serial port read buffer is emptied, then an `EOT` (`0x04`) is send and for 30x100ms waited for an `ENQ` (`0x05`), after which a `VS2_START_VS2, 0, 0` (`0x16,0x00,0x00`) is send and within 30x100ms an `VS2_ACK` (`0x06`) is expected. If an `VS2_ACK` (`0x06`) is received, before the start was sent, the start is resent (and the timeout is reset). In case a `VS2_NACK` (`0x15`) is received, it also resents the start and resets the timeout.

   After message is send, for up 30x100ms serial data is read. An `VS2_ACK` (`0x06`) or `VS2_NACK` (`0x15`) is expected first. If more than one is received, the oldest ones are removed from the receive buffer. If it is not received as the first byte, the message was not send successfully. Further bytes are collected till a full message is received. If the checksum is valid, an `VS2_ACK` is send out to confirm the successful transmission. A `VS2_NACK` is never send!

   If no message was send within 5s, the connection is restarted, the serial port read buffer is emptied and then sending a `VS2_START_VS2, 0, 0` (`0x16,0x00,0x00`) and within 30x100ms expecting an `VS2_ACK` (`0x06`).

   In case a UNACKD Message was send, only a single `VS2_ACK` or `VS2_NACK` is expected.


   #### VS2 Message Format

   The message requires a simple checksum.

   1. `VS2_DAP_STANDARD` (0x41)
   2. Package length for the CRC
   3. Protocol Identifier (0x00 = LDAP, 0x10 = RDAP, unused) | Message Identifier (0 = Request Message, 1 = Response Message, 2 = UNACKD Message, 3 = Error Message)
   4. Message Sequenz Number (top 3 bits in the byte) | Function Code
   5. Address High Byte
   6. Address Low Byte
   7. Block Length
   8. Block Length additional bytes
   9. CRC, a modulo-256 addition of bytes from Block Length and the additional bytes. CRC is technically the wrong name, it is more a checksum. But that is what Viessmann calls it.

   ##### Defined Commands/Function Codes:

   There are many commands defined, but only very few are actually used by Vitosoft, which seems to be `Virtual_READ`, `Virtual_WRITE`, `Remote_Procedure_Call`, `PROZESS_READ`, `PROZESS_WRITE`, `GFA_READ`, `GFA_WRITE`.

   Here is the complete list:
   - `undefined` = 0
   - `Virtual_READ` = 1
   - `Virtual_WRITE` = 2
   - `Physical_READ` = 3
   - `Physical_WRITE` = 4
   - `EEPROM_READ` = 5
   - `EEPROM_WRITE` = 6
   - `Remote_Procedure_Call` = 7
   - `Virtual_MBUS` = 33
   - `Virtual_MarktManager_READ` = 34
   - `Virtual_MarktManager_WRITE` = 35
   - `Virtual_WILO_READ` = 36
   - `Virtual_WILO_WRITE` = 37
   - `XRAM_READ` = 49
   - `XRAM_WRITE` = 50
   - `Port_READ` = 51
   - `Port_WRITE` = 52
   - `BE_READ` = 53
   - `BE_WRITE` = 54
   - `KMBUS_RAM_READ` = 65
   - `KMBUS_EEPROM_READ` = 67
   - `KBUS_DATAELEMENT_READ` = 81
   - `KBUS_DATAELEMENT_WRITE` = 82
   - `KBUS_DATABLOCK_READ` = 83
   - `KBUS_DATABLOCK_WRITE` = 84
   - `KBUS_TRANSPARENT_READ` = 85
   - `KBUS_TRANSPARENT_WRITE` = 86
   - `KBUS_INITIALISATION_READ` = 87
   - `KBUS_INITIALISATION_WRITE` = 88
   - `KBUS_EEPROM_LT_READ` = 89
   - `KBUS_EEPROM_LT_WRITE` = 90
   - `KBUS_CONTROL_WRITE` = 91
   - `KBUS_MEMBERLIST_READ` = 93
   - `KBUS_MEMBERLIST_WRITE` = 94
   - `KBUS_VIRTUAL_READ` = 95
   - `KBUS_VIRTUAL_WRITE` = 96
   - `KBUS_DIRECT_READ` = 97
   - `KBUS_DIRECT_WRITE` = 98
   - `KBUS_INDIRECT_READ` = 99
   - `KBUS_INDIRECT_WRITE` = 100
   - `KBUS_GATEWAY_READ` = 101
   - `KBUS_GATEWAY_WRITE` = 102
   - `PROZESS_WRITE` = 120
   - `PROZESS_READ` = 123
   - `OT_Physical_Read` = 180
   - `OT_Virtual_Read` = 181
   - `OT_Physical_Write` = 182
   - `OT_Virtual_Write` = 183
   - `GFA_READ` = 201
   - `GFA_WRITE` = 202
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

   /* Remarks by Phil Oebel:
   - Timer handling here done a little bit different...   
   - Sync not implemented - seems to be not needed 
   - Message Queueing implemented due to async usage

   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/


   public class CCommRequReturn
   {
      public bool Success = false;
      public byte[] RecdTelegr = new byte[0];
      public byte[] Data = new byte[0];
   }

   public class CBulkReadItem
   {
      public string Key = String.Empty;
      public ushort Address = 0x00F8; // std identifier
      public byte ReadLength = 2;
      public bool Success = false;
      public byte[] RecData = new byte[0];
   }

   public enum PROTOCOL
   {
      //NA,
      VS1_KW,
      VS2_300
   }

   public class COptoLinkCommAsync : IDisposable
   {
      #region constructor
      public COptoLinkCommAsync()
      {
         InitClass();
      }

      public void Dispose()
      {
         Dispose(true);
         GC.SuppressFinalize(this);
      }

      protected virtual void Dispose(bool disposing)
      {
         if (disposing)
         {
            // dispose managed resources

            if (tmrTimeout != null)
            {
               tmrTimeout.Enabled = false;
               tmrTimeout.Elapsed -= tmrTimeout_Elapsed;
               tmrTimeout.Dispose();
               //tmrTimeout = null;
            }

            if (tmrComDelay != null)
            {
               tmrComDelay.Enabled = false;
               tmrComDelay.Elapsed -= tmrComDelay_Elapsed;
               tmrComDelay.Dispose();
               //tmrComDelay = null;
            }

            if (tmrSync != null)
            {
               tmrSync.Enabled = false;
               tmrSync.Elapsed -= tmrSync_Elapsed;
               tmrSync.Dispose();
               //tmrTimeout = null;
            }

            if (serialPort != null)
            {
               if (serialPort.IsOpen)
               {
                  //port.DataReceived -= DataReceived;
                  serialPort.Close();
               }
               serialPort.Dispose();
               //serialPort = null;
            }

            ctsWait.Dispose();
         }

         // free native resources
         //...
      }
      #endregion constructor


      #region string constants
      public readonly string csBlank = " ";
      public readonly string csCrLf = "\r\n";
      public readonly string csCR = "\r";
      public readonly string csLf = "\n";
      public readonly string csTab = "\t";
      #endregion string constants

      #region Optolink comm constants
      public readonly byte VS1_DATA = 0x00;     // response to a successful write attempt 
      public readonly byte VS1_CONFIRM = 0x01;  // to be send to confirm reception of ENQ  
      public readonly byte EOT = 0x04;
      public readonly byte ENQ = 0x05;          // not init
      public readonly byte VS2_ACK = 0x06;
      public readonly byte VS2_NACK = 0x15;     // Error 
      public readonly byte VS2_START_VS2 = 0x16;
      public readonly byte STX = 0x41;          // VS2_DAP_STANDARD

      // Byte 02: 0x00 = Anfrage, 01 = Antwort, 03 = Fehler
      public readonly byte cbREQ = 0x00;
      public readonly byte cbRSP = 0x01;
      public readonly byte cbERR = 0x03;

      // Byte 03: 0x01 = ReadData, 0x02 = WriteData, 07 = Function Call
      // Bits 7,6,5 können wahlfrei gesetzt werden, sie werden in der Antwort dann ebenfalls gesetzt
      public readonly byte cbREAD = 0x01;
      public readonly byte cbWRITE = 0x02;
      public readonly byte cbFNCC = 0x07;
      #endregion Optolink comm constants

      #region more variables and objects
      /// <summary>
      /// controls way of transmission
      /// </summary>
      public PROTOCOL Protocol = PROTOCOL.VS1_KW;  // to start with

      /// <summary>
      /// if true no waiting for 0x05 for transmission
      /// remember to reset after bulk!
      /// </summary>   
      public bool fKWBulk = false;

      // From for debug output
      private FDebug frmDebug = null;          // disable
      //private FDebug frmDebug = new FDebug();  // enable

      private SerialPort serialPort = new SerialPort();
      //public bool fBusy = false;

      // timeout
      private System.Timers.Timer tmrTimeout = new System.Timers.Timer();
      private bool fTimeout = false;

      private System.Timers.Timer tmrSync = new System.Timers.Timer();

      private int checkReceiveDelay = 10;  // ms
      #endregion more variables and objects


      // init +++++++
      private void InitClass()
      {
         tmrTimeout.Elapsed += new System.Timers.ElapsedEventHandler(this.tmrTimeout_Elapsed);
         tmrTimeout.AutoReset = false;

         tmrComDelay.Elapsed += new System.Timers.ElapsedEventHandler(this.tmrComDelay_Elapsed);
         tmrComDelay.AutoReset = false;

         tmrSync.Elapsed += new System.Timers.ElapsedEventHandler(this.tmrSync_Elapsed);
         tmrSync.AutoReset = false;

         InitSerialPort();

         if (frmDebug != null)
         {
            frmDebug.Show();
            frmDebug.Left = 10;
            frmDebug.Top = 10;
         }
      }

      private void InitSerialPort()
      {
         serialPort.BaudRate = 4800;
         serialPort.DataBits = 8;
         serialPort.StopBits = StopBits.Two;
         serialPort.Parity = Parity.Even;
         serialPort.Handshake = Handshake.None;
      }


      // port and exit +++++++
      public bool OpenPort(string portname, bool showErrMsg)
      {
         try
         {
            serialPort.PortName = portname;
            serialPort.Open();
            DoLog("Port opened: " + serialPort.PortName); //temp
         }
         catch (Exception ex)
         {
            if (showErrMsg) MessageBox.Show("Error opening Port " + portname + ":" +csCrLf+ ex.Message);
            return false;
         }
         return serialPort.IsOpen;
      }

      public void ClosePort()
      {
         if (serialPort == null)
            return;

         if (serialPort.IsOpen)
         {
            tmrSync.Stop();
            tmrTimeout.Stop();

            if (Protocol == PROTOCOL.VS2_300)
            {
               // re-init KW protocol
               SendBytes(new byte[1] { EOT });  // 0x04
            }

            fCancel = true;
            //cts.Cancel(); //!! ??
            //await Task.Delay(300);

            serialPort.Close();
            DoLog("Port closed."); //temp

            fCancel = false;  //!! ??
         }
      }

      public bool PortIsOpen()
      {
         return ((serialPort != null) && serialPort.IsOpen);
      }

      /// <summary>
      /// to be called when closing apllication
      /// </summary>
      /// <returns></returns>
      public async Task CleanExit()
      {
         if (frmDebug != null)
            frmDebug.Close();

         // stop all timers
         tmrTimeout.Stop();
         tmrSync.Stop();
         tmrComDelay.Stop();

         // cancel everything
         Cancel();
         await Task.Delay(100);

         try
         {
            if (serialPort.IsOpen)
            {
               // re-init KW protocol
               SendBytes(new byte[1] { EOT });  // 0x04
               serialPort.Close();
               serialPort.Dispose();
            }
         }
         catch (Exception) { }


         // dispose timers +++
         tmrTimeout.Enabled = false;
         tmrTimeout.Elapsed -= tmrTimeout_Elapsed;
         tmrTimeout.Dispose();

         tmrSync.Enabled = false;
         tmrSync.Elapsed -= tmrSync_Elapsed;
         tmrSync.Dispose();

         tmrComDelay.Enabled = false;
         tmrComDelay.Elapsed -= tmrComDelay_Elapsed;
         tmrComDelay.Dispose();

      }


      #region communication
      // ### CheckProtokoll DOES NOT WORK!!! ###
      public async Task<PROTOCOL> CheckProtokoll(bool queuehandling)
      {
         // ### DOES NOT WORK!!! ###  with my VD300-W HO2C

         // after opening the serial port or in case of an error, 
         // a connection is created by waiting for up to 30x100ms for an `ENQ` (0x05). 
         // It then immediately is confirmed by sending a `0x01` (VS1_CONFIRM). 
         // In case an `VS2_ACK` (`0x06`) or `VS2_NACK` (`0x15`) was received, the VS2 protocol is also supported.

         PROTOCOL ret = PROTOCOL.VS1_KW;   //.NA;

         if (fCancel || (serialPort == null) || !serialPort.IsOpen)
            return ret;

         if (queuehandling)
            if (!await HandleQueue())
               return ret;


         serialPort.DiscardInBuffer();

         if (!await WaitFor0x05())
            goto doexit;

         SendBytes(new byte[1] { 0x01 });

         StartTimoutTimer(2000);

         int inbyte = 0;

         while (!(fTimeout | fCancel))
         {
            await WaitAsync(checkReceiveDelay);

            if (!fCancel && (serialPort != null) && serialPort.IsOpen && serialPort.BytesToRead > 0)
            {
               inbyte = serialPort.ReadByte();
               DoLog((byte)inbyte, "RX", String.Empty);

               if ((inbyte == VS2_ACK) | (inbyte == VS2_NACK))
                  ret = PROTOCOL.VS2_300;
               else
                  ret = PROTOCOL.VS1_KW;

               goto doexit;
            }
         }

         doexit:
         tmrTimeout.Stop();
         if (queuehandling)
            LineGotFree();
         return ret;
      }

      public async Task<bool> Init300Protocol()
      {
         // timeout mechanism happens in subs!

         if (fCancel || (serialPort == null) || !serialPort.IsOpen)
            return false;

         if (!await HandleQueue())
            return false;

         bool ret = false;

         // To initiate the connection, after the serial port read buffer is emptied, 
         // then an `EOT` (`0x04`) is send 
         if (!SendBytes(new byte[1] { EOT }))  // 0x04
            goto doexit;

         // and for 30x100ms waited for an `ENQ` (`0x05`)
         if (!await WaitFor0x05())
            goto doexit;

         //await WaitAsync(10); // ?

         // after which a `VS2_START_VS2, 0, 0` (`0x16,0x00,0x00`) is send
         // and within 30x100ms an `VS2_ACK` (`0x06`) is expected
         ret = await DoSyncV2(false);


         doexit:
         if (ret)
            Protocol = PROTOCOL.VS2_300;
         else
            Protocol = PROTOCOL.VS1_KW;

         LineGotFree();
         return ret;
      }

      private async Task<bool> WaitFor0x05()
      {
         int inbyte;
         bool ret = false;

         StartTimoutTimer(5000);  // for 30x100ms waited

         while (!(fTimeout | fCancel))
         {
            await WaitAsync(checkReceiveDelay);

            while (!fCancel && (serialPort != null) && serialPort.IsOpen && serialPort.BytesToRead > 0)
            {
               inbyte = serialPort.ReadByte();
               DoLog((byte)inbyte, "RX", String.Empty);

               if (inbyte == ENQ)
               {
                  ret = true;
                  goto doexit;
               }
            }
         }

         doexit:
         tmrTimeout.Stop();
         return ret;
      }

      #region Sync - not used
      /// <summary>
      /// send sync sequence and wait for ACK
      /// </summary>
      /// <returns>success</returns>
      public async Task<bool> DoSyncV2(bool queuehandling)
      {
         if (fCancel || (serialPort == null) || !serialPort.IsOpen)
            return false;

         if (queuehandling)
            if (!await HandleQueue())
               return false;


         bool ret = false;
         int inbyte = 0;
         int retry = 0;
         doretry:

         // If an `VS2_ACK` (`0x06`) is received, before the start was sent, the start is resent
         serialPort.DiscardInBuffer();

         // a `VS2_START_VS2, 0, 0` (`0x16,0x00,0x00`) is send
         SendBytes(new byte[3] { VS2_START_VS2, 0x00, 0x00 });

         StartTimoutTimer(5000);  // and within 30x100ms an `VS2_ACK` (`0x06`) is expected

         while (!(fTimeout | fCancel))
         {
            await WaitAsync(checkReceiveDelay);

            if (!fCancel && (serialPort != null) && serialPort.IsOpen && serialPort.BytesToRead > 0)
            {
               inbyte = serialPort.ReadByte();
               DoLog((byte)inbyte, "RX", String.Empty);

               // a `VS2_ACK` (`0x06`) is expected
               if ((byte)inbyte == VS2_ACK)
               {
                  ret = true;
                  goto doexit;
               }
               else
               {
                  // In case a `VS2_NACK` (`0x15`) is received, it also resents the start and resets the timeout.
                  retry++;
                  if (retry < 3)
                     goto doretry;
                  else
                     goto doexit;
               }
            }

            #region not straigt to sarnau
            //while (serialPort.BytesToRead > 0)
            //{
            //   inbyte = serialPort.ReadByte();
            //   DoLog((byte)inbyte, "RX", String.Empty);

            //   if ((byte)inbyte == VS2_ACK)
            //   {
            //      ret = true;
            //      goto doexit;
            //   }
            //}
            #endregion not straigt to sarnau
         }

         doexit:
         tmrTimeout.Stop();
         if (queuehandling)
            LineGotFree();
         return ret;
      }

      public async Task<bool> DoSyncV1(bool queuehandling)
      {
         if (fCancel || (serialPort == null) || !serialPort.IsOpen)
            return false;

         if (queuehandling)
            if (!await HandleQueue())
               return false;

         int val = await Read2ByteValue(0xF8);
         bool ret = (val != short.MinValue);

         if (queuehandling)
            LineGotFree();

         return ret;
      }

      private void ResetSyncTimer()
      {
         tmrSync.Stop();
         tmrSync.Start();
      }
      #endregion Sync

      // best for public use +++++++
      public async Task<float> Read1ByteValue(int addr, bool signed, float precision)
      {
         int ret = await Read1ByteValue(addr, signed);

         return (ret * precision);
      }

      public async Task<int> Read1ByteValue(int addr, bool signed)
      {
         int ret = await Read1ByteValue(addr);

         if (signed)
            ret = (sbyte)(ret);

         return ret;
      }

      public async Task<int> Read1ByteValue(int addr)
      {
         int ret = short.MinValue;

         CCommRequReturn rr = await ReadData(addr, 1);

         if (rr.Success && (rr.Data.Length > 0))
         {
            ret = rr.Data[0];
         }

         return ret;
      }

      public async Task<float> Read2ByteValue(int addr, bool signed, float precision)
      {
         int ret = await Read2ByteValue(addr, signed);

         return (ret * precision);
      }

      public async Task<int> Read2ByteValue(int addr, bool signed)
      {
         int ret = await Read2ByteValue(addr);

         if (signed)
            ret = (short)(ret);

         return ret;
      }

      public async Task<int> Read2ByteValue(int addr)
      {
         int ret = short.MinValue;

         CCommRequReturn rr = await ReadData(addr, 2);

         if (rr.Success && (rr.Data.Length > 1))
         {
            ret = rr.Data[0] + (rr.Data[1] << 8);
         }

         return ret;
      }


      public async Task<bool> Write1ByteValue(int addr, byte val)
      {
         byte[] data = new byte[1] { val };

         CCommRequReturn rr = await WriteData(addr, data);

         return rr.Success;
      }

      public async Task<bool> Write2ByteValue(int addr, int val)
      {
         byte[] data = BitConverter.GetBytes((short)(val));

         CCommRequReturn rr = await WriteData(addr, data);

         return rr.Success;
      }


      // mainly for internal use +++++++
      public async Task<CCommRequReturn> ReadData(int addr, byte len)
      {
         // queue handling in subs

         //DoLog("ReadData " + addr.ToString("X4"));

         if (Protocol == PROTOCOL.VS2_300)
            return await ReadData300(addr, len);
         else
            return await ReadDataKW(addr, len);
      }

      public async Task<CCommRequReturn> WriteData(int addr, byte[] data)
      {
         // queue handling in subs

         if (Protocol == PROTOCOL.VS2_300)
            return await WriteData300(addr, data);
         else
            return await WriteDataKW(addr, data);
      }

      private async Task<CCommRequReturn> ReadData300(int addr, byte len)
      {
         CCommRequReturn rr = new CCommRequReturn();

         //DoLog("ReadData300 Einstieg");

         if (fCancel || (serialPort == null) || !serialPort.IsOpen)
            return rr;

         //DoLog("HandleQueue");

         if (!await HandleQueue())
            return rr;

         //DoLog("now send request");

         #region send telegram
         byte[] outbuff = new byte[8];
         string errmsg = String.Empty;

         outbuff[0] = STX;   // 0x41 Telegrammstart
         outbuff[1] = 0x05;    // Len Nutzdaten, hier immer 5
         outbuff[2] = cbREQ;   // 0x00 Anfrage
         outbuff[3] = cbREAD;  // 0x01 Lesen
         outbuff[4] = (byte)((addr >> 8) & 0xFF);  // hi byte
         outbuff[5] = (byte)((addr) & 0xFF);       // lo byte
         outbuff[6] = len;     // Anzahl der zu lesenden Daten-Bytes
         outbuff[7] = Calc_CRC(outbuff);

         if (!SendBytes(outbuff))
            goto doexit;
         #endregion send telegram

         StartTimoutTimer(3000); //!

         //DoLog("now receive resonse");

         #region recive resopnse
         int inbyte = 0;
         int state = 0;
         int bytesrecd = 0;
         bool reccompl = false;

         while (!(reccompl | fTimeout | fCancel))
         {
            await WaitAsync(checkReceiveDelay);

            while (!reccompl && !fCancel && (serialPort != null) && serialPort.IsOpen && (serialPort.BytesToRead > 0))
            {
               inbyte = serialPort.ReadByte();
               //DoLog((byte)inbyte, "RX", state.ToString()); //String.Empty);

               switch (state)
               {
                  case 0: // first byte
                     {
                        if (inbyte == VS2_ACK) // 0x06
                        {
                           bytesrecd++;
                           state++;
                        }
                        else if (inbyte == VS2_NACK)  // 0x15
                        {
                           errmsg = "ERROR NACK 0x15";
                           rr.RecdTelegr = new byte[1] { VS2_NACK };
                           //state++;  // trotzdem Rest empfangen
                           goto doexit;
                        }
                        else if (inbyte == ENQ)  // 0x05 not init'ed
                        {
                           errmsg = "ERROR ENQ 0x05";
                           rr.RecdTelegr = new byte[1] { ENQ };
                           //state++;  // trotzdem Rest empfangen
                           goto doexit;
                        }
                        break;
                     }
                  case 1: // wait for STX
                     {
                        if (inbyte == STX)  // 0x41
                        {
                           bytesrecd++;
                           state++;
                        }
                        break;
                     }
                  case 2: // receive len
                     {
                        rr.RecdTelegr = new byte[inbyte + 4]; // 0x06 + 0x41 + Len + Nutzdaten + CRC
                        rr.RecdTelegr[0] = VS2_ACK;
                        rr.RecdTelegr[1] = STX;
                        rr.RecdTelegr[2] = (byte)(inbyte & 0xFF);

                        bytesrecd++;
                        state++;
                        break;
                     }
                  case 3: // receive rest of telegram
                     {
                        if (bytesrecd < rr.RecdTelegr.Length)
                        {
                           rr.RecdTelegr[bytesrecd] = (byte)(inbyte & 0xFF);
                           bytesrecd++;
                           //DoLog(rr.RecData, "", bytesrecd.ToString()); //temp
                        }

                        if (bytesrecd >= rr.RecdTelegr.Length)
                        {
                           reccompl = true;
                           //DoLog("Rec compl"); //temp
                        }

                        break;
                     }
               }
            }
         }
         #endregion recive resopnse

         tmrTimeout.Stop();

         #region check
         if (reccompl)
         {
            if (Calc_CRC(rr.RecdTelegr) == rr.RecdTelegr[rr.RecdTelegr.Length - 1])
            {
               // If the checksum is valid, an `VS2_ACK` is send out to confirm the successful transmission.
               // ... nerver done so - working anyway

               len = rr.RecdTelegr[7];
               rr.Data = new byte[len];
               Array.Copy(rr.RecdTelegr, 8, rr.Data, 0, len);
            }
            else
            {
               // A `VS2_NACK` is never send!
               errmsg = "ERROR CRC";
               goto doexit;
            }

            //if ()  weiter prüfen?!?
            // rr.RecData[2] != 0x03  // Fehler
            // rr.RecData[3] R/W data...
            // rr.RecData[4,5] Adresse

            rr.Success = true;
         }
         else
            errmsg = "ERROR Timeout/Cancel";
         #endregion check

         doexit:
         tmrTimeout.Stop();
         DoLog(rr.RecdTelegr, "RX", errmsg);
         //DoLog(rr.Data, "RX", "Data");
         LineGotFree();
         return rr;
      }

      private async Task<CCommRequReturn> ReadDataKW(int addr, byte len)
      {
         CCommRequReturn rr = new CCommRequReturn();

         if (fCancel || (serialPort == null) || !serialPort.IsOpen)
            return rr;

         if (!await HandleQueue())
            return rr;


         #region send telegram
         byte[] outbuff = new byte[4];
         string errmsg = String.Empty;
         int offs = 0;

         serialPort.DiscardInBuffer();

         if (!fKWBulk)
         {
            outbuff = new byte[5];
            offs = 1;
            outbuff[0] = 0x01;  // STX_KW

            // a connection is created by waiting for up to 30x100ms for an `ENQ` (0x05).
            await WaitFor0x05();
         }
         /* else
         Anstatt auf das nächste 0x05 zu warten, kann auch direkt nach dem Empfang einer Antwort 
         das nächste Telegramm geschickt werden. Dabei darf das Telegramm nicht mit 0x01 eingeleitet werden 
         (Somit ist das 0x01 logisch gesehen nicht ein Telegram-Start-Byte sondern ein ACK auf die 0x05).
         https://github.com/openv/openv/wiki/Protokoll-KW
         */

         outbuff[0 + offs] = 0xF7;   // 0xF7 Virtual_Read
         outbuff[1 + offs] = (byte)((addr >> 8) & 0xFF);  // hi byte
         outbuff[2 + offs] = (byte)(addr & 0xFF);         // lo byte
         outbuff[3 + offs] = len;    // Anzahl der zu lesenden Daten-Bytes


         // the message is written out and for up to 20x50ms serial data is read.
         if (!SendBytes(outbuff))
            goto doexit;
         #endregion send telegram

         StartTimoutTimer(3000); //  20x50ms serial data is read

         #region recive resopnse
         int inbyte = 0;
         int bytesrecd = 0;
         bool reccompl = false;

         rr.RecdTelegr = new byte[len];

         while (!(reccompl | fTimeout | fCancel))
         {
            await WaitAsync(checkReceiveDelay);

            while (!reccompl && !fCancel && (serialPort != null) && serialPort.IsOpen && (serialPort.BytesToRead > 0))
            {
               inbyte = serialPort.ReadByte();
               DoLog((byte)inbyte, "RX", String.Empty);

               rr.RecdTelegr[bytesrecd] = (byte)(inbyte & 0xFF);
               bytesrecd++;
               reccompl = (bytesrecd >= len);
            }
         }
         #endregion recive resopnse

         tmrTimeout.Stop();

         #region check
         if (reccompl)
         {
            rr.Data = rr.RecdTelegr;
            rr.Success = true;
         }
         else
            errmsg = "ERROR Timeout/Cancel";
         #endregion check

         doexit:
         tmrTimeout.Stop();
         DoLog(rr.RecdTelegr, "RX", errmsg);
         LineGotFree();
         return rr;
      }

      private async Task<CCommRequReturn> WriteData300(int addr, byte[] data)  // data[0]=loB .. data[n]=hiB  entspr. BitConverter
      {
         CCommRequReturn rr = new CCommRequReturn();

         if (fCancel || (serialPort == null) || !serialPort.IsOpen)
            return rr;

         int len = data.Length;
         if (len < 1)
            return rr;

         if (!await HandleQueue())
            return rr;


         #region send telegram
         byte[] outbuff = new byte[len + 8];
         //byte[] inbuff = new byte[0];
         string errmsg = String.Empty;
         //bool ret = false;

         outbuff[0] = STX;   // 0x41 Telegrammstart
         outbuff[1] = (byte)(5 + len);    //
         outbuff[2] = cbREQ;   // 0x00 Anfrage
         outbuff[3] = cbWRITE;  // 0x02 Schreiben
         outbuff[4] = (byte)((addr >> 8) & 0xFF);  // hi byte
         outbuff[5] = (byte)((addr) & 0xFF);       // lo byte
         outbuff[6] = (byte)len;   // Anzahl der zu schreibenden Daten-Bytes

         for (int i = 0; i < len; i++)
            outbuff[7 + i] = data[i];  //[len - 1 - i];    

         outbuff[7 + len] = Calc_CRC(outbuff);

         if (!SendBytes(outbuff))
            goto doexit;
         #endregion send telegram

         StartTimoutTimer(5000);

         #region recive resopnse
         int inbyte = 0;
         int state = 0;
         int bytesrecd = 0;
         bool reccompl = false;

         while (!(reccompl | fTimeout | fCancel))
         {
            await WaitAsync(checkReceiveDelay);

            //try
            //{
            while (!reccompl && !fCancel && (serialPort != null) && serialPort.IsOpen && (serialPort.BytesToRead > 0))
            {
               inbyte = serialPort.ReadByte();
               //DoLog((byte)inbyte, "RX", state.ToString()); //String.Empty);

               switch (state)
               {
                  case 0: // first byte
                     {
                        if (inbyte == VS2_ACK) // 0x06
                        {
                           bytesrecd++;
                           state++;
                        }
                        else if (inbyte == VS2_NACK)  // 0x15
                        {
                           errmsg = "ERROR NACK 0x15";
                           rr.RecdTelegr = new byte[1] { VS2_NACK };
                           //state++;  // trotzdem Rest empfangen
                           goto doexit;
                        }
                        else if (inbyte == ENQ)  // 0x05 not init'ed
                        {
                           errmsg = "ERROR NEQ 0x05";
                           rr.RecdTelegr = new byte[1] { ENQ };
                           //state++;  // trotzdem Rest empfangen
                           goto doexit;
                        }

                        break;
                     }
                  case 1: // wait for STX
                     {
                        if (inbyte == STX)   // 0x41
                        {
                           bytesrecd++;
                           state++;
                        }
                        break;
                     }
                  case 2: // receive len
                     {
                        rr.RecdTelegr = new byte[inbyte + 4]; // 0x06 + 0x41 + Len + Nutzdaten + CRC
                        rr.RecdTelegr[0] = VS2_ACK;
                        rr.RecdTelegr[1] = STX;
                        rr.RecdTelegr[2] = (byte)inbyte;

                        bytesrecd++;
                        state++;
                        break;
                     }
                  case 3: // receive rest of telegram
                     {
                        if (bytesrecd < rr.RecdTelegr.Length)
                        {
                           rr.RecdTelegr[bytesrecd] = (byte)inbyte;
                           bytesrecd++;
                           //DoLog(rr.RecData, "", bytesrecd.ToString()); //temp
                        }

                        if (bytesrecd >= rr.RecdTelegr.Length)
                        {
                           reccompl = true;
                           //DoLog("Rec compl"); //temp
                        }

                        break;
                     }
               }
            }
            //}
            //catch (Exception ex)
            //{
            //   DoLog(ex.Message);
            //}

         }
         #endregion recive resopnse

         tmrTimeout.Stop();

         #region check
         if (reccompl)
         {
            if (Calc_CRC(rr.RecdTelegr) != rr.RecdTelegr[rr.RecdTelegr.Length - 1])
            {
               errmsg = "ERROR CRC";
               goto doexit;
            }

            //if ()  weiter prüfen?!?
            // rr.RecData[2] != 0x03  // Fehler
            // rr.RecData[3] R/W data...
            // rr.RecData[4,5] Adresse

            rr.Success = true;
         }
         else
            errmsg = "ERROR Timeout/Cancel";
         #endregion check

         doexit:
         tmrTimeout.Stop();
         DoLog(rr.RecdTelegr, "RX", errmsg);
         LineGotFree();
         return rr;
      }

      private async Task<CCommRequReturn> WriteDataKW(int addr, byte[] data)
      {
         CCommRequReturn rr = new CCommRequReturn();

         if (fCancel || (serialPort == null) || !serialPort.IsOpen)
            return rr;

         int len = data.Length;
         if (len < 1)
            return rr;

         if (!await HandleQueue())
            return rr;

         #region send telegram
         byte[] outbuff = new byte[4];
         string errmsg = String.Empty;
         int offs = 0;

         serialPort.DiscardInBuffer();

         //if (!fKWBulk)  // no bulk write for now
         {
            outbuff = new byte[5 + len];
            offs = 1;
            outbuff[0] = 0x01;  // STX_KW

            // a connection is created by waiting for up to 30x100ms for an `ENQ` (0x05).
            await WaitFor0x05();
         }
         /* else
         Anstatt auf das nächste 0x05 zu warten, kann auch direkt nach dem Empfang einer Antwort 
         das nächste Telegramm geschickt werden. Dabei darf das Telegramm nicht mit 0x01 eingeleitet werden 
         (Somit ist das 0x01 logisch gesehen nicht ein Telegram-Start-Byte sondern ein ACK auf die 0x05).
         https://github.com/openv/openv/wiki/Protokoll-KW
         */

         outbuff[0 + offs] = 0xF4;   // 0xF4 Virtual_Write
         outbuff[1 + offs] = (byte)((addr >> 8) & 0xFF);  // hi byte
         outbuff[2 + offs] = (byte)(addr & 0xFF);         // lo byte
         outbuff[3 + offs] = (byte)len;    // Anzahl der zu schreibenden Daten-Bytes

         for (int i = 0; i < len; i++)
            outbuff[4 + offs + i] = data[i];  //[len - 1 - i];    

         if (!SendBytes(outbuff))
            goto doexit;
         #endregion send telegram

         StartTimoutTimer(5000);

         #region recive resopnse
         int inbyte = 0;

         while (!(fTimeout | fCancel))
         {
            await WaitAsync(checkReceiveDelay);

            if (!fCancel && (serialPort != null) && serialPort.IsOpen && (serialPort.BytesToRead > 0))
            {
               // All write functions send a single byte `vs1_data`, which is `0x00` in case the write was successful,
               // any other value is undefined and is a failure.
               inbyte = serialPort.ReadByte();

               rr.RecdTelegr = new byte[1] { (byte)inbyte };

               if ((byte)inbyte == VS1_DATA)
                  rr.Success = true;
               else
                  errmsg = "ERROR Failure";

               goto doexit;
            }
         }
         #endregion recive resopnse

         doexit:
         tmrTimeout.Stop();
         DoLog(rr.RecdTelegr, "RX", errmsg);
         LineGotFree();
         return rr;
      }

      public bool SendBytes(byte[] outbuf)
      {
         return SendBytes(outbuf, outbuf.Length);
      }

      public bool SendBytes(byte[] outbuf, int len)
      {
         // check...
         if (fCancel || (serialPort == null) || !serialPort.IsOpen) return false;

         try
         {
            serialPort.DiscardOutBuffer();
            serialPort.DiscardInBuffer();
            serialPort.Write(outbuf, 0, len);
            serialPort.BaseStream.Flush();   // ?? so übernommen... aber
                                             // The Write command will get written to the serial port driver transmit buffer without any extra help. 
                                             // Flush is not required. 
                                             // If it doesn't make it to the device then you've probably got a handshake problem. 
                                             // A classic mistake is to leave it set to None and not setting the DtrEnable and RtsEnable properties to true.
            DoLog(outbuf, "TX", String.Empty);
            return true;
         }
         catch (Exception ex)
         {
            DoLog("TX_EXC: " + ex.Message);
            //DoLog(outbuf, "TX", ErrToString(PCA_ERROR.Transmit));
            //if (!fCancel) AppMessage.Message("Error sending Data:" + csCrLf + ex.Message, "ParcoA");
            return false;
         }
      }


      // utils +++++++
      private byte Calc_CRC(byte[] telegram)
      {
         uint CRCsum = 0;
         byte telestart = 1;
         byte teleend = (byte)(telegram[1] + 1);

         if (telegram[0] != 0x41)       // vielleicht noch ein 0x06 davor?
         {
            telestart++;
            teleend = (byte)(telegram[2] + 2);
            if ((telegram[0] != 0x06) & (telegram[1] != 0x41)) return (0);
         }

         for (byte i = telestart; i <= teleend; i++)
         {
            CRCsum += telegram[i];
         }

         return ((byte)(CRCsum % 0x100));
      }

      public void StartTimoutTimer(int millisecs)
      {
         tmrTimeout.Stop();
         fTimeout = false;
         tmrTimeout.Interval = millisecs;
         tmrTimeout.Start();
      }

      public async Task JustReceive()
      {
         if (fCancel || (serialPort == null) || !serialPort.IsOpen)
            return;

         int inbyte = 0;

         while (!fCancel)
         {
            while (!fCancel && (serialPort != null) && serialPort.IsOpen && serialPort.BytesToRead > 0)
            {
               inbyte = serialPort.ReadByte();
               DoLog((byte)inbyte, "RXs", String.Empty);
            }

            await WaitAsync(checkReceiveDelay);
         }
      }


      #region bulk reading - not used
      public Dictionary<string, CBulkReadItem> dicBulkRead = new Dictionary<string, CBulkReadItem>();

      public async Task<bool> ReadBulk()
      {
         bool ret = true;

         foreach (KeyValuePair<string, CBulkReadItem> itm in dicBulkRead)
         {
            CCommRequReturn rr = await ReadData(itm.Value.Address, itm.Value.ReadLength);

            if (rr.Success)
            {
               dicBulkRead[itm.Key].RecData = rr.Data;
            }

            ret &= rr.Success;

            await WaitAsync(50);
         }

         return ret;
      }

      #endregion bulk reading

      #endregion communication

      #region queueing
      //+++ how queueing works ++++
      // check queue:  // HandleQueue()        
      //   while(not_my_turn or inter_comm_delay)
      //     wait
      // do my stuff:
      //   send request
      //   receive response
      //   evaluate...
      // release:      // LineGotFree()
      //   start interCommDelay timer
      //   increase queue pointer
      //
      // HandleQueue() has to be awaited befor each communication attempt,
      // LineGotFree() has to get called after communication initiated after HandleQueue().
      //   Make sure LineGotFree() gets called even in case of Error, 
      //   otherwise next HandleQueue() waits infinitively  
      //+++++++++++++++++++++++++++

      #region queueing variables
      private uint iQueuePointer = 0;
      private uint iQueueIndex = 0;

      /// <summary>
      /// max number of delayed comm requests
      /// </summary>
      public uint maxQueueLength = 30;
      /// <summary>
      /// minimum delay [ms] between two comm cycles
      /// </summary>
      public int interCommDelay = 50;
      /// <summary>
      /// delay [ms] to check if line is free (-> queue)
      /// </summary>
      public int checkLineFreeDelay = 5;

      // inter-comm delay
      private System.Timers.Timer tmrComDelay = new System.Timers.Timer();
      private bool fDelayCom = false;
      #endregion queueing variables


      /// <summary>
      /// number of active/pending comm requests
      /// </summary>
      public int QueueState
      {
         get
         {
            return ((int)(iQueuePointer - iQueueIndex));
         }
      }

      /// <summary>
      /// method to be awaited befor each communication attempt to care for queueing and message delay,
      /// to be released by calling LineGotFree()
      /// </summary>
      /// <returns>successful waiting for line being free for comm attempt</returns>
      private async Task<bool> HandleQueue()
      {
         if (fCancel) return false;  // PCA_ERROR.Cancel;

         //string sLog = iQueueCounter.ToString() + csBlank + iQueueIndex.ToString();
         //DoLog("HandleQueue_in: " + sLog);

         if (iQueuePointer == 0)
         {
            // line is free - go
            iQueuePointer++;
         }
         else
         {
            // line is busy - wait

            Console.WriteLine("Q {0} {1}", iQueuePointer, iQueueIndex);

            if ((QueueState > maxQueueLength) | (iQueuePointer == int.MaxValue))
               return false; // PCA_ERROR.QueueOverrun;

            uint iMyQueueIndex = iQueuePointer;

            iQueuePointer++;

            while (iMyQueueIndex > iQueueIndex)
            {
               if (fCancel) return false; // PCA_ERROR.Cancel;
               await WaitAsync(checkLineFreeDelay);
            }
            // now line got free
         }

         //sLog = iQueueCounter.ToString() + csBlank + iQueueIndex.ToString();
         //DoLog("HandleQueue_out: " + sLog);

         // if necessary delay next telegram
         while (fDelayCom)
         {
            if (fCancel) return false;  // PCA_ERROR.Cancel;
            await WaitAsync(checkLineFreeDelay);
         }

         // go
         return true;  // PCA_ERROR.None;
      }

      /// <summary>
      /// always in pair with HandleQueue(), 
      /// to get called after communication to indicate that the attempt got finished
      /// </summary>
      private void LineGotFree()
      {
         StartComDelayTimer(interCommDelay);

         //string sLog = iQueueCounter.ToString() + csBlank + iQueueIndex.ToString();
         //DoLog("LineGotFree_in: " + sLog);

         iQueueIndex++;

         if (iQueueIndex == iQueuePointer)
         {
            // this was the last pending com request - reset both counters
            iQueuePointer = 0;
            iQueueIndex = 0;
         }

         //sLog = iQueueCounter.ToString() + csBlank + iQueueIndex.ToString();
         //DoLog("LineGotFree_out: " + sLog);
      }

      private void StartComDelayTimer(int iMilliseconds)
      {
         if (iMilliseconds > 0)
         {
            tmrComDelay.Enabled = false;
            fDelayCom = true;
            tmrComDelay.Interval = iMilliseconds;
            tmrComDelay.Enabled = true;
         }
         else
         {
            fDelayCom = false;
         }
      }

      // must get attached to tmrComDelay.Elapsed during init!
      private void tmrComDelay_Elapsed(object sender, ElapsedEventArgs e)
      {
         tmrComDelay.Enabled = false;
         fDelayCom = false;
      }
      #endregion queueing

      #region cancel, wait
      private CancellationTokenSource ctsWait = new CancellationTokenSource();
      public bool fCancel = false;

      public void Cancel()
      {
         fCancel = true;
         ctsWait.Cancel();
      }

      public void UnCancel()
      {
         fCancel = false;
         iQueuePointer = iQueueIndex = 0;
         ctsWait = new CancellationTokenSource();
      }

      public async Task WaitAsync(int milliseconds)
      {
         if (milliseconds > 0)
         {
            try
            {
               await Task.Delay(milliseconds, ctsWait.Token);
            }
            catch (TaskCanceledException) { }
            catch (Exception) { }
         }
      }
      #endregion cancel, wait

      #region utils
      public void DoLog(string message)
      {
         if (frmDebug == null) return;
         frmDebug.ShowInfo(message);
         //lbxInfo.Items.Add(message);
         //lbxInfo.SelectedIndex = lbxInfo.Items.Count - 1;
      }

      public void DoLog(byte[] data, string pre, string post)
      {
         //if (!fLogging) return;
         if (frmDebug == null) return;

         if (pre != String.Empty) pre += ": ";

         string sLine = pre;

         for (int i = 0; i < data.Length; i++)
         {
            sLine += (data[i].ToString("X2") + csBlank);
         }

         if (post != String.Empty) sLine += ": " + post;  // eigentlich nur ErrInfo -> hat leading space

         DoLog(sLine);
      }

      public void DoLog(byte data, string pre, string post)
      {
         //if (!fLogging) return;
         if (frmDebug == null) return;

         if (pre != String.Empty) pre += ": ";

         string sLine = pre;

         sLine += (data.ToString("X2") + csBlank);

         if (post != String.Empty) sLine += ":" + post;  // eigentlich nur ErrInfo -> hat leading space

         DoLog(sLine);
      }
      #endregion utils

      #region timer events
      private void tmrTimeout_Elapsed(object sender, ElapsedEventArgs e)
      {
         tmrTimeout.Enabled = false;
         fTimeout = true;
         DoLog("Timeout"); //temp
      }

      private void tmrSync_Elapsed(object sender, ElapsedEventArgs e)
      {
         tmrSync.Enabled = false;

         if (Protocol == PROTOCOL.VS2_300)
            DoSyncV2(true);
         else
         { //noop
         }

         tmrSync.Start();
      }
      #endregion timer events

   }

   
   public class FDebug : Form
   {
      public FDebug()
      {
         InitializeComponent();
         lbxInfo.Size = this.ClientSize;
      }


      // Threadsafe Kram
      delegate void ShowInfoD(string msg);
      public void ShowInfo(string msg)
      {
         try
         {
            if (lbxInfo.InvokeRequired)
            {
               ShowInfoD d = new ShowInfoD(ShowInfo);
               Invoke(d, new object[] { msg });
            }
            else
            {
               //lbxInfo.Text = msg;
               lbxInfo.Items.Add(msg);
               lbxInfo.SelectedIndex = lbxInfo.Items.Count - 1;
            }
         }
         catch (Exception) { }
      }


      private void FDebug_ResizeEnd(object sender, EventArgs e)
      {
         lbxInfo.Size = this.ClientSize;
      }

      private void lbxInfo_DoubleClick(object sender, EventArgs e)
      {
         lbxInfo.Items.Clear();
      }

      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lbxInfo = new System.Windows.Forms.ListBox();
         this.SuspendLayout();
         // 
         // lbxInfo
         // 
         this.lbxInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.lbxInfo.FormattingEnabled = true;
         this.lbxInfo.HorizontalScrollbar = true;
         this.lbxInfo.ItemHeight = 16;
         this.lbxInfo.Location = new System.Drawing.Point(0, 0);
         this.lbxInfo.Name = "lbxInfo";
         this.lbxInfo.Size = new System.Drawing.Size(166, 276);
         this.lbxInfo.TabIndex = 0;
         this.lbxInfo.DoubleClick += new System.EventHandler(this.lbxInfo_DoubleClick);
         // 
         // FDebug
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(255, 293);
         this.ControlBox = true;
         this.Controls.Add(this.lbxInfo);
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "FDebug";
         this.Text = "FDebug";
         this.ResizeEnd += new System.EventHandler(this.FDebug_ResizeEnd);
         this.ResumeLayout(false);

      }

      #endregion

      public System.Windows.Forms.ListBox lbxInfo;
   }

}
