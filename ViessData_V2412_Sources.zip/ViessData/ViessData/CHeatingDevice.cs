﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Globalization;

namespace ViessData
{
   public class CHeatingDevice
   {
      private List<CDevice> lstDevices = new List<CDevice>();

      private enum CSVCOLM : int
      {
         DeviceIdent = 0,
         HwSwIdent,
         HwSwIdentTill,
         IdentF0,
         IdentF0Till,
         Description,
         DataPoint
      }

      private enum CSVFLAGS : int
      {
         SwRelevant = 0x01,
         HwRelevant = 0x02,
         F0Relevant = 0x04,
         RelevantMask = 0x0F,
         HwSwTillEmpty = 0x20,
         F0TillEmpty = 0x20
      }



      public bool ReadCsv(string csvfile)
      {
         if (!File.Exists(csvfile))
            return false;

         string[] lines = File.ReadAllLines(csvfile);

         if (lines.Length < 1)
            return false;


         byte bval = 0;
         uint ival = 0;
         string sval = String.Empty;

         lstDevices = new List<CDevice>();

         #region evaluate csv
         string[] values;

         //try
         //{
            //for (int i = lines.GetUpperBound(0); i > 0; i--)
            foreach (string line in lines)
            {
               //string line = lines[i];
               values = line.Split(new char[] { ';' }, StringSplitOptions.None);

               CDevice device = new CDevice();

               // DeviceIdent ++++++++++++++
               sval = values[(int)CSVCOLM.DeviceIdent].Trim().ToUpper().Replace("0X", String.Empty);
               if (!uint.TryParse(sval, NumberStyles.AllowHexSpecifier, null, out ival))
                  continue;
               device.DeviceIdent = ival;

               // HwSwIdent ++++++++++++++
               sval = values[(int)CSVCOLM.HwSwIdent].Trim().ToUpper().Replace("0X", String.Empty); ;
               if (sval != String.Empty)
               {
                  // HwSwIdent not empty
                  device.Flags |= (int)CSVFLAGS.SwRelevant;

                  if (!uint.TryParse(sval, NumberStyles.AllowHexSpecifier, null, out ival))
                     continue;
                  device.HwSwIdent = ival;

                  sval = values[(int)CSVCOLM.HwSwIdentTill].Trim().ToUpper().Replace("0X", String.Empty);
                  if (sval != String.Empty)
                  {
                     if (!uint.TryParse(sval, NumberStyles.AllowHexSpecifier, null, out ival))
                        continue;
                     device.HwSwIdentTill = ival;
                  }
                  else
                  {
                     device.Flags |= (int)CSVFLAGS.HwSwTillEmpty;
                  }
               }


               // IdentF0 ++++++++++++++
               sval = values[(int)CSVCOLM.IdentF0].Trim().ToUpper().Replace("0X", String.Empty);
               if (sval != String.Empty)
               {
                  device.Flags |= (int)CSVFLAGS.F0Relevant;

                  // IdentF0 exist
                  if (!byte.TryParse(sval, NumberStyles.AllowHexSpecifier, null, out bval))
                     continue;
                  device.IdentF0 = bval;

                  sval = values[(int)CSVCOLM.IdentF0Till].Trim().ToUpper().Replace("0X", String.Empty);
                  if (sval != String.Empty)
                  {
                     if (!byte.TryParse(sval, NumberStyles.AllowHexSpecifier, null, out bval))
                        continue;
                     device.IdentF0Till = bval;
                  }
                  else
                  {
                     device.Flags |= (int)CSVFLAGS.F0TillEmpty;
                  }

               }


               // strings
               device.Description = values[(int)CSVCOLM.Description].Trim();
               device.DataPoint = values[(int)CSVCOLM.DataPoint].Trim();

               // add to list
               lstDevices.Add(device);
            }
            #endregion evaluate csv

            #region evaluate flags + fill empty till
            for (int i = 0; i < lstDevices.Count; i++)
            {
               CDevice device = lstDevices[i];

               //if (device.DeviceIdent < 0x2050)
               //{
               //   // only DeviceIdent counts
               //   device.Flags = device.Flags & ~((int)CSVFLAGS.RelevantMask);
               //}
               //else 

               if (device.DeviceIdent == 0x2054)
               {
                  // Bedienteil BT2 und Feuerungsautomat LGM29, alle Software-Indizes
                  device.Flags = (device.Flags & ~((int)CSVFLAGS.RelevantMask));
               }

               else
               {
                  if ((device.Flags & (int)CSVFLAGS.SwRelevant) > 0)
                  {
                     if (device.DeviceIdent <= 0x2090)
                     {
                        // with the older devices also HW Id matters
                        device.Flags |= (int)CSVFLAGS.HwRelevant;
                     }

                     if ((device.Flags & (int)CSVFLAGS.HwSwTillEmpty) > 0)
                     {
                        if (i < lstDevices.Count - 2)
                        {
                           ival = lstDevices[i + 1].HwSwIdent;
                           if (ival < device.HwSwIdent)
                              ival = 0xFFFF;
                        }
                        else
                           ival = 0xFFFF;

                        device.HwSwIdentTill = ival;
                     }
                  }

                  if ((device.Flags & (int)CSVFLAGS.F0Relevant) > 0)
                  {
                     if ((device.Flags & (int)CSVFLAGS.F0TillEmpty) > 0)
                     {
                        if (i < lstDevices.Count - 2)
                        {
                           bval = lstDevices[i + 1].IdentF0;
                           if (bval < device.IdentF0)
                              bval = 0xFF;
                        }
                        else
                           bval = 0xFF;

                        device.IdentF0Till = bval;
                     }
                  }
               }
            }
            #endregion evaluate flags + fill empty till
         //}
         //catch (Exception e)
         //{
         //   Console.WriteLine(e.Message);
         //   Console.WriteLine(e.Source);
         //   Console.WriteLine(e.StackTrace);
         //}

         return (lstDevices.Count > 0);
      }

      public bool GetDevice(byte[] sysident, byte identf0, out CDevice device)
      {
         uint deviceident = (uint)(sysident[0] << 8) + sysident[1];
         uint hwswident = (uint)(sysident[2] << 8) + sysident[3];

         return GetDevice(deviceident, hwswident, identf0, out device);
      }

      public bool GetDevice(uint deviceident, uint hwswident, byte identf0, out CDevice device)
      {
         device = new CDevice();
         uint mask, first, last, relevant;

         foreach (CDevice dev in lstDevices)
         {
            if (dev.DeviceIdent == deviceident)
            {
               mask = 0;

               if ((dev.Flags & (int)CSVFLAGS.SwRelevant) > 0)
                  mask |= 0x00FF;

               if ((dev.Flags & (int)CSVFLAGS.HwRelevant) > 0)
                  mask |= 0xFF00;

               first = dev.HwSwIdent & mask;
               last = dev.HwSwIdentTill & mask;
               relevant = hwswident & mask;

               if ((first <= relevant) && (relevant <= last))
               {
                  if ((dev.Flags & (int)CSVFLAGS.F0Relevant) > 0)
                  {
                     if ((dev.IdentF0 <= identf0) && (identf0 <= dev.IdentF0Till))
                     {
                        device = dev;
                        break;
                     }
                  }
                  else
                  {
                     device = dev;
                     break;
                  }
               }
            }
         }

         return (device != null);
      }

      public string GetDeviceDataPoint(uint deviceident, uint hwswident, byte identf0)
      {
         string ret = String.Empty;
         CDevice dev;

         if (GetDevice(deviceident, hwswident, identf0, out dev))
            ret = dev.DataPoint;

         return ret;
      }

      public string GetDeviceDescrition(uint deviceident, uint hwswident, byte identf0)
      {
         string ret = String.Empty;
         CDevice dev;

         if (GetDevice(deviceident, hwswident, identf0, out dev))
            ret = dev.Description;

         return ret;
      }


      public class CDevice
      {
         public uint DeviceIdent = 0;
         public uint HwSwIdent = 0;
         public uint HwSwIdentTill = 0;
         public byte IdentF0 = 0;
         public byte IdentF0Till = 0;
         public int Flags = 0;
         public string DataPoint = String.Empty;  // DataPoint heisst das in der SQL DB und in den xmls bei Vitosoft...
         public string Description = "<unknown>"; //String.Empty;
      }

   }
}
