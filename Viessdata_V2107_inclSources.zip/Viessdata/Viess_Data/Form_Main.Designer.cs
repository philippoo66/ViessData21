﻿namespace Viess_Data
{
   partial class Main_Form
   {
      /// <summary>
      /// Erforderliche Designervariable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Verwendete Ressourcen bereinigen.
      /// </summary>
      /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Vom Windows Form-Designer generierter Code

      /// <summary>
      /// Erforderliche Methode für die Designerunterstützung.
      /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
      /// </summary>
      private void InitializeComponent()
      {
         this.components = new System.ComponentModel.Container();
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Form));
         this.dataSet1 = new System.Data.DataSet();
         this.dataSet2 = new System.Data.DataSet();
         this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
         this.btnClearErrMsg = new System.Windows.Forms.Button();
         this.TextBox_status = new System.Windows.Forms.TextBox();
         this.tabControl1 = new System.Windows.Forms.TabControl();
         this.tabPage1 = new System.Windows.Forms.TabPage();
         this.label93 = new System.Windows.Forms.Label();
         this.label92 = new System.Windows.Forms.Label();
         this.tbBrennwert = new System.Windows.Forms.TextBox();
         this.tbZZahl = new System.Windows.Forms.TextBox();
         this.label90 = new System.Windows.Forms.Label();
         this.label87 = new System.Windows.Forms.Label();
         this.TB_RTSakt = new System.Windows.Forms.TextBox();
         this.Label_SparA6 = new System.Windows.Forms.Label();
         this.Label_SparA5 = new System.Windows.Forms.Label();
         this.label91 = new System.Windows.Forms.Label();
         this.TextBoxRT = new System.Windows.Forms.TextBox();
         this.TextBoxRL = new System.Windows.Forms.TextBox();
         this.label7 = new System.Windows.Forms.Label();
         this.label89 = new System.Windows.Forms.Label();
         this.TB_MaxBrennerNH = new System.Windows.Forms.TextBox();
         this.label88 = new System.Windows.Forms.Label();
         this.label86 = new System.Windows.Forms.Label();
         this.label85 = new System.Windows.Forms.Label();
         this.label84 = new System.Windows.Forms.Label();
         this.label83 = new System.Windows.Forms.Label();
         this.label82 = new System.Windows.Forms.Label();
         this.label81 = new System.Windows.Forms.Label();
         this.label80 = new System.Windows.Forms.Label();
         this.label79 = new System.Windows.Forms.Label();
         this.label78 = new System.Windows.Forms.Label();
         this.label77 = new System.Windows.Forms.Label();
         this.label76 = new System.Windows.Forms.Label();
         this.label73 = new System.Windows.Forms.Label();
         this.label72 = new System.Windows.Forms.Label();
         this.label71 = new System.Windows.Forms.Label();
         this.label70 = new System.Windows.Forms.Label();
         this.label69 = new System.Windows.Forms.Label();
         this.label68 = new System.Windows.Forms.Label();
         this.textBox3 = new System.Windows.Forms.TextBox();
         this.label67 = new System.Windows.Forms.Label();
         this.CB_SparBrenner = new System.Windows.Forms.ComboBox();
         this.CB_SparHK = new System.Windows.Forms.ComboBox();
         this.label66 = new System.Windows.Forms.Label();
         this.label60 = new System.Windows.Forms.Label();
         this.CB_ZirkuFrequ = new System.Windows.Forms.ComboBox();
         this.TB_DaempfungAT = new System.Windows.Forms.TextBox();
         this.label65 = new System.Windows.Forms.Label();
         this.label64 = new System.Windows.Forms.Label();
         this.TB_NachlaufWW = new System.Windows.Forms.TextBox();
         this.label63 = new System.Windows.Forms.Label();
         this.TB_MaxDeltaKTWW = new System.Windows.Forms.TextBox();
         this.label62 = new System.Windows.Forms.Label();
         this.TB_MaxBrennerWW = new System.Windows.Forms.TextBox();
         this.label61 = new System.Windows.Forms.Label();
         this.TB_PlstbeiRed = new System.Windows.Forms.TextBox();
         this.TB_PlstminbeiNorm = new System.Windows.Forms.TextBox();
         this.TB_PlstmaxbeiNorm = new System.Windows.Forms.TextBox();
         this.ChB_PlstbeiRed = new System.Windows.Forms.CheckBox();
         this.label59 = new System.Windows.Forms.Label();
         this.label58 = new System.Windows.Forms.Label();
         this.label57 = new System.Windows.Forms.Label();
         this.TB_ErhoehungszeitKTS = new System.Windows.Forms.TextBox();
         this.label56 = new System.Windows.Forms.Label();
         this.TB_ErhoehungKTS = new System.Windows.Forms.TextBox();
         this.label55 = new System.Windows.Forms.Label();
         this.TB_PumpebeiWW = new System.Windows.Forms.TextBox();
         this.label54 = new System.Windows.Forms.Label();
         this.CB_Frostschutztemp = new System.Windows.Forms.ComboBox();
         this.label53 = new System.Windows.Forms.Label();
         this.CB_WWHysterese = new System.Windows.Forms.ComboBox();
         this.label19 = new System.Windows.Forms.Label();
         this.label48 = new System.Windows.Forms.Label();
         this.TextBoxWWS = new System.Windows.Forms.TextBox();
         this.label14 = new System.Windows.Forms.Label();
         this.TextBoxRTS_Party = new System.Windows.Forms.TextBox();
         this.TextBox3304 = new System.Windows.Forms.TextBox();
         this.label22 = new System.Windows.Forms.Label();
         this.TextBox3305 = new System.Windows.Forms.TextBox();
         this.TextBoxRTS_Nacht = new System.Windows.Forms.TextBox();
         this.La_Betriebsart = new System.Windows.Forms.Label();
         this.label21 = new System.Windows.Forms.Label();
         this.CB_Betriebsart = new System.Windows.Forms.ComboBox();
         this.label12 = new System.Windows.Forms.Label();
         this.TextBoxRTS_Tag = new System.Windows.Forms.TextBox();
         this.label10 = new System.Windows.Forms.Label();
         this.Frostgefahr = new System.Windows.Forms.Label();
         this.label47 = new System.Windows.Forms.Label();
         this.label29 = new System.Windows.Forms.Label();
         this.label28 = new System.Windows.Forms.Label();
         this.label27 = new System.Windows.Forms.Label();
         this.label26 = new System.Windows.Forms.Label();
         this.label24 = new System.Windows.Forms.Label();
         this.label13 = new System.Windows.Forms.Label();
         this.label9 = new System.Windows.Forms.Label();
         this.ChB_Sparbetrieb = new System.Windows.Forms.CheckBox();
         this.TextBox0812 = new System.Windows.Forms.TextBox();
         this.ChB_Partybetrieb = new System.Windows.Forms.CheckBox();
         this.Label0842 = new System.Windows.Forms.Label();
         this.Label3906 = new System.Windows.Forms.Label();
         this.Label0883 = new System.Windows.Forms.Label();
         this.Label0845 = new System.Windows.Forms.Label();
         this.Label0846 = new System.Windows.Forms.Label();
         this.TextBox081A = new System.Windows.Forms.TextBox();
         this.label46 = new System.Windows.Forms.Label();
         this.TextBox5525 = new System.Windows.Forms.TextBox();
         this.Label11 = new System.Windows.Forms.Label();
         this.Label8 = new System.Windows.Forms.Label();
         this.Label0845a = new System.Windows.Forms.Label();
         this.Label0846a = new System.Windows.Forms.Label();
         this.TextBox088A = new System.Windows.Forms.TextBox();
         this.Label17 = new System.Windows.Forms.Label();
         this.Label15 = new System.Windows.Forms.Label();
         this.TextBox0818 = new System.Windows.Forms.TextBox();
         this.Label0883a = new System.Windows.Forms.Label();
         this.TextBox0810 = new System.Windows.Forms.TextBox();
         this.label30 = new System.Windows.Forms.Label();
         this.label38 = new System.Windows.Forms.Label();
         this.TextBox0808 = new System.Windows.Forms.TextBox();
         this.TextBox080A = new System.Windows.Forms.TextBox();
         this.TextBox080C = new System.Windows.Forms.TextBox();
         this.label39 = new System.Windows.Forms.Label();
         this.TextBox0804 = new System.Windows.Forms.TextBox();
         this.TextBox0802 = new System.Windows.Forms.TextBox();
         this.TextBox0800 = new System.Windows.Forms.TextBox();
         this.label41 = new System.Windows.Forms.Label();
         this.label43 = new System.Windows.Forms.Label();
         this.label44 = new System.Windows.Forms.Label();
         this.TextBox08A7 = new System.Windows.Forms.TextBox();
         this.label23 = new System.Windows.Forms.Label();
         this.tabPage2 = new System.Windows.Forms.TabPage();
         this.btnNewCsv = new System.Windows.Forms.Button();
         this.lblHint = new System.Windows.Forms.Label();
         this.btnClearRowVal = new System.Windows.Forms.Button();
         this.btnWriteDp = new System.Windows.Forms.Button();
         this.btnReadDp = new System.Windows.Forms.Button();
         this.btn_select_kein = new System.Windows.Forms.Button();
         this.btn_select_alle = new System.Windows.Forms.Button();
         this.btnClearChart = new System.Windows.Forms.Button();
         this.gbxComSettings = new System.Windows.Forms.GroupBox();
         this.label6 = new System.Windows.Forms.Label();
         this.CoBx_Handshake = new System.Windows.Forms.ComboBox();
         this.label5 = new System.Windows.Forms.Label();
         this.CoBx_Datenbits = new System.Windows.Forms.ComboBox();
         this.label4 = new System.Windows.Forms.Label();
         this.CoBx_Stopbits = new System.Windows.Forms.ComboBox();
         this.label3 = new System.Windows.Forms.Label();
         this.label2 = new System.Windows.Forms.Label();
         this.CoBx_Parity = new System.Windows.Forms.ComboBox();
         this.Label1 = new System.Windows.Forms.Label();
         this.CoBx_BaudRate = new System.Windows.Forms.ComboBox();
         this.cbxPort = new System.Windows.Forms.ComboBox();
         this.mydataGridView1 = new System.Windows.Forms.DataGridView();
         this.tabPage3 = new System.Windows.Forms.TabPage();
         this.btnSendTimeTable = new System.Windows.Forms.Button();
         this.radioButton3 = new System.Windows.Forms.RadioButton();
         this.radioButton2 = new System.Windows.Forms.RadioButton();
         this.radioButton1 = new System.Windows.Forms.RadioButton();
         this.GroupBox2206 = new System.Windows.Forms.GroupBox();
         this.TextBox154 = new System.Windows.Forms.TextBox();
         this.TextBox146 = new System.Windows.Forms.TextBox();
         this.TextBox138 = new System.Windows.Forms.TextBox();
         this.TextBox130 = new System.Windows.Forms.TextBox();
         this.TextBox155 = new System.Windows.Forms.TextBox();
         this.TextBox147 = new System.Windows.Forms.TextBox();
         this.TextBox139 = new System.Windows.Forms.TextBox();
         this.TextBox131 = new System.Windows.Forms.TextBox();
         this.TextBox123 = new System.Windows.Forms.TextBox();
         this.TextBox122 = new System.Windows.Forms.TextBox();
         this.TextBox115 = new System.Windows.Forms.TextBox();
         this.TextBox114 = new System.Windows.Forms.TextBox();
         this.TextBox107 = new System.Windows.Forms.TextBox();
         this.label51 = new System.Windows.Forms.Label();
         this.label52 = new System.Windows.Forms.Label();
         this.TextBox106 = new System.Windows.Forms.TextBox();
         this.GroupBox2204 = new System.Windows.Forms.GroupBox();
         this.TextBox152 = new System.Windows.Forms.TextBox();
         this.TextBox144 = new System.Windows.Forms.TextBox();
         this.TextBox136 = new System.Windows.Forms.TextBox();
         this.TextBox128 = new System.Windows.Forms.TextBox();
         this.TextBox153 = new System.Windows.Forms.TextBox();
         this.TextBox145 = new System.Windows.Forms.TextBox();
         this.TextBox137 = new System.Windows.Forms.TextBox();
         this.TextBox129 = new System.Windows.Forms.TextBox();
         this.TextBox121 = new System.Windows.Forms.TextBox();
         this.TextBox120 = new System.Windows.Forms.TextBox();
         this.TextBox113 = new System.Windows.Forms.TextBox();
         this.TextBox112 = new System.Windows.Forms.TextBox();
         this.TextBox105 = new System.Windows.Forms.TextBox();
         this.label49 = new System.Windows.Forms.Label();
         this.label50 = new System.Windows.Forms.Label();
         this.TextBox104 = new System.Windows.Forms.TextBox();
         this.GroupBox2202 = new System.Windows.Forms.GroupBox();
         this.TextBox150 = new System.Windows.Forms.TextBox();
         this.TextBox142 = new System.Windows.Forms.TextBox();
         this.TextBox134 = new System.Windows.Forms.TextBox();
         this.TextBox126 = new System.Windows.Forms.TextBox();
         this.TextBox151 = new System.Windows.Forms.TextBox();
         this.TextBox143 = new System.Windows.Forms.TextBox();
         this.TextBox135 = new System.Windows.Forms.TextBox();
         this.TextBox127 = new System.Windows.Forms.TextBox();
         this.TextBox119 = new System.Windows.Forms.TextBox();
         this.TextBox118 = new System.Windows.Forms.TextBox();
         this.TextBox111 = new System.Windows.Forms.TextBox();
         this.TextBox110 = new System.Windows.Forms.TextBox();
         this.TextBox103 = new System.Windows.Forms.TextBox();
         this.label16 = new System.Windows.Forms.Label();
         this.label18 = new System.Windows.Forms.Label();
         this.TextBox102 = new System.Windows.Forms.TextBox();
         this.TextBox0200 = new System.Windows.Forms.TextBox();
         this.Label42 = new System.Windows.Forms.Label();
         this.Label40 = new System.Windows.Forms.Label();
         this.Label37 = new System.Windows.Forms.Label();
         this.Label36 = new System.Windows.Forms.Label();
         this.Label35 = new System.Windows.Forms.Label();
         this.Label34 = new System.Windows.Forms.Label();
         this.Label33 = new System.Windows.Forms.Label();
         this.Label32 = new System.Windows.Forms.Label();
         this.Label31 = new System.Windows.Forms.Label();
         this.GroupBox2200 = new System.Windows.Forms.GroupBox();
         this.TextBox148 = new System.Windows.Forms.TextBox();
         this.TextBox140 = new System.Windows.Forms.TextBox();
         this.TextBox132 = new System.Windows.Forms.TextBox();
         this.TextBox124 = new System.Windows.Forms.TextBox();
         this.TextBox149 = new System.Windows.Forms.TextBox();
         this.TextBox141 = new System.Windows.Forms.TextBox();
         this.TextBox133 = new System.Windows.Forms.TextBox();
         this.TextBox125 = new System.Windows.Forms.TextBox();
         this.TextBox117 = new System.Windows.Forms.TextBox();
         this.TextBox116 = new System.Windows.Forms.TextBox();
         this.TextBox109 = new System.Windows.Forms.TextBox();
         this.TextBox108 = new System.Windows.Forms.TextBox();
         this.TextBox101 = new System.Windows.Forms.TextBox();
         this.Label74 = new System.Windows.Forms.Label();
         this.Label75 = new System.Windows.Forms.Label();
         this.TextBox100 = new System.Windows.Forms.TextBox();
         this.tabPage4 = new System.Windows.Forms.TabPage();
         this.plotterDisplayEx1 = new GraphLib.PlotterDisplayEx();
         this.tabPage5 = new System.Windows.Forms.TabPage();
         this.gbxStats = new System.Windows.Forms.GroupBox();
         this.groupBox6 = new System.Windows.Forms.GroupBox();
         this.label20 = new System.Windows.Forms.Label();
         this.btnRefreshData = new System.Windows.Forms.Button();
         this.mydataGridView2 = new System.Windows.Forms.DataGridView();
         this.groupBox5 = new System.Windows.Forms.GroupBox();
         this.label45 = new System.Windows.Forms.Label();
         this.label25 = new System.Windows.Forms.Label();
         this.btnLoadOtherCsv = new System.Windows.Forms.Button();
         this.tbDataFile = new System.Windows.Forms.TextBox();
         this.tbCurrDataFile = new System.Windows.Forms.TextBox();
         this.btnLoadCurrCsv = new System.Windows.Forms.Button();
         this.toolStrip1 = new System.Windows.Forms.ToolStrip();
         this.tsbtnSaveAll = new System.Windows.Forms.ToolStripButton();
         this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
         this.tsbtnReadAll = new System.Windows.Forms.ToolStripButton();
         this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
         this.tscbPollInterval = new System.Windows.Forms.ToolStripComboBox();
         this.tsbtnStartStop = new System.Windows.Forms.ToolStripButton();
         this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
         this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
         this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
         this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
         this.tscbGraphArea = new System.Windows.Forms.ToolStripComboBox();
         this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
         this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
         this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
         this.toolStripLabel5 = new System.Windows.Forms.ToolStripLabel();
         this.toolStripTextBox2 = new System.Windows.Forms.ToolStripTextBox();
         this.tsbtnInfo = new System.Windows.Forms.ToolStripButton();
         ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
         ((System.ComponentModel.ISupportInitialize)(this.dataSet2)).BeginInit();
         this.tabControl1.SuspendLayout();
         this.tabPage1.SuspendLayout();
         this.tabPage2.SuspendLayout();
         this.gbxComSettings.SuspendLayout();
         ((System.ComponentModel.ISupportInitialize)(this.mydataGridView1)).BeginInit();
         this.tabPage3.SuspendLayout();
         this.GroupBox2206.SuspendLayout();
         this.GroupBox2204.SuspendLayout();
         this.GroupBox2202.SuspendLayout();
         this.GroupBox2200.SuspendLayout();
         this.tabPage4.SuspendLayout();
         this.tabPage5.SuspendLayout();
         this.gbxStats.SuspendLayout();
         this.groupBox6.SuspendLayout();
         ((System.ComponentModel.ISupportInitialize)(this.mydataGridView2)).BeginInit();
         this.groupBox5.SuspendLayout();
         this.toolStrip1.SuspendLayout();
         this.SuspendLayout();
         // 
         // dataSet1
         // 
         this.dataSet1.DataSetName = "NewDataSet";
         // 
         // dataSet2
         // 
         this.dataSet2.DataSetName = "NewDataSet";
         // 
         // openFileDialog1
         // 
         this.openFileDialog1.FileName = "openFileDialog1";
         // 
         // btnClearErrMsg
         // 
         this.btnClearErrMsg.BackColor = System.Drawing.SystemColors.ButtonFace;
         this.btnClearErrMsg.Location = new System.Drawing.Point(616, 19);
         this.btnClearErrMsg.Name = "btnClearErrMsg";
         this.btnClearErrMsg.Size = new System.Drawing.Size(57, 24);
         this.btnClearErrMsg.TabIndex = 515;
         this.btnClearErrMsg.Text = "löschen";
         this.btnClearErrMsg.UseVisualStyleBackColor = false;
         this.btnClearErrMsg.Click += new System.EventHandler(this.btnClearErrMsg_Click);
         // 
         // TextBox_status
         // 
         this.TextBox_status.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox_status.Location = new System.Drawing.Point(174, 18);
         this.TextBox_status.Name = "TextBox_status";
         this.TextBox_status.Size = new System.Drawing.Size(436, 25);
         this.TextBox_status.TabIndex = 147;
         this.TextBox_status.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // tabControl1
         // 
         this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
         this.tabControl1.Controls.Add(this.tabPage1);
         this.tabControl1.Controls.Add(this.tabPage2);
         this.tabControl1.Controls.Add(this.tabPage3);
         this.tabControl1.Controls.Add(this.tabPage4);
         this.tabControl1.Controls.Add(this.tabPage5);
         this.tabControl1.Location = new System.Drawing.Point(0, 37);
         this.tabControl1.Name = "tabControl1";
         this.tabControl1.SelectedIndex = 0;
         this.tabControl1.Size = new System.Drawing.Size(984, 517);
         this.tabControl1.TabIndex = 160;
         this.tabControl1.Click += new System.EventHandler(this.TabControl1_SelectedIndexChanged);
         // 
         // tabPage1
         // 
         this.tabPage1.Controls.Add(this.label93);
         this.tabPage1.Controls.Add(this.label92);
         this.tabPage1.Controls.Add(this.tbBrennwert);
         this.tabPage1.Controls.Add(this.tbZZahl);
         this.tabPage1.Controls.Add(this.label90);
         this.tabPage1.Controls.Add(this.label87);
         this.tabPage1.Controls.Add(this.TB_RTSakt);
         this.tabPage1.Controls.Add(this.Label_SparA6);
         this.tabPage1.Controls.Add(this.Label_SparA5);
         this.tabPage1.Controls.Add(this.label91);
         this.tabPage1.Controls.Add(this.TextBoxRT);
         this.tabPage1.Controls.Add(this.TextBoxRL);
         this.tabPage1.Controls.Add(this.label7);
         this.tabPage1.Controls.Add(this.label89);
         this.tabPage1.Controls.Add(this.TB_MaxBrennerNH);
         this.tabPage1.Controls.Add(this.label88);
         this.tabPage1.Controls.Add(this.label86);
         this.tabPage1.Controls.Add(this.label85);
         this.tabPage1.Controls.Add(this.label84);
         this.tabPage1.Controls.Add(this.label83);
         this.tabPage1.Controls.Add(this.label82);
         this.tabPage1.Controls.Add(this.label81);
         this.tabPage1.Controls.Add(this.label80);
         this.tabPage1.Controls.Add(this.label79);
         this.tabPage1.Controls.Add(this.label78);
         this.tabPage1.Controls.Add(this.label77);
         this.tabPage1.Controls.Add(this.label76);
         this.tabPage1.Controls.Add(this.label73);
         this.tabPage1.Controls.Add(this.label72);
         this.tabPage1.Controls.Add(this.label71);
         this.tabPage1.Controls.Add(this.label70);
         this.tabPage1.Controls.Add(this.label69);
         this.tabPage1.Controls.Add(this.label68);
         this.tabPage1.Controls.Add(this.textBox3);
         this.tabPage1.Controls.Add(this.label67);
         this.tabPage1.Controls.Add(this.CB_SparBrenner);
         this.tabPage1.Controls.Add(this.CB_SparHK);
         this.tabPage1.Controls.Add(this.label66);
         this.tabPage1.Controls.Add(this.label60);
         this.tabPage1.Controls.Add(this.CB_ZirkuFrequ);
         this.tabPage1.Controls.Add(this.TB_DaempfungAT);
         this.tabPage1.Controls.Add(this.label65);
         this.tabPage1.Controls.Add(this.label64);
         this.tabPage1.Controls.Add(this.TB_NachlaufWW);
         this.tabPage1.Controls.Add(this.label63);
         this.tabPage1.Controls.Add(this.TB_MaxDeltaKTWW);
         this.tabPage1.Controls.Add(this.label62);
         this.tabPage1.Controls.Add(this.TB_MaxBrennerWW);
         this.tabPage1.Controls.Add(this.label61);
         this.tabPage1.Controls.Add(this.TB_PlstbeiRed);
         this.tabPage1.Controls.Add(this.TB_PlstminbeiNorm);
         this.tabPage1.Controls.Add(this.TB_PlstmaxbeiNorm);
         this.tabPage1.Controls.Add(this.ChB_PlstbeiRed);
         this.tabPage1.Controls.Add(this.label59);
         this.tabPage1.Controls.Add(this.label58);
         this.tabPage1.Controls.Add(this.label57);
         this.tabPage1.Controls.Add(this.TB_ErhoehungszeitKTS);
         this.tabPage1.Controls.Add(this.label56);
         this.tabPage1.Controls.Add(this.TB_ErhoehungKTS);
         this.tabPage1.Controls.Add(this.label55);
         this.tabPage1.Controls.Add(this.TB_PumpebeiWW);
         this.tabPage1.Controls.Add(this.label54);
         this.tabPage1.Controls.Add(this.CB_Frostschutztemp);
         this.tabPage1.Controls.Add(this.label53);
         this.tabPage1.Controls.Add(this.CB_WWHysterese);
         this.tabPage1.Controls.Add(this.label19);
         this.tabPage1.Controls.Add(this.label48);
         this.tabPage1.Controls.Add(this.TextBoxWWS);
         this.tabPage1.Controls.Add(this.label14);
         this.tabPage1.Controls.Add(this.TextBoxRTS_Party);
         this.tabPage1.Controls.Add(this.TextBox3304);
         this.tabPage1.Controls.Add(this.label22);
         this.tabPage1.Controls.Add(this.TextBox3305);
         this.tabPage1.Controls.Add(this.TextBoxRTS_Nacht);
         this.tabPage1.Controls.Add(this.La_Betriebsart);
         this.tabPage1.Controls.Add(this.label21);
         this.tabPage1.Controls.Add(this.CB_Betriebsart);
         this.tabPage1.Controls.Add(this.label12);
         this.tabPage1.Controls.Add(this.TextBoxRTS_Tag);
         this.tabPage1.Controls.Add(this.label10);
         this.tabPage1.Controls.Add(this.Frostgefahr);
         this.tabPage1.Controls.Add(this.label47);
         this.tabPage1.Controls.Add(this.label29);
         this.tabPage1.Controls.Add(this.label28);
         this.tabPage1.Controls.Add(this.label27);
         this.tabPage1.Controls.Add(this.label26);
         this.tabPage1.Controls.Add(this.label24);
         this.tabPage1.Controls.Add(this.label13);
         this.tabPage1.Controls.Add(this.label9);
         this.tabPage1.Controls.Add(this.ChB_Sparbetrieb);
         this.tabPage1.Controls.Add(this.TextBox0812);
         this.tabPage1.Controls.Add(this.ChB_Partybetrieb);
         this.tabPage1.Controls.Add(this.Label0842);
         this.tabPage1.Controls.Add(this.Label3906);
         this.tabPage1.Controls.Add(this.Label0883);
         this.tabPage1.Controls.Add(this.Label0845);
         this.tabPage1.Controls.Add(this.Label0846);
         this.tabPage1.Controls.Add(this.TextBox081A);
         this.tabPage1.Controls.Add(this.label46);
         this.tabPage1.Controls.Add(this.TextBox5525);
         this.tabPage1.Controls.Add(this.Label11);
         this.tabPage1.Controls.Add(this.Label8);
         this.tabPage1.Controls.Add(this.Label0845a);
         this.tabPage1.Controls.Add(this.Label0846a);
         this.tabPage1.Controls.Add(this.TextBox088A);
         this.tabPage1.Controls.Add(this.Label17);
         this.tabPage1.Controls.Add(this.Label15);
         this.tabPage1.Controls.Add(this.TextBox0818);
         this.tabPage1.Controls.Add(this.Label0883a);
         this.tabPage1.Controls.Add(this.TextBox0810);
         this.tabPage1.Controls.Add(this.label30);
         this.tabPage1.Controls.Add(this.label38);
         this.tabPage1.Controls.Add(this.TextBox0808);
         this.tabPage1.Controls.Add(this.TextBox080A);
         this.tabPage1.Controls.Add(this.TextBox080C);
         this.tabPage1.Controls.Add(this.label39);
         this.tabPage1.Controls.Add(this.TextBox0804);
         this.tabPage1.Controls.Add(this.TextBox0802);
         this.tabPage1.Controls.Add(this.TextBox0800);
         this.tabPage1.Controls.Add(this.label41);
         this.tabPage1.Controls.Add(this.label43);
         this.tabPage1.Controls.Add(this.label44);
         this.tabPage1.Controls.Add(this.TextBox08A7);
         this.tabPage1.Controls.Add(this.label23);
         this.tabPage1.Location = new System.Drawing.Point(4, 22);
         this.tabPage1.Name = "tabPage1";
         this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
         this.tabPage1.Size = new System.Drawing.Size(976, 491);
         this.tabPage1.TabIndex = 0;
         this.tabPage1.Text = "Übersicht";
         this.tabPage1.UseVisualStyleBackColor = true;
         // 
         // label93
         // 
         this.label93.AutoSize = true;
         this.label93.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label93.Location = new System.Drawing.Point(275, 361);
         this.label93.Name = "label93";
         this.label93.Size = new System.Drawing.Size(9, 9);
         this.label93.TabIndex = 235;
         this.label93.Text = "3";
         this.label93.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label92
         // 
         this.label92.AutoSize = true;
         this.label92.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label92.Location = new System.Drawing.Point(239, 363);
         this.label92.Name = "label92";
         this.label92.Size = new System.Drawing.Size(43, 16);
         this.label92.TabIndex = 234;
         this.label92.Text = "kW/m";
         this.label92.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // tbBrennwert
         // 
         this.tbBrennwert.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.tbBrennwert.Location = new System.Drawing.Point(184, 362);
         this.tbBrennwert.Name = "tbBrennwert";
         this.tbBrennwert.Size = new System.Drawing.Size(55, 20);
         this.tbBrennwert.TabIndex = 12;
         this.tbBrennwert.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.tbBrennwert.Leave += new System.EventHandler(this.tbBrennwert_Leave);
         // 
         // tbZZahl
         // 
         this.tbZZahl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.tbZZahl.Location = new System.Drawing.Point(184, 336);
         this.tbZZahl.Name = "tbZZahl";
         this.tbZZahl.Size = new System.Drawing.Size(55, 20);
         this.tbZZahl.TabIndex = 11;
         this.tbZZahl.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.tbZZahl.Leave += new System.EventHandler(this.tbZZahl_Leave);
         // 
         // label90
         // 
         this.label90.AutoSize = true;
         this.label90.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label90.Location = new System.Drawing.Point(19, 361);
         this.label90.Name = "label90";
         this.label90.Size = new System.Drawing.Size(94, 16);
         this.label90.TabIndex = 233;
         this.label90.Text = "Gas Brennwert";
         this.label90.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label87
         // 
         this.label87.AutoSize = true;
         this.label87.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label87.Location = new System.Drawing.Point(19, 336);
         this.label87.Name = "label87";
         this.label87.Size = new System.Drawing.Size(113, 16);
         this.label87.TabIndex = 232;
         this.label87.Text = "Gas Zustandszahl";
         this.label87.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TB_RTSakt
         // 
         this.TB_RTSakt.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TB_RTSakt.Location = new System.Drawing.Point(857, 82);
         this.TB_RTSakt.Name = "TB_RTSakt";
         this.TB_RTSakt.Size = new System.Drawing.Size(50, 22);
         this.TB_RTSakt.TabIndex = 231;
         this.TB_RTSakt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // Label_SparA6
         // 
         this.Label_SparA6.AllowDrop = true;
         this.Label_SparA6.BackColor = System.Drawing.Color.LightPink;
         this.Label_SparA6.Location = new System.Drawing.Point(622, 438);
         this.Label_SparA6.Name = "Label_SparA6";
         this.Label_SparA6.Size = new System.Drawing.Size(15, 15);
         this.Label_SparA6.TabIndex = 230;
         // 
         // Label_SparA5
         // 
         this.Label_SparA5.AllowDrop = true;
         this.Label_SparA5.BackColor = System.Drawing.Color.LightPink;
         this.Label_SparA5.Location = new System.Drawing.Point(622, 412);
         this.Label_SparA5.Name = "Label_SparA5";
         this.Label_SparA5.Size = new System.Drawing.Size(15, 15);
         this.Label_SparA5.TabIndex = 229;
         // 
         // label91
         // 
         this.label91.AutoSize = true;
         this.label91.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label91.Location = new System.Drawing.Point(682, 85);
         this.label91.Name = "label91";
         this.label91.Size = new System.Drawing.Size(75, 16);
         this.label91.TabIndex = 228;
         this.label91.Text = "Raumtemp.";
         this.label91.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TextBoxRT
         // 
         this.TextBoxRT.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBoxRT.Location = new System.Drawing.Point(803, 82);
         this.TextBoxRT.Name = "TextBoxRT";
         this.TextBoxRT.Size = new System.Drawing.Size(50, 22);
         this.TextBoxRT.TabIndex = 227;
         this.TextBoxRT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TextBoxRT.Visible = false;
         // 
         // TextBoxRL
         // 
         this.TextBoxRL.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBoxRL.Location = new System.Drawing.Point(803, 132);
         this.TextBoxRL.Name = "TextBoxRL";
         this.TextBoxRL.Size = new System.Drawing.Size(50, 22);
         this.TextBoxRL.TabIndex = 224;
         this.TextBoxRL.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TextBoxRL.Visible = false;
         // 
         // label7
         // 
         this.label7.AutoSize = true;
         this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label7.Location = new System.Drawing.Point(682, 135);
         this.label7.Name = "label7";
         this.label7.Size = new System.Drawing.Size(91, 16);
         this.label7.TabIndex = 223;
         this.label7.Text = "Rücklauftemp.";
         this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         this.label7.Visible = false;
         // 
         // label89
         // 
         this.label89.AutoSize = true;
         this.label89.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label89.Location = new System.Drawing.Point(617, 135);
         this.label89.Name = "label89";
         this.label89.Size = new System.Drawing.Size(20, 16);
         this.label89.TabIndex = 222;
         this.label89.Text = "%";
         this.label89.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TB_MaxBrennerNH
         // 
         this.TB_MaxBrennerNH.Location = new System.Drawing.Point(590, 135);
         this.TB_MaxBrennerNH.Name = "TB_MaxBrennerNH";
         this.TB_MaxBrennerNH.Size = new System.Drawing.Size(25, 20);
         this.TB_MaxBrennerNH.TabIndex = 19;
         this.TB_MaxBrennerNH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TB_MaxBrennerNH.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TB_MaxBrennerHK_Leave);
         // 
         // label88
         // 
         this.label88.AutoSize = true;
         this.label88.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label88.Location = new System.Drawing.Point(299, 135);
         this.label88.Name = "label88";
         this.label88.Size = new System.Drawing.Size(256, 16);
         this.label88.TabIndex = 220;
         this.label88.Text = "Max. Brennerleistung bei Normheizbetrieb";
         this.label88.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label86
         // 
         this.label86.AutoSize = true;
         this.label86.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label86.Location = new System.Drawing.Point(617, 360);
         this.label86.Name = "label86";
         this.label86.Size = new System.Drawing.Size(29, 16);
         this.label86.TabIndex = 218;
         this.label86.Text = "min";
         this.label86.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label85
         // 
         this.label85.AutoSize = true;
         this.label85.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label85.Location = new System.Drawing.Point(617, 336);
         this.label85.Name = "label85";
         this.label85.Size = new System.Drawing.Size(20, 16);
         this.label85.TabIndex = 217;
         this.label85.Text = "%";
         this.label85.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label84
         // 
         this.label84.AutoSize = true;
         this.label84.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label84.Location = new System.Drawing.Point(618, 311);
         this.label84.Name = "label84";
         this.label84.Size = new System.Drawing.Size(20, 16);
         this.label84.TabIndex = 216;
         this.label84.Text = "%";
         this.label84.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label83
         // 
         this.label83.AutoSize = true;
         this.label83.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label83.Location = new System.Drawing.Point(617, 235);
         this.label83.Name = "label83";
         this.label83.Size = new System.Drawing.Size(20, 16);
         this.label83.TabIndex = 215;
         this.label83.Text = "%";
         this.label83.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label82
         // 
         this.label82.AutoSize = true;
         this.label82.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label82.Location = new System.Drawing.Point(617, 210);
         this.label82.Name = "label82";
         this.label82.Size = new System.Drawing.Size(20, 16);
         this.label82.TabIndex = 214;
         this.label82.Text = "%";
         this.label82.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label81
         // 
         this.label81.AutoSize = true;
         this.label81.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label81.Location = new System.Drawing.Point(239, 311);
         this.label81.Name = "label81";
         this.label81.Size = new System.Drawing.Size(28, 16);
         this.label81.TabIndex = 213;
         this.label81.Text = "kW";
         this.label81.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label80
         // 
         this.label80.AutoSize = true;
         this.label80.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label80.Location = new System.Drawing.Point(617, 184);
         this.label80.Name = "label80";
         this.label80.Size = new System.Drawing.Size(21, 16);
         this.label80.TabIndex = 212;
         this.label80.Text = "°C";
         this.label80.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label79
         // 
         this.label79.AutoSize = true;
         this.label79.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label79.Location = new System.Drawing.Point(617, 160);
         this.label79.Name = "label79";
         this.label79.Size = new System.Drawing.Size(20, 16);
         this.label79.TabIndex = 211;
         this.label79.Text = "%";
         this.label79.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label78
         // 
         this.label78.AutoSize = true;
         this.label78.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label78.Location = new System.Drawing.Point(617, 110);
         this.label78.Name = "label78";
         this.label78.Size = new System.Drawing.Size(21, 16);
         this.label78.TabIndex = 210;
         this.label78.Text = "°C";
         this.label78.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label77
         // 
         this.label77.AutoSize = true;
         this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label77.Location = new System.Drawing.Point(617, 85);
         this.label77.Name = "label77";
         this.label77.Size = new System.Drawing.Size(29, 16);
         this.label77.TabIndex = 209;
         this.label77.Text = "min";
         this.label77.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label76
         // 
         this.label76.AutoSize = true;
         this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label76.Location = new System.Drawing.Point(617, 60);
         this.label76.Name = "label76";
         this.label76.Size = new System.Drawing.Size(20, 16);
         this.label76.TabIndex = 208;
         this.label76.Text = "%";
         this.label76.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label73
         // 
         this.label73.AutoSize = true;
         this.label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label73.Location = new System.Drawing.Point(617, 35);
         this.label73.Name = "label73";
         this.label73.Size = new System.Drawing.Size(29, 16);
         this.label73.TabIndex = 207;
         this.label73.Text = "min";
         this.label73.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label72
         // 
         this.label72.AutoSize = true;
         this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label72.Location = new System.Drawing.Point(239, 160);
         this.label72.Name = "label72";
         this.label72.Size = new System.Drawing.Size(21, 16);
         this.label72.TabIndex = 206;
         this.label72.Text = "°C";
         this.label72.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label71
         // 
         this.label71.AutoSize = true;
         this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label71.Location = new System.Drawing.Point(239, 185);
         this.label71.Name = "label71";
         this.label71.Size = new System.Drawing.Size(21, 16);
         this.label71.TabIndex = 205;
         this.label71.Text = "°C";
         this.label71.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label70
         // 
         this.label70.AutoSize = true;
         this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label70.Location = new System.Drawing.Point(239, 210);
         this.label70.Name = "label70";
         this.label70.Size = new System.Drawing.Size(21, 16);
         this.label70.TabIndex = 204;
         this.label70.Text = "°C";
         this.label70.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label69
         // 
         this.label69.AutoSize = true;
         this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label69.Location = new System.Drawing.Point(618, 260);
         this.label69.Name = "label69";
         this.label69.Size = new System.Drawing.Size(21, 16);
         this.label69.TabIndex = 203;
         this.label69.Text = "°C";
         this.label69.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label68
         // 
         this.label68.AutoSize = true;
         this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label68.Location = new System.Drawing.Point(239, 135);
         this.label68.Name = "label68";
         this.label68.Size = new System.Drawing.Size(21, 16);
         this.label68.TabIndex = 202;
         this.label68.Text = "°C";
         this.label68.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // textBox3
         // 
         this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.textBox3.Location = new System.Drawing.Point(184, 310);
         this.textBox3.Name = "textBox3";
         this.textBox3.Size = new System.Drawing.Size(55, 20);
         this.textBox3.TabIndex = 10;
         this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.textBox3.Leave += new System.EventHandler(this.textBox3__Leave);
         // 
         // label67
         // 
         this.label67.AutoSize = true;
         this.label67.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label67.Location = new System.Drawing.Point(18, 311);
         this.label67.Name = "label67";
         this.label67.Size = new System.Drawing.Size(152, 16);
         this.label67.TabIndex = 200;
         this.label67.Text = "Nennleistung der Therme";
         this.label67.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // CB_SparBrenner
         // 
         this.CB_SparBrenner.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.CB_SparBrenner.FormattingEnabled = true;
         this.CB_SparBrenner.Location = new System.Drawing.Point(520, 434);
         this.CB_SparBrenner.Name = "CB_SparBrenner";
         this.CB_SparBrenner.RightToLeft = System.Windows.Forms.RightToLeft.No;
         this.CB_SparBrenner.Size = new System.Drawing.Size(95, 21);
         this.CB_SparBrenner.TabIndex = 33;
         this.CB_SparBrenner.KeyUp += new System.Windows.Forms.KeyEventHandler(this.CB_SparBrenner_Leave);
         // 
         // CB_SparHK
         // 
         this.CB_SparHK.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.CB_SparHK.FormattingEnabled = true;
         this.CB_SparHK.Location = new System.Drawing.Point(520, 409);
         this.CB_SparHK.Name = "CB_SparHK";
         this.CB_SparHK.RightToLeft = System.Windows.Forms.RightToLeft.No;
         this.CB_SparHK.Size = new System.Drawing.Size(95, 21);
         this.CB_SparHK.TabIndex = 32;
         this.CB_SparHK.KeyUp += new System.Windows.Forms.KeyEventHandler(this.CB_SparHK_Leave);
         // 
         // label66
         // 
         this.label66.AutoSize = true;
         this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label66.Location = new System.Drawing.Point(299, 410);
         this.label66.Name = "label66";
         this.label66.Size = new System.Drawing.Size(162, 16);
         this.label66.TabIndex = 199;
         this.label66.Text = "Sparschaltung HK-Pumpe";
         this.label66.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label60
         // 
         this.label60.AutoSize = true;
         this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label60.Location = new System.Drawing.Point(299, 435);
         this.label60.Name = "label60";
         this.label60.Size = new System.Drawing.Size(215, 16);
         this.label60.TabIndex = 198;
         this.label60.Text = "Sparschaltung Brenner und Pumpe";
         this.label60.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // CB_ZirkuFrequ
         // 
         this.CB_ZirkuFrequ.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.CB_ZirkuFrequ.FormattingEnabled = true;
         this.CB_ZirkuFrequ.Location = new System.Drawing.Point(520, 384);
         this.CB_ZirkuFrequ.Name = "CB_ZirkuFrequ";
         this.CB_ZirkuFrequ.RightToLeft = System.Windows.Forms.RightToLeft.No;
         this.CB_ZirkuFrequ.Size = new System.Drawing.Size(95, 21);
         this.CB_ZirkuFrequ.TabIndex = 31;
         this.CB_ZirkuFrequ.KeyUp += new System.Windows.Forms.KeyEventHandler(this.CB_ZirkuFrequ_Leave);
         // 
         // TB_DaempfungAT
         // 
         this.TB_DaempfungAT.Location = new System.Drawing.Point(567, 34);
         this.TB_DaempfungAT.Name = "TB_DaempfungAT";
         this.TB_DaempfungAT.Size = new System.Drawing.Size(48, 20);
         this.TB_DaempfungAT.TabIndex = 15;
         this.TB_DaempfungAT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TB_DaempfungAT.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TB_DaempfungAT_Leave);
         // 
         // label65
         // 
         this.label65.AutoSize = true;
         this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label65.Location = new System.Drawing.Point(299, 385);
         this.label65.Name = "label65";
         this.label65.Size = new System.Drawing.Size(138, 16);
         this.label65.TabIndex = 195;
         this.label65.Text = "Zirkupumpe Frequenz";
         this.label65.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label64
         // 
         this.label64.AutoSize = true;
         this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label64.Location = new System.Drawing.Point(299, 35);
         this.label64.Name = "label64";
         this.label64.Size = new System.Drawing.Size(259, 16);
         this.label64.TabIndex = 194;
         this.label64.Text = "Zeitkonstante Dämpfung Außentemperatur";
         this.label64.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TB_NachlaufWW
         // 
         this.TB_NachlaufWW.Location = new System.Drawing.Point(590, 360);
         this.TB_NachlaufWW.Name = "TB_NachlaufWW";
         this.TB_NachlaufWW.Size = new System.Drawing.Size(25, 20);
         this.TB_NachlaufWW.TabIndex = 30;
         this.TB_NachlaufWW.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TB_NachlaufWW.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TB_NachlaufWW_Leave);
         // 
         // label63
         // 
         this.label63.AutoSize = true;
         this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label63.Location = new System.Drawing.Point(299, 360);
         this.label63.Name = "label63";
         this.label63.Size = new System.Drawing.Size(249, 16);
         this.label63.TabIndex = 192;
         this.label63.Text = "Pumpennachlaufzeit nach WW Bereitung";
         this.label63.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TB_MaxDeltaKTWW
         // 
         this.TB_MaxDeltaKTWW.Location = new System.Drawing.Point(590, 184);
         this.TB_MaxDeltaKTWW.Name = "TB_MaxDeltaKTWW";
         this.TB_MaxDeltaKTWW.Size = new System.Drawing.Size(25, 20);
         this.TB_MaxDeltaKTWW.TabIndex = 21;
         this.TB_MaxDeltaKTWW.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TB_MaxDeltaKTWW.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TB_MaxDeltaKTWW_Leave);
         // 
         // label62
         // 
         this.label62.AutoSize = true;
         this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label62.Location = new System.Drawing.Point(299, 185);
         this.label62.Name = "label62";
         this.label62.Size = new System.Drawing.Size(190, 16);
         this.label62.TabIndex = 190;
         this.label62.Text = "Max. Delta KT-Soll zu WW-Soll";
         this.label62.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TB_MaxBrennerWW
         // 
         this.TB_MaxBrennerWW.Location = new System.Drawing.Point(590, 160);
         this.TB_MaxBrennerWW.Name = "TB_MaxBrennerWW";
         this.TB_MaxBrennerWW.Size = new System.Drawing.Size(25, 20);
         this.TB_MaxBrennerWW.TabIndex = 20;
         this.TB_MaxBrennerWW.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TB_MaxBrennerWW.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TB_MaxBrennerWW_Leave);
         // 
         // label61
         // 
         this.label61.AutoSize = true;
         this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label61.Location = new System.Drawing.Point(299, 160);
         this.label61.Name = "label61";
         this.label61.Size = new System.Drawing.Size(243, 16);
         this.label61.TabIndex = 188;
         this.label61.Text = "Max. Brennerleistung bei WW Bereitung";
         this.label61.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TB_PlstbeiRed
         // 
         this.TB_PlstbeiRed.Location = new System.Drawing.Point(590, 309);
         this.TB_PlstbeiRed.Name = "TB_PlstbeiRed";
         this.TB_PlstbeiRed.Size = new System.Drawing.Size(25, 20);
         this.TB_PlstbeiRed.TabIndex = 28;
         this.TB_PlstbeiRed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TB_PlstbeiRed.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TB_PlstbeiRed_Leave);
         // 
         // TB_PlstminbeiNorm
         // 
         this.TB_PlstminbeiNorm.Location = new System.Drawing.Point(590, 209);
         this.TB_PlstminbeiNorm.Name = "TB_PlstminbeiNorm";
         this.TB_PlstminbeiNorm.Size = new System.Drawing.Size(25, 20);
         this.TB_PlstminbeiNorm.TabIndex = 22;
         this.TB_PlstminbeiNorm.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TB_PlstminbeiNorm.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TB_PlstminbeiNorm_Leave);
         // 
         // TB_PlstmaxbeiNorm
         // 
         this.TB_PlstmaxbeiNorm.Location = new System.Drawing.Point(590, 234);
         this.TB_PlstmaxbeiNorm.Name = "TB_PlstmaxbeiNorm";
         this.TB_PlstmaxbeiNorm.Size = new System.Drawing.Size(25, 20);
         this.TB_PlstmaxbeiNorm.TabIndex = 23;
         this.TB_PlstmaxbeiNorm.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TB_PlstmaxbeiNorm.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TB_PlstmaxbeiNorm_Leave);
         // 
         // ChB_PlstbeiRed
         // 
         this.ChB_PlstbeiRed.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
         this.ChB_PlstbeiRed.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
         this.ChB_PlstbeiRed.Location = new System.Drawing.Point(297, 284);
         this.ChB_PlstbeiRed.Name = "ChB_PlstbeiRed";
         this.ChB_PlstbeiRed.Size = new System.Drawing.Size(318, 21);
         this.ChB_PlstbeiRed.TabIndex = 25;
         this.ChB_PlstbeiRed.Text = "Fixe Pumpenleistung im reduzierten Betrieb";
         this.ChB_PlstbeiRed.UseVisualStyleBackColor = true;
         this.ChB_PlstbeiRed.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ChB_PlstbeiRed_Leave);
         // 
         // label59
         // 
         this.label59.AutoSize = true;
         this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label59.Location = new System.Drawing.Point(299, 210);
         this.label59.Name = "label59";
         this.label59.Size = new System.Drawing.Size(231, 16);
         this.label59.TabIndex = 181;
         this.label59.Text = "Pumpenleistung min. bei Normbetrieb";
         this.label59.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label58
         // 
         this.label58.AutoSize = true;
         this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label58.Location = new System.Drawing.Point(299, 310);
         this.label58.Name = "label58";
         this.label58.Size = new System.Drawing.Size(236, 16);
         this.label58.TabIndex = 180;
         this.label58.Text = "Pumpenleistung im reduzierten Betrieb";
         this.label58.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label57
         // 
         this.label57.AutoSize = true;
         this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label57.Location = new System.Drawing.Point(299, 235);
         this.label57.Name = "label57";
         this.label57.Size = new System.Drawing.Size(235, 16);
         this.label57.TabIndex = 179;
         this.label57.Text = "Pumpenleistung max. bei Normbetrieb";
         this.label57.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TB_ErhoehungszeitKTS
         // 
         this.TB_ErhoehungszeitKTS.Location = new System.Drawing.Point(590, 84);
         this.TB_ErhoehungszeitKTS.Name = "TB_ErhoehungszeitKTS";
         this.TB_ErhoehungszeitKTS.Size = new System.Drawing.Size(25, 20);
         this.TB_ErhoehungszeitKTS.TabIndex = 17;
         this.TB_ErhoehungszeitKTS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TB_ErhoehungszeitKTS.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TB_ErhoehungszeitKTS_Leave);
         // 
         // label56
         // 
         this.label56.AutoSize = true;
         this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label56.Location = new System.Drawing.Point(299, 85);
         this.label56.Name = "label56";
         this.label56.Size = new System.Drawing.Size(216, 16);
         this.label56.TabIndex = 177;
         this.label56.Text = "Erhöhungszeit KT-Soll bei Heizstart";
         this.label56.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TB_ErhoehungKTS
         // 
         this.TB_ErhoehungKTS.Location = new System.Drawing.Point(590, 59);
         this.TB_ErhoehungKTS.Name = "TB_ErhoehungKTS";
         this.TB_ErhoehungKTS.Size = new System.Drawing.Size(25, 20);
         this.TB_ErhoehungKTS.TabIndex = 16;
         this.TB_ErhoehungKTS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TB_ErhoehungKTS.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TB_ErhoehungKTS_Leave);
         // 
         // label55
         // 
         this.label55.AutoSize = true;
         this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label55.Location = new System.Drawing.Point(299, 60);
         this.label55.Name = "label55";
         this.label55.Size = new System.Drawing.Size(189, 16);
         this.label55.TabIndex = 175;
         this.label55.Text = "Erhöhung KT-Soll bei Heizstart";
         this.label55.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TB_PumpebeiWW
         // 
         this.TB_PumpebeiWW.Location = new System.Drawing.Point(590, 335);
         this.TB_PumpebeiWW.Name = "TB_PumpebeiWW";
         this.TB_PumpebeiWW.Size = new System.Drawing.Size(25, 20);
         this.TB_PumpebeiWW.TabIndex = 29;
         this.TB_PumpebeiWW.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TB_PumpebeiWW.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TB_PumpebeiWW_Leave);
         // 
         // label54
         // 
         this.label54.AutoSize = true;
         this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label54.Location = new System.Drawing.Point(299, 335);
         this.label54.Name = "label54";
         this.label54.Size = new System.Drawing.Size(215, 16);
         this.label54.TabIndex = 173;
         this.label54.Text = "Pumpenleistung bei WW Bereitung";
         this.label54.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // CB_Frostschutztemp
         // 
         this.CB_Frostschutztemp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.CB_Frostschutztemp.FormattingEnabled = true;
         this.CB_Frostschutztemp.Location = new System.Drawing.Point(567, 258);
         this.CB_Frostschutztemp.Name = "CB_Frostschutztemp";
         this.CB_Frostschutztemp.RightToLeft = System.Windows.Forms.RightToLeft.No;
         this.CB_Frostschutztemp.Size = new System.Drawing.Size(48, 21);
         this.CB_Frostschutztemp.TabIndex = 24;
         this.CB_Frostschutztemp.KeyUp += new System.Windows.Forms.KeyEventHandler(this.CB_Frostschutztemp_Leave);
         // 
         // label53
         // 
         this.label53.AutoSize = true;
         this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label53.Location = new System.Drawing.Point(299, 260);
         this.label53.Name = "label53";
         this.label53.Size = new System.Drawing.Size(193, 16);
         this.label53.TabIndex = 171;
         this.label53.Text = "Ein-/Ausschaltpunkt HK-Pumpe";
         this.label53.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // CB_WWHysterese
         // 
         this.CB_WWHysterese.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.CB_WWHysterese.FormattingEnabled = true;
         this.CB_WWHysterese.Location = new System.Drawing.Point(567, 109);
         this.CB_WWHysterese.Name = "CB_WWHysterese";
         this.CB_WWHysterese.RightToLeft = System.Windows.Forms.RightToLeft.No;
         this.CB_WWHysterese.Size = new System.Drawing.Size(48, 21);
         this.CB_WWHysterese.TabIndex = 18;
         this.CB_WWHysterese.KeyUp += new System.Windows.Forms.KeyEventHandler(this.CB_WWHysterese_Leave);
         // 
         // label19
         // 
         this.label19.AutoSize = true;
         this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label19.Location = new System.Drawing.Point(299, 110);
         this.label19.Name = "label19";
         this.label19.Size = new System.Drawing.Size(260, 16);
         this.label19.TabIndex = 169;
         this.label19.Text = "WW Bereitung bei Soll-Unterschreitung um";
         this.label19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label48
         // 
         this.label48.AutoSize = true;
         this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label48.Location = new System.Drawing.Point(18, 210);
         this.label48.Name = "label48";
         this.label48.Size = new System.Drawing.Size(113, 16);
         this.label48.TabIndex = 168;
         this.label48.Text = "Warmwasser Soll";
         this.label48.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TextBoxWWS
         // 
         this.TextBoxWWS.Location = new System.Drawing.Point(214, 209);
         this.TextBoxWWS.Name = "TextBoxWWS";
         this.TextBoxWWS.Size = new System.Drawing.Size(25, 20);
         this.TextBoxWWS.TabIndex = 7;
         this.TextBoxWWS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TextBoxWWS.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TextBoxWWS_Leave);
         // 
         // label14
         // 
         this.label14.AutoSize = true;
         this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label14.Location = new System.Drawing.Point(18, 185);
         this.label14.Name = "label14";
         this.label14.Size = new System.Drawing.Size(140, 16);
         this.label14.TabIndex = 144;
         this.label14.Text = "RaumTemp Party Soll";
         this.label14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TextBoxRTS_Party
         // 
         this.TextBoxRTS_Party.Location = new System.Drawing.Point(214, 184);
         this.TextBoxRTS_Party.Name = "TextBoxRTS_Party";
         this.TextBoxRTS_Party.Size = new System.Drawing.Size(25, 20);
         this.TextBoxRTS_Party.TabIndex = 6;
         this.TextBoxRTS_Party.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TextBoxRTS_Party.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TextBoxRTS_Party_Leave);
         // 
         // TextBox3304
         // 
         this.TextBox3304.Location = new System.Drawing.Point(214, 234);
         this.TextBox3304.Name = "TextBox3304";
         this.TextBox3304.Size = new System.Drawing.Size(25, 20);
         this.TextBox3304.TabIndex = 8;
         this.TextBox3304.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TextBox3304.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TextBoxHKLNiveau_Leave);
         // 
         // label22
         // 
         this.label22.AutoSize = true;
         this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label22.Location = new System.Drawing.Point(18, 160);
         this.label22.Name = "label22";
         this.label22.Size = new System.Drawing.Size(144, 16);
         this.label22.TabIndex = 147;
         this.label22.Text = "RaumTemp Nacht Soll";
         this.label22.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TextBox3305
         // 
         this.TextBox3305.Location = new System.Drawing.Point(214, 258);
         this.TextBox3305.Name = "TextBox3305";
         this.TextBox3305.Size = new System.Drawing.Size(25, 20);
         this.TextBox3305.TabIndex = 9;
         this.TextBox3305.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TextBox3305.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TextBoxHKLNeigung_Leave);
         // 
         // TextBoxRTS_Nacht
         // 
         this.TextBoxRTS_Nacht.Location = new System.Drawing.Point(214, 159);
         this.TextBoxRTS_Nacht.Name = "TextBoxRTS_Nacht";
         this.TextBoxRTS_Nacht.Size = new System.Drawing.Size(25, 20);
         this.TextBoxRTS_Nacht.TabIndex = 5;
         this.TextBoxRTS_Nacht.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TextBoxRTS_Nacht.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TextBoxRTS_Nacht_Leave);
         // 
         // La_Betriebsart
         // 
         this.La_Betriebsart.AutoSize = true;
         this.La_Betriebsart.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.La_Betriebsart.Location = new System.Drawing.Point(18, 36);
         this.La_Betriebsart.Name = "La_Betriebsart";
         this.La_Betriebsart.Size = new System.Drawing.Size(71, 16);
         this.La_Betriebsart.TabIndex = 166;
         this.La_Betriebsart.Text = "Betriebsart";
         this.La_Betriebsart.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label21
         // 
         this.label21.AutoSize = true;
         this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label21.Location = new System.Drawing.Point(18, 135);
         this.label21.Name = "label21";
         this.label21.Size = new System.Drawing.Size(134, 16);
         this.label21.TabIndex = 145;
         this.label21.Text = "RaumTemp Tag Soll";
         this.label21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // CB_Betriebsart
         // 
         this.CB_Betriebsart.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.CB_Betriebsart.FormattingEnabled = true;
         this.CB_Betriebsart.Location = new System.Drawing.Point(118, 34);
         this.CB_Betriebsart.Name = "CB_Betriebsart";
         this.CB_Betriebsart.Size = new System.Drawing.Size(121, 21);
         this.CB_Betriebsart.TabIndex = 1;
         this.CB_Betriebsart.KeyUp += new System.Windows.Forms.KeyEventHandler(this.CB_Betriebsart_Leave);
         // 
         // label12
         // 
         this.label12.AutoSize = true;
         this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label12.Location = new System.Drawing.Point(18, 235);
         this.label12.Name = "label12";
         this.label12.Size = new System.Drawing.Size(134, 16);
         this.label12.TabIndex = 139;
         this.label12.Text = "Heizkennlinie Niveau";
         this.label12.TextAlign = System.Drawing.ContentAlignment.BottomRight;
         // 
         // TextBoxRTS_Tag
         // 
         this.TextBoxRTS_Tag.Location = new System.Drawing.Point(214, 134);
         this.TextBoxRTS_Tag.Name = "TextBoxRTS_Tag";
         this.TextBoxRTS_Tag.Size = new System.Drawing.Size(25, 20);
         this.TextBoxRTS_Tag.TabIndex = 4;
         this.TextBoxRTS_Tag.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TextBoxRTS_Tag.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TextBoxRTS_Tag_Leave);
         // 
         // label10
         // 
         this.label10.AutoSize = true;
         this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label10.Location = new System.Drawing.Point(18, 259);
         this.label10.Name = "label10";
         this.label10.Size = new System.Drawing.Size(142, 16);
         this.label10.TabIndex = 138;
         this.label10.Text = "Heizkennlinie Neigung";
         this.label10.TextAlign = System.Drawing.ContentAlignment.BottomRight;
         // 
         // Frostgefahr
         // 
         this.Frostgefahr.AllowDrop = true;
         this.Frostgefahr.BackColor = System.Drawing.Color.LightPink;
         this.Frostgefahr.Location = new System.Drawing.Point(892, 386);
         this.Frostgefahr.Name = "Frostgefahr";
         this.Frostgefahr.Size = new System.Drawing.Size(15, 15);
         this.Frostgefahr.TabIndex = 164;
         // 
         // label47
         // 
         this.label47.AutoSize = true;
         this.label47.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label47.Location = new System.Drawing.Point(682, 386);
         this.label47.Name = "label47";
         this.label47.Size = new System.Drawing.Size(73, 16);
         this.label47.TabIndex = 163;
         this.label47.Text = "Frostgefahr";
         this.label47.TextAlign = System.Drawing.ContentAlignment.BottomRight;
         // 
         // label29
         // 
         this.label29.AllowDrop = true;
         this.label29.BackColor = System.Drawing.Color.LightPink;
         this.label29.Location = new System.Drawing.Point(892, 436);
         this.label29.Name = "label29";
         this.label29.Size = new System.Drawing.Size(15, 15);
         this.label29.TabIndex = 162;
         // 
         // label28
         // 
         this.label28.AutoSize = true;
         this.label28.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label28.Location = new System.Drawing.Point(682, 436);
         this.label28.Name = "label28";
         this.label28.Size = new System.Drawing.Size(96, 16);
         this.label28.TabIndex = 161;
         this.label28.Text = "Brennerstörung";
         this.label28.TextAlign = System.Drawing.ContentAlignment.BottomRight;
         // 
         // label27
         // 
         this.label27.AutoSize = true;
         this.label27.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label27.Location = new System.Drawing.Point(853, 260);
         this.label27.Name = "label27";
         this.label27.Size = new System.Drawing.Size(20, 16);
         this.label27.TabIndex = 160;
         this.label27.Text = "%";
         this.label27.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label26
         // 
         this.label26.AutoSize = true;
         this.label26.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label26.Location = new System.Drawing.Point(682, 260);
         this.label26.Name = "label26";
         this.label26.Size = new System.Drawing.Size(71, 16);
         this.label26.TabIndex = 159;
         this.label26.Text = "Int. Pumpe";
         this.label26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label24
         // 
         this.label24.AutoSize = true;
         this.label24.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label24.Location = new System.Drawing.Point(853, 209);
         this.label24.Name = "label24";
         this.label24.Size = new System.Drawing.Size(20, 16);
         this.label24.TabIndex = 158;
         this.label24.Text = "%";
         this.label24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label13
         // 
         this.label13.AutoSize = true;
         this.label13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label13.Location = new System.Drawing.Point(682, 210);
         this.label13.Name = "label13";
         this.label13.Size = new System.Drawing.Size(116, 16);
         this.label13.TabIndex = 157;
         this.label13.Text = "Brennermodulation";
         this.label13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label9
         // 
         this.label9.AutoSize = true;
         this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label9.Location = new System.Drawing.Point(853, 285);
         this.label9.Name = "label9";
         this.label9.Size = new System.Drawing.Size(22, 16);
         this.label9.TabIndex = 156;
         this.label9.Text = "l/h";
         this.label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         this.label9.Visible = false;
         // 
         // ChB_Sparbetrieb
         // 
         this.ChB_Sparbetrieb.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
         this.ChB_Sparbetrieb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
         this.ChB_Sparbetrieb.Location = new System.Drawing.Point(22, 86);
         this.ChB_Sparbetrieb.Name = "ChB_Sparbetrieb";
         this.ChB_Sparbetrieb.Size = new System.Drawing.Size(112, 21);
         this.ChB_Sparbetrieb.TabIndex = 3;
         this.ChB_Sparbetrieb.Text = "Sparbetrieb";
         this.ChB_Sparbetrieb.UseVisualStyleBackColor = true;
         this.ChB_Sparbetrieb.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ChB_Spar_Leave);
         // 
         // TextBox0812
         // 
         this.TextBox0812.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox0812.Location = new System.Drawing.Point(856, 182);
         this.TextBox0812.Name = "TextBox0812";
         this.TextBox0812.Size = new System.Drawing.Size(50, 22);
         this.TextBox0812.TabIndex = 128;
         this.TextBox0812.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // ChB_Partybetrieb
         // 
         this.ChB_Partybetrieb.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
         this.ChB_Partybetrieb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
         this.ChB_Partybetrieb.Location = new System.Drawing.Point(22, 61);
         this.ChB_Partybetrieb.Name = "ChB_Partybetrieb";
         this.ChB_Partybetrieb.Size = new System.Drawing.Size(112, 21);
         this.ChB_Partybetrieb.TabIndex = 2;
         this.ChB_Partybetrieb.Text = "Partybetrieb";
         this.ChB_Partybetrieb.UseVisualStyleBackColor = true;
         this.ChB_Partybetrieb.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ChB_Party_Leave);
         // 
         // Label0842
         // 
         this.Label0842.AllowDrop = true;
         this.Label0842.BackColor = System.Drawing.Color.LightPink;
         this.Label0842.Location = new System.Drawing.Point(891, 211);
         this.Label0842.Name = "Label0842";
         this.Label0842.Size = new System.Drawing.Size(15, 15);
         this.Label0842.TabIndex = 126;
         // 
         // Label3906
         // 
         this.Label3906.AllowDrop = true;
         this.Label3906.BackColor = System.Drawing.Color.LightPink;
         this.Label3906.Location = new System.Drawing.Point(891, 260);
         this.Label3906.Name = "Label3906";
         this.Label3906.Size = new System.Drawing.Size(15, 15);
         this.Label3906.TabIndex = 125;
         // 
         // Label0883
         // 
         this.Label0883.AllowDrop = true;
         this.Label0883.BackColor = System.Drawing.Color.LightPink;
         this.Label0883.Location = new System.Drawing.Point(892, 411);
         this.Label0883.Name = "Label0883";
         this.Label0883.Size = new System.Drawing.Size(15, 15);
         this.Label0883.TabIndex = 121;
         // 
         // Label0845
         // 
         this.Label0845.AllowDrop = true;
         this.Label0845.BackColor = System.Drawing.Color.LightPink;
         this.Label0845.Location = new System.Drawing.Point(891, 310);
         this.Label0845.Name = "Label0845";
         this.Label0845.Size = new System.Drawing.Size(15, 15);
         this.Label0845.TabIndex = 118;
         // 
         // Label0846
         // 
         this.Label0846.AllowDrop = true;
         this.Label0846.BackColor = System.Drawing.Color.LightPink;
         this.Label0846.Location = new System.Drawing.Point(891, 335);
         this.Label0846.Name = "Label0846";
         this.Label0846.Size = new System.Drawing.Size(15, 15);
         this.Label0846.TabIndex = 117;
         // 
         // TextBox081A
         // 
         this.TextBox081A.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox081A.Location = new System.Drawing.Point(803, 232);
         this.TextBox081A.Name = "TextBox081A";
         this.TextBox081A.Size = new System.Drawing.Size(104, 22);
         this.TextBox081A.TabIndex = 114;
         this.TextBox081A.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // label46
         // 
         this.label46.AutoSize = true;
         this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label46.Location = new System.Drawing.Point(856, 14);
         this.label46.Name = "label46";
         this.label46.Size = new System.Drawing.Size(38, 16);
         this.label46.TabIndex = 108;
         this.label46.Text = "gem.";
         // 
         // TextBox5525
         // 
         this.TextBox5525.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox5525.Location = new System.Drawing.Point(857, 32);
         this.TextBox5525.Name = "TextBox5525";
         this.TextBox5525.Size = new System.Drawing.Size(50, 22);
         this.TextBox5525.TabIndex = 107;
         this.TextBox5525.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // Label11
         // 
         this.Label11.AutoSize = true;
         this.Label11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label11.Location = new System.Drawing.Point(682, 285);
         this.Label11.Name = "Label11";
         this.Label11.Size = new System.Drawing.Size(91, 16);
         this.Label11.TabIndex = 103;
         this.Label11.Text = "Volumenstrom";
         this.Label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         this.Label11.Visible = false;
         // 
         // Label8
         // 
         this.Label8.AutoSize = true;
         this.Label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label8.Location = new System.Drawing.Point(682, 235);
         this.Label8.Name = "Label8";
         this.Label8.Size = new System.Drawing.Size(40, 16);
         this.Label8.TabIndex = 102;
         this.Label8.Text = "Ventil";
         this.Label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // Label0845a
         // 
         this.Label0845a.AutoSize = true;
         this.Label0845a.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label0845a.Location = new System.Drawing.Point(682, 310);
         this.Label0845a.Name = "Label0845a";
         this.Label0845a.Size = new System.Drawing.Size(79, 16);
         this.Label0845a.TabIndex = 92;
         this.Label0845a.Text = "WW-Pumpe";
         this.Label0845a.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // Label0846a
         // 
         this.Label0846a.AutoSize = true;
         this.Label0846a.BackColor = System.Drawing.Color.Transparent;
         this.Label0846a.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label0846a.Location = new System.Drawing.Point(682, 335);
         this.Label0846a.Name = "Label0846a";
         this.Label0846a.Size = new System.Drawing.Size(81, 16);
         this.Label0846a.TabIndex = 91;
         this.Label0846a.Text = "Zirku-Pumpe";
         this.Label0846a.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TextBox088A
         // 
         this.TextBox088A.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox088A.Location = new System.Drawing.Point(150, 408);
         this.TextBox088A.Name = "TextBox088A";
         this.TextBox088A.Size = new System.Drawing.Size(89, 20);
         this.TextBox088A.TabIndex = 13;
         this.TextBox088A.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // Label17
         // 
         this.Label17.AutoSize = true;
         this.Label17.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label17.Location = new System.Drawing.Point(18, 410);
         this.Label17.Name = "Label17";
         this.Label17.Size = new System.Drawing.Size(86, 16);
         this.Label17.TabIndex = 84;
         this.Label17.Text = "Brennerstarts";
         this.Label17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // Label15
         // 
         this.Label15.AutoSize = true;
         this.Label15.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label15.Location = new System.Drawing.Point(18, 436);
         this.Label15.Name = "Label15";
         this.Label15.Size = new System.Drawing.Size(99, 16);
         this.Label15.TabIndex = 82;
         this.Label15.Text = "Brennerstunden";
         this.Label15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TextBox0818
         // 
         this.TextBox0818.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox0818.Location = new System.Drawing.Point(803, 207);
         this.TextBox0818.Name = "TextBox0818";
         this.TextBox0818.Size = new System.Drawing.Size(50, 22);
         this.TextBox0818.TabIndex = 80;
         this.TextBox0818.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // Label0883a
         // 
         this.Label0883a.AutoSize = true;
         this.Label0883a.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label0883a.Location = new System.Drawing.Point(682, 411);
         this.Label0883a.Name = "Label0883a";
         this.Label0883a.Size = new System.Drawing.Size(99, 16);
         this.Label0883a.TabIndex = 76;
         this.Label0883a.Text = "Sammelstörung";
         this.Label0883a.TextAlign = System.Drawing.ContentAlignment.BottomRight;
         // 
         // TextBox0810
         // 
         this.TextBox0810.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox0810.Location = new System.Drawing.Point(857, 107);
         this.TextBox0810.Name = "TextBox0810";
         this.TextBox0810.Size = new System.Drawing.Size(50, 22);
         this.TextBox0810.TabIndex = 73;
         this.TextBox0810.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // label30
         // 
         this.label30.AutoSize = true;
         this.label30.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label30.Location = new System.Drawing.Point(682, 185);
         this.label30.Name = "label30";
         this.label30.Size = new System.Drawing.Size(89, 16);
         this.label30.TabIndex = 72;
         this.label30.Text = "WW-Speicher";
         this.label30.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label38
         // 
         this.label38.AutoSize = true;
         this.label38.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label38.Location = new System.Drawing.Point(682, 35);
         this.label38.Name = "label38";
         this.label38.Size = new System.Drawing.Size(85, 16);
         this.label38.TabIndex = 71;
         this.label38.Text = "Aussentemp.";
         this.label38.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TextBox0808
         // 
         this.TextBox0808.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox0808.Location = new System.Drawing.Point(803, 157);
         this.TextBox0808.Name = "TextBox0808";
         this.TextBox0808.Size = new System.Drawing.Size(50, 22);
         this.TextBox0808.TabIndex = 70;
         this.TextBox0808.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // TextBox080A
         // 
         this.TextBox080A.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox080A.Location = new System.Drawing.Point(803, 282);
         this.TextBox080A.Name = "TextBox080A";
         this.TextBox080A.Size = new System.Drawing.Size(50, 22);
         this.TextBox080A.TabIndex = 69;
         this.TextBox080A.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         this.TextBox080A.Visible = false;
         // 
         // TextBox080C
         // 
         this.TextBox080C.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox080C.Location = new System.Drawing.Point(803, 257);
         this.TextBox080C.Name = "TextBox080C";
         this.TextBox080C.Size = new System.Drawing.Size(50, 22);
         this.TextBox080C.TabIndex = 68;
         this.TextBox080C.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // label39
         // 
         this.label39.AutoSize = true;
         this.label39.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label39.Location = new System.Drawing.Point(682, 160);
         this.label39.Name = "label39";
         this.label39.Size = new System.Drawing.Size(78, 16);
         this.label39.TabIndex = 67;
         this.label39.Text = "Abgastemp.";
         this.label39.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TextBox0804
         // 
         this.TextBox0804.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox0804.Location = new System.Drawing.Point(803, 182);
         this.TextBox0804.Name = "TextBox0804";
         this.TextBox0804.Size = new System.Drawing.Size(50, 22);
         this.TextBox0804.TabIndex = 66;
         this.TextBox0804.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // TextBox0802
         // 
         this.TextBox0802.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox0802.Location = new System.Drawing.Point(803, 107);
         this.TextBox0802.Name = "TextBox0802";
         this.TextBox0802.Size = new System.Drawing.Size(50, 22);
         this.TextBox0802.TabIndex = 65;
         this.TextBox0802.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // TextBox0800
         // 
         this.TextBox0800.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox0800.Location = new System.Drawing.Point(803, 32);
         this.TextBox0800.Name = "TextBox0800";
         this.TextBox0800.Size = new System.Drawing.Size(50, 22);
         this.TextBox0800.TabIndex = 64;
         this.TextBox0800.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // label41
         // 
         this.label41.AutoSize = true;
         this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label41.Location = new System.Drawing.Point(856, 60);
         this.label41.Name = "label41";
         this.label41.Size = new System.Drawing.Size(55, 16);
         this.label41.TabIndex = 63;
         this.label41.Text = "Soll akt.";
         // 
         // label43
         // 
         this.label43.AutoSize = true;
         this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label43.Location = new System.Drawing.Point(802, 14);
         this.label43.Name = "label43";
         this.label43.Size = new System.Drawing.Size(51, 16);
         this.label43.TabIndex = 61;
         this.label43.Text = "Sensor";
         // 
         // label44
         // 
         this.label44.AutoSize = true;
         this.label44.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label44.Location = new System.Drawing.Point(682, 110);
         this.label44.Name = "label44";
         this.label44.Size = new System.Drawing.Size(81, 16);
         this.label44.TabIndex = 60;
         this.label44.Text = "Kesseltemp.";
         this.label44.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TextBox08A7
         // 
         this.TextBox08A7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox08A7.Location = new System.Drawing.Point(150, 435);
         this.TextBox08A7.Name = "TextBox08A7";
         this.TextBox08A7.Size = new System.Drawing.Size(89, 20);
         this.TextBox08A7.TabIndex = 14;
         this.TextBox08A7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
         // 
         // label23
         // 
         this.label23.AutoSize = true;
         this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label23.Location = new System.Drawing.Point(802, 60);
         this.label23.Name = "label23";
         this.label23.Size = new System.Drawing.Size(21, 16);
         this.label23.TabIndex = 145;
         this.label23.Text = "Ist";
         // 
         // tabPage2
         // 
         this.tabPage2.Controls.Add(this.btnNewCsv);
         this.tabPage2.Controls.Add(this.lblHint);
         this.tabPage2.Controls.Add(this.btnClearRowVal);
         this.tabPage2.Controls.Add(this.btnWriteDp);
         this.tabPage2.Controls.Add(this.btnReadDp);
         this.tabPage2.Controls.Add(this.btn_select_kein);
         this.tabPage2.Controls.Add(this.btn_select_alle);
         this.tabPage2.Controls.Add(this.btnClearChart);
         this.tabPage2.Controls.Add(this.gbxComSettings);
         this.tabPage2.Controls.Add(this.mydataGridView1);
         this.tabPage2.Location = new System.Drawing.Point(4, 22);
         this.tabPage2.Name = "tabPage2";
         this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
         this.tabPage2.Size = new System.Drawing.Size(976, 491);
         this.tabPage2.TabIndex = 1;
         this.tabPage2.Text = "Daten";
         this.tabPage2.UseVisualStyleBackColor = true;
         // 
         // btnNewCsv
         // 
         this.btnNewCsv.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.btnNewCsv.Location = new System.Drawing.Point(245, 458);
         this.btnNewCsv.Name = "btnNewCsv";
         this.btnNewCsv.Size = new System.Drawing.Size(296, 23);
         this.btnNewCsv.TabIndex = 220;
         this.btnNewCsv.Text = "Neue csv erstellen entspr. Auswahl \'Sp.\'";
         this.btnNewCsv.UseVisualStyleBackColor = true;
         this.btnNewCsv.Click += new System.EventHandler(this.btnNewCsv_Click);
         // 
         // lblHint
         // 
         this.lblHint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.lblHint.ForeColor = System.Drawing.Color.Red;
         this.lblHint.Location = new System.Drawing.Point(242, 399);
         this.lblHint.Name = "lblHint";
         this.lblHint.Size = new System.Drawing.Size(299, 56);
         this.lblHint.TabIndex = 251;
         this.lblHint.Text = "ACHTUNG! Bei Änderung in der Spalte \'Sp.\' muss eine neue csv Datei erstellt werde" +
    "n, sonst gibt es Chaos.\r\nAusserdem müssen alle in der Grafik dargestellte Datenp" +
    "unkte auch als \'Sp.\' selektiert sein!";
         // 
         // btnClearRowVal
         // 
         this.btnClearRowVal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.btnClearRowVal.Location = new System.Drawing.Point(120, 399);
         this.btnClearRowVal.Name = "btnClearRowVal";
         this.btnClearRowVal.Size = new System.Drawing.Size(90, 23);
         this.btnClearRowVal.TabIndex = 215;
         this.btnClearRowVal.Text = "Clear Value";
         this.btnClearRowVal.UseVisualStyleBackColor = true;
         this.btnClearRowVal.Click += new System.EventHandler(this.btnClearRowVal_Click);
         // 
         // btnWriteDp
         // 
         this.btnWriteDp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.btnWriteDp.ForeColor = System.Drawing.Color.Red;
         this.btnWriteDp.Location = new System.Drawing.Point(120, 458);
         this.btnWriteDp.Name = "btnWriteDp";
         this.btnWriteDp.Size = new System.Drawing.Size(90, 23);
         this.btnWriteDp.TabIndex = 217;
         this.btnWriteDp.Text = "Write DP";
         this.btnWriteDp.UseVisualStyleBackColor = true;
         this.btnWriteDp.Click += new System.EventHandler(this.btnWriteDp_Click);
         // 
         // btnReadDp
         // 
         this.btnReadDp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.btnReadDp.Location = new System.Drawing.Point(120, 428);
         this.btnReadDp.Name = "btnReadDp";
         this.btnReadDp.Size = new System.Drawing.Size(90, 23);
         this.btnReadDp.TabIndex = 216;
         this.btnReadDp.Text = "Read DP";
         this.btnReadDp.UseVisualStyleBackColor = true;
         this.btnReadDp.Click += new System.EventHandler(this.btnReadDp_Click);
         // 
         // btn_select_kein
         // 
         this.btn_select_kein.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.btn_select_kein.Location = new System.Drawing.Point(3, 458);
         this.btn_select_kein.Name = "btn_select_kein";
         this.btn_select_kein.Size = new System.Drawing.Size(90, 23);
         this.btn_select_kein.TabIndex = 212;
         this.btn_select_kein.Text = "keinen \'Akt.\'";
         this.btn_select_kein.UseVisualStyleBackColor = true;
         this.btn_select_kein.Click += new System.EventHandler(this.btn_select_kein_Click);
         // 
         // btn_select_alle
         // 
         this.btn_select_alle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.btn_select_alle.Location = new System.Drawing.Point(3, 428);
         this.btn_select_alle.Name = "btn_select_alle";
         this.btn_select_alle.Size = new System.Drawing.Size(90, 23);
         this.btn_select_alle.TabIndex = 211;
         this.btn_select_alle.Text = "alle \'Akt.\'";
         this.btn_select_alle.UseVisualStyleBackColor = true;
         this.btn_select_alle.Click += new System.EventHandler(this.btn_select_alle_Click);
         // 
         // btnClearChart
         // 
         this.btnClearChart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
         this.btnClearChart.Location = new System.Drawing.Point(3, 399);
         this.btnClearChart.Name = "btnClearChart";
         this.btnClearChart.Size = new System.Drawing.Size(90, 23);
         this.btnClearChart.TabIndex = 210;
         this.btnClearChart.Text = "Clear Values";
         this.btnClearChart.UseVisualStyleBackColor = true;
         this.btnClearChart.Click += new System.EventHandler(this.btnClearChart_Click);
         // 
         // gbxComSettings
         // 
         this.gbxComSettings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
         this.gbxComSettings.BackColor = System.Drawing.Color.LightCyan;
         this.gbxComSettings.Controls.Add(this.label6);
         this.gbxComSettings.Controls.Add(this.CoBx_Handshake);
         this.gbxComSettings.Controls.Add(this.label5);
         this.gbxComSettings.Controls.Add(this.CoBx_Datenbits);
         this.gbxComSettings.Controls.Add(this.label4);
         this.gbxComSettings.Controls.Add(this.CoBx_Stopbits);
         this.gbxComSettings.Controls.Add(this.label3);
         this.gbxComSettings.Controls.Add(this.label2);
         this.gbxComSettings.Controls.Add(this.CoBx_Parity);
         this.gbxComSettings.Controls.Add(this.Label1);
         this.gbxComSettings.Controls.Add(this.CoBx_BaudRate);
         this.gbxComSettings.Controls.Add(this.cbxPort);
         this.gbxComSettings.Location = new System.Drawing.Point(871, 6);
         this.gbxComSettings.Name = "gbxComSettings";
         this.gbxComSettings.Size = new System.Drawing.Size(94, 290);
         this.gbxComSettings.TabIndex = 250;
         this.gbxComSettings.TabStop = false;
         this.gbxComSettings.Text = "ser. Optionen";
         // 
         // label6
         // 
         this.label6.AutoSize = true;
         this.label6.Location = new System.Drawing.Point(6, 220);
         this.label6.Name = "label6";
         this.label6.Size = new System.Drawing.Size(62, 13);
         this.label6.TabIndex = 21;
         this.label6.Text = "Handshake";
         // 
         // CoBx_Handshake
         // 
         this.CoBx_Handshake.Enabled = false;
         this.CoBx_Handshake.FormattingEnabled = true;
         this.CoBx_Handshake.Location = new System.Drawing.Point(9, 233);
         this.CoBx_Handshake.Name = "CoBx_Handshake";
         this.CoBx_Handshake.Size = new System.Drawing.Size(76, 21);
         this.CoBx_Handshake.TabIndex = 20;
         this.CoBx_Handshake.SelectedIndexChanged += new System.EventHandler(this.CoBx_Handshake_SelectedIndexChanged);
         // 
         // label5
         // 
         this.label5.AutoSize = true;
         this.label5.Location = new System.Drawing.Point(6, 180);
         this.label5.Name = "label5";
         this.label5.Size = new System.Drawing.Size(50, 13);
         this.label5.TabIndex = 19;
         this.label5.Text = "Data Bits";
         // 
         // CoBx_Datenbits
         // 
         this.CoBx_Datenbits.Enabled = false;
         this.CoBx_Datenbits.FormattingEnabled = true;
         this.CoBx_Datenbits.Location = new System.Drawing.Point(9, 193);
         this.CoBx_Datenbits.Name = "CoBx_Datenbits";
         this.CoBx_Datenbits.Size = new System.Drawing.Size(76, 21);
         this.CoBx_Datenbits.TabIndex = 14;
         this.CoBx_Datenbits.SelectedIndexChanged += new System.EventHandler(this.CoBx_Datenbits_SelectedIndexChanged);
         // 
         // label4
         // 
         this.label4.AutoSize = true;
         this.label4.Location = new System.Drawing.Point(6, 140);
         this.label4.Name = "label4";
         this.label4.Size = new System.Drawing.Size(49, 13);
         this.label4.TabIndex = 18;
         this.label4.Text = "Stop Bits";
         // 
         // CoBx_Stopbits
         // 
         this.CoBx_Stopbits.Enabled = false;
         this.CoBx_Stopbits.FormattingEnabled = true;
         this.CoBx_Stopbits.Location = new System.Drawing.Point(9, 153);
         this.CoBx_Stopbits.Name = "CoBx_Stopbits";
         this.CoBx_Stopbits.Size = new System.Drawing.Size(76, 21);
         this.CoBx_Stopbits.TabIndex = 13;
         this.CoBx_Stopbits.SelectedIndexChanged += new System.EventHandler(this.CoBx_Stopbits_SelectedIndexChanged);
         // 
         // label3
         // 
         this.label3.AutoSize = true;
         this.label3.Location = new System.Drawing.Point(6, 100);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(33, 13);
         this.label3.TabIndex = 17;
         this.label3.Text = "Parity";
         // 
         // label2
         // 
         this.label2.AutoSize = true;
         this.label2.Location = new System.Drawing.Point(6, 60);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(58, 13);
         this.label2.TabIndex = 16;
         this.label2.Text = "Baud Rate";
         // 
         // CoBx_Parity
         // 
         this.CoBx_Parity.Enabled = false;
         this.CoBx_Parity.FormattingEnabled = true;
         this.CoBx_Parity.Location = new System.Drawing.Point(9, 113);
         this.CoBx_Parity.Name = "CoBx_Parity";
         this.CoBx_Parity.Size = new System.Drawing.Size(76, 21);
         this.CoBx_Parity.TabIndex = 12;
         this.CoBx_Parity.SelectedIndexChanged += new System.EventHandler(this.CoBx_Parity_SelectedIndexChanged);
         // 
         // Label1
         // 
         this.Label1.AutoSize = true;
         this.Label1.Location = new System.Drawing.Point(6, 20);
         this.Label1.Name = "Label1";
         this.Label1.Size = new System.Drawing.Size(26, 13);
         this.Label1.TabIndex = 15;
         this.Label1.Text = "Port";
         // 
         // CoBx_BaudRate
         // 
         this.CoBx_BaudRate.Enabled = false;
         this.CoBx_BaudRate.FormattingEnabled = true;
         this.CoBx_BaudRate.Location = new System.Drawing.Point(9, 73);
         this.CoBx_BaudRate.Name = "CoBx_BaudRate";
         this.CoBx_BaudRate.Size = new System.Drawing.Size(76, 21);
         this.CoBx_BaudRate.TabIndex = 11;
         this.CoBx_BaudRate.SelectedIndexChanged += new System.EventHandler(this.CoBx_BaudRate_SelectedIndexChanged);
         // 
         // cbxPort
         // 
         this.cbxPort.FormattingEnabled = true;
         this.cbxPort.Location = new System.Drawing.Point(9, 33);
         this.cbxPort.Name = "cbxPort";
         this.cbxPort.Size = new System.Drawing.Size(76, 21);
         this.cbxPort.TabIndex = 251;
         this.cbxPort.SelectedIndexChanged += new System.EventHandler(this.CoBx_Ports_SelectedIndexChanged);
         // 
         // mydataGridView1
         // 
         this.mydataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
         this.mydataGridView1.Location = new System.Drawing.Point(0, 6);
         this.mydataGridView1.MultiSelect = false;
         this.mydataGridView1.Name = "mydataGridView1";
         this.mydataGridView1.Size = new System.Drawing.Size(865, 382);
         this.mydataGridView1.TabIndex = 200;
         this.mydataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
         // 
         // tabPage3
         // 
         this.tabPage3.Controls.Add(this.btnSendTimeTable);
         this.tabPage3.Controls.Add(this.radioButton3);
         this.tabPage3.Controls.Add(this.radioButton2);
         this.tabPage3.Controls.Add(this.radioButton1);
         this.tabPage3.Controls.Add(this.GroupBox2206);
         this.tabPage3.Controls.Add(this.GroupBox2204);
         this.tabPage3.Controls.Add(this.GroupBox2202);
         this.tabPage3.Controls.Add(this.TextBox0200);
         this.tabPage3.Controls.Add(this.Label42);
         this.tabPage3.Controls.Add(this.Label40);
         this.tabPage3.Controls.Add(this.Label37);
         this.tabPage3.Controls.Add(this.Label36);
         this.tabPage3.Controls.Add(this.Label35);
         this.tabPage3.Controls.Add(this.Label34);
         this.tabPage3.Controls.Add(this.Label33);
         this.tabPage3.Controls.Add(this.Label32);
         this.tabPage3.Controls.Add(this.Label31);
         this.tabPage3.Controls.Add(this.GroupBox2200);
         this.tabPage3.Location = new System.Drawing.Point(4, 22);
         this.tabPage3.Name = "tabPage3";
         this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
         this.tabPage3.Size = new System.Drawing.Size(976, 491);
         this.tabPage3.TabIndex = 2;
         this.tabPage3.Text = "Zeitprogramme";
         this.tabPage3.UseVisualStyleBackColor = true;
         // 
         // btnSendTimeTable
         // 
         this.btnSendTimeTable.Location = new System.Drawing.Point(658, 285);
         this.btnSendTimeTable.Name = "btnSendTimeTable";
         this.btnSendTimeTable.Size = new System.Drawing.Size(105, 23);
         this.btnSendTimeTable.TabIndex = 51;
         this.btnSendTimeTable.Text = "Sende Tabelle";
         this.btnSendTimeTable.UseVisualStyleBackColor = true;
         this.btnSendTimeTable.Click += new System.EventHandler(this.Schreibe_Zeiten);
         // 
         // radioButton3
         // 
         this.radioButton3.AutoSize = true;
         this.radioButton3.Location = new System.Drawing.Point(15, 87);
         this.radioButton3.Name = "radioButton3";
         this.radioButton3.Size = new System.Drawing.Size(86, 17);
         this.radioButton3.TabIndex = 50;
         this.radioButton3.TabStop = true;
         this.radioButton3.Text = "Warmwasser";
         this.radioButton3.UseVisualStyleBackColor = true;
         this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
         // 
         // radioButton2
         // 
         this.radioButton2.AutoSize = true;
         this.radioButton2.Location = new System.Drawing.Point(15, 56);
         this.radioButton2.Name = "radioButton2";
         this.radioButton2.Size = new System.Drawing.Size(64, 17);
         this.radioButton2.TabIndex = 49;
         this.radioButton2.TabStop = true;
         this.radioButton2.Text = "Heizung";
         this.radioButton2.UseVisualStyleBackColor = true;
         this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
         // 
         // radioButton1
         // 
         this.radioButton1.AutoSize = true;
         this.radioButton1.Location = new System.Drawing.Point(15, 118);
         this.radioButton1.Name = "radioButton1";
         this.radioButton1.Size = new System.Drawing.Size(111, 17);
         this.radioButton1.TabIndex = 48;
         this.radioButton1.TabStop = true;
         this.radioButton1.Text = "Zirkulationspumpe";
         this.radioButton1.UseVisualStyleBackColor = true;
         this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
         // 
         // GroupBox2206
         // 
         this.GroupBox2206.Controls.Add(this.TextBox154);
         this.GroupBox2206.Controls.Add(this.TextBox146);
         this.GroupBox2206.Controls.Add(this.TextBox138);
         this.GroupBox2206.Controls.Add(this.TextBox130);
         this.GroupBox2206.Controls.Add(this.TextBox155);
         this.GroupBox2206.Controls.Add(this.TextBox147);
         this.GroupBox2206.Controls.Add(this.TextBox139);
         this.GroupBox2206.Controls.Add(this.TextBox131);
         this.GroupBox2206.Controls.Add(this.TextBox123);
         this.GroupBox2206.Controls.Add(this.TextBox122);
         this.GroupBox2206.Controls.Add(this.TextBox115);
         this.GroupBox2206.Controls.Add(this.TextBox114);
         this.GroupBox2206.Controls.Add(this.TextBox107);
         this.GroupBox2206.Controls.Add(this.label51);
         this.GroupBox2206.Controls.Add(this.label52);
         this.GroupBox2206.Controls.Add(this.TextBox106);
         this.GroupBox2206.Location = new System.Drawing.Point(652, 15);
         this.GroupBox2206.Name = "GroupBox2206";
         this.GroupBox2206.Size = new System.Drawing.Size(117, 247);
         this.GroupBox2206.TabIndex = 4;
         this.GroupBox2206.TabStop = false;
         this.GroupBox2206.Text = "A1M1 ZP Zeit 4";
         // 
         // TextBox154
         // 
         this.TextBox154.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox154.Location = new System.Drawing.Point(6, 219);
         this.TextBox154.Name = "TextBox154";
         this.TextBox154.Size = new System.Drawing.Size(46, 25);
         this.TextBox154.TabIndex = 16;
         this.TextBox154.Text = "00:00";
         this.TextBox154.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox146
         // 
         this.TextBox146.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox146.Location = new System.Drawing.Point(6, 188);
         this.TextBox146.Name = "TextBox146";
         this.TextBox146.Size = new System.Drawing.Size(46, 25);
         this.TextBox146.TabIndex = 15;
         this.TextBox146.Text = "00:00";
         this.TextBox146.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox138
         // 
         this.TextBox138.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox138.Location = new System.Drawing.Point(6, 157);
         this.TextBox138.Name = "TextBox138";
         this.TextBox138.Size = new System.Drawing.Size(46, 25);
         this.TextBox138.TabIndex = 14;
         this.TextBox138.Text = "00:00";
         this.TextBox138.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox130
         // 
         this.TextBox130.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox130.Location = new System.Drawing.Point(6, 126);
         this.TextBox130.Name = "TextBox130";
         this.TextBox130.Size = new System.Drawing.Size(46, 25);
         this.TextBox130.TabIndex = 13;
         this.TextBox130.Text = "00:00";
         this.TextBox130.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox155
         // 
         this.TextBox155.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox155.Location = new System.Drawing.Point(65, 219);
         this.TextBox155.Name = "TextBox155";
         this.TextBox155.Size = new System.Drawing.Size(46, 25);
         this.TextBox155.TabIndex = 26;
         this.TextBox155.Text = "23:59";
         this.TextBox155.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox147
         // 
         this.TextBox147.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox147.Location = new System.Drawing.Point(65, 188);
         this.TextBox147.Name = "TextBox147";
         this.TextBox147.Size = new System.Drawing.Size(46, 25);
         this.TextBox147.TabIndex = 25;
         this.TextBox147.Text = "23:59";
         this.TextBox147.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox139
         // 
         this.TextBox139.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox139.Location = new System.Drawing.Point(65, 157);
         this.TextBox139.Name = "TextBox139";
         this.TextBox139.Size = new System.Drawing.Size(46, 25);
         this.TextBox139.TabIndex = 24;
         this.TextBox139.Text = "23:59";
         this.TextBox139.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox131
         // 
         this.TextBox131.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox131.Location = new System.Drawing.Point(65, 126);
         this.TextBox131.Name = "TextBox131";
         this.TextBox131.Size = new System.Drawing.Size(46, 25);
         this.TextBox131.TabIndex = 23;
         this.TextBox131.Text = "23:59";
         this.TextBox131.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox123
         // 
         this.TextBox123.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox123.Location = new System.Drawing.Point(65, 95);
         this.TextBox123.Name = "TextBox123";
         this.TextBox123.Size = new System.Drawing.Size(46, 25);
         this.TextBox123.TabIndex = 22;
         this.TextBox123.Text = "23:59";
         this.TextBox123.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox122
         // 
         this.TextBox122.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox122.Location = new System.Drawing.Point(6, 95);
         this.TextBox122.Name = "TextBox122";
         this.TextBox122.Size = new System.Drawing.Size(46, 25);
         this.TextBox122.TabIndex = 12;
         this.TextBox122.Text = "00:00";
         this.TextBox122.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox115
         // 
         this.TextBox115.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox115.Location = new System.Drawing.Point(65, 64);
         this.TextBox115.Name = "TextBox115";
         this.TextBox115.Size = new System.Drawing.Size(46, 25);
         this.TextBox115.TabIndex = 21;
         this.TextBox115.Text = "23:59";
         this.TextBox115.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox114
         // 
         this.TextBox114.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox114.Location = new System.Drawing.Point(6, 64);
         this.TextBox114.Name = "TextBox114";
         this.TextBox114.Size = new System.Drawing.Size(46, 25);
         this.TextBox114.TabIndex = 11;
         this.TextBox114.Text = "00:00";
         this.TextBox114.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox107
         // 
         this.TextBox107.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox107.Location = new System.Drawing.Point(65, 33);
         this.TextBox107.Name = "TextBox107";
         this.TextBox107.Size = new System.Drawing.Size(46, 25);
         this.TextBox107.TabIndex = 20;
         this.TextBox107.Text = "23:59";
         this.TextBox107.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // label51
         // 
         this.label51.AutoSize = true;
         this.label51.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label51.Location = new System.Drawing.Point(6, 16);
         this.label51.Name = "label51";
         this.label51.Size = new System.Drawing.Size(41, 17);
         this.label51.TabIndex = 13;
         this.label51.Text = "Ein 4";
         this.label51.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label52
         // 
         this.label52.AutoSize = true;
         this.label52.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label52.Location = new System.Drawing.Point(65, 16);
         this.label52.Name = "label52";
         this.label52.Size = new System.Drawing.Size(45, 17);
         this.label52.TabIndex = 12;
         this.label52.Text = "Aus 4";
         this.label52.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TextBox106
         // 
         this.TextBox106.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox106.Location = new System.Drawing.Point(6, 33);
         this.TextBox106.Name = "TextBox106";
         this.TextBox106.Size = new System.Drawing.Size(46, 25);
         this.TextBox106.TabIndex = 10;
         this.TextBox106.Text = "00:00";
         this.TextBox106.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // GroupBox2204
         // 
         this.GroupBox2204.Controls.Add(this.TextBox152);
         this.GroupBox2204.Controls.Add(this.TextBox144);
         this.GroupBox2204.Controls.Add(this.TextBox136);
         this.GroupBox2204.Controls.Add(this.TextBox128);
         this.GroupBox2204.Controls.Add(this.TextBox153);
         this.GroupBox2204.Controls.Add(this.TextBox145);
         this.GroupBox2204.Controls.Add(this.TextBox137);
         this.GroupBox2204.Controls.Add(this.TextBox129);
         this.GroupBox2204.Controls.Add(this.TextBox121);
         this.GroupBox2204.Controls.Add(this.TextBox120);
         this.GroupBox2204.Controls.Add(this.TextBox113);
         this.GroupBox2204.Controls.Add(this.TextBox112);
         this.GroupBox2204.Controls.Add(this.TextBox105);
         this.GroupBox2204.Controls.Add(this.label49);
         this.GroupBox2204.Controls.Add(this.label50);
         this.GroupBox2204.Controls.Add(this.TextBox104);
         this.GroupBox2204.Location = new System.Drawing.Point(518, 15);
         this.GroupBox2204.Name = "GroupBox2204";
         this.GroupBox2204.Size = new System.Drawing.Size(117, 247);
         this.GroupBox2204.TabIndex = 3;
         this.GroupBox2204.TabStop = false;
         this.GroupBox2204.Text = "A1M1 ZP Zeit 3";
         // 
         // TextBox152
         // 
         this.TextBox152.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox152.Location = new System.Drawing.Point(6, 219);
         this.TextBox152.Name = "TextBox152";
         this.TextBox152.Size = new System.Drawing.Size(46, 25);
         this.TextBox152.TabIndex = 16;
         this.TextBox152.Text = "00:00";
         this.TextBox152.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox144
         // 
         this.TextBox144.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox144.Location = new System.Drawing.Point(6, 188);
         this.TextBox144.Name = "TextBox144";
         this.TextBox144.Size = new System.Drawing.Size(46, 25);
         this.TextBox144.TabIndex = 15;
         this.TextBox144.Text = "00:00";
         this.TextBox144.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox136
         // 
         this.TextBox136.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox136.Location = new System.Drawing.Point(6, 157);
         this.TextBox136.Name = "TextBox136";
         this.TextBox136.Size = new System.Drawing.Size(46, 25);
         this.TextBox136.TabIndex = 14;
         this.TextBox136.Text = "00:00";
         this.TextBox136.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox128
         // 
         this.TextBox128.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox128.Location = new System.Drawing.Point(6, 126);
         this.TextBox128.Name = "TextBox128";
         this.TextBox128.Size = new System.Drawing.Size(46, 25);
         this.TextBox128.TabIndex = 13;
         this.TextBox128.Text = "00:00";
         this.TextBox128.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox153
         // 
         this.TextBox153.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox153.Location = new System.Drawing.Point(65, 219);
         this.TextBox153.Name = "TextBox153";
         this.TextBox153.Size = new System.Drawing.Size(46, 25);
         this.TextBox153.TabIndex = 26;
         this.TextBox153.Text = "23:59";
         this.TextBox153.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox145
         // 
         this.TextBox145.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox145.Location = new System.Drawing.Point(65, 188);
         this.TextBox145.Name = "TextBox145";
         this.TextBox145.Size = new System.Drawing.Size(46, 25);
         this.TextBox145.TabIndex = 25;
         this.TextBox145.Text = "23:59";
         this.TextBox145.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox137
         // 
         this.TextBox137.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox137.Location = new System.Drawing.Point(65, 157);
         this.TextBox137.Name = "TextBox137";
         this.TextBox137.Size = new System.Drawing.Size(46, 25);
         this.TextBox137.TabIndex = 24;
         this.TextBox137.Text = "23:59";
         this.TextBox137.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox129
         // 
         this.TextBox129.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox129.Location = new System.Drawing.Point(65, 126);
         this.TextBox129.Name = "TextBox129";
         this.TextBox129.Size = new System.Drawing.Size(46, 25);
         this.TextBox129.TabIndex = 23;
         this.TextBox129.Text = "23:59";
         this.TextBox129.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox121
         // 
         this.TextBox121.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox121.Location = new System.Drawing.Point(65, 95);
         this.TextBox121.Name = "TextBox121";
         this.TextBox121.Size = new System.Drawing.Size(46, 25);
         this.TextBox121.TabIndex = 22;
         this.TextBox121.Text = "23:59";
         this.TextBox121.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox120
         // 
         this.TextBox120.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox120.Location = new System.Drawing.Point(6, 95);
         this.TextBox120.Name = "TextBox120";
         this.TextBox120.Size = new System.Drawing.Size(46, 25);
         this.TextBox120.TabIndex = 12;
         this.TextBox120.Text = "00:00";
         this.TextBox120.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox113
         // 
         this.TextBox113.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox113.Location = new System.Drawing.Point(65, 64);
         this.TextBox113.Name = "TextBox113";
         this.TextBox113.Size = new System.Drawing.Size(46, 25);
         this.TextBox113.TabIndex = 21;
         this.TextBox113.Text = "23:59";
         this.TextBox113.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox112
         // 
         this.TextBox112.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox112.Location = new System.Drawing.Point(6, 64);
         this.TextBox112.Name = "TextBox112";
         this.TextBox112.Size = new System.Drawing.Size(46, 25);
         this.TextBox112.TabIndex = 11;
         this.TextBox112.Text = "00:00";
         this.TextBox112.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox105
         // 
         this.TextBox105.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox105.Location = new System.Drawing.Point(65, 33);
         this.TextBox105.Name = "TextBox105";
         this.TextBox105.Size = new System.Drawing.Size(46, 25);
         this.TextBox105.TabIndex = 20;
         this.TextBox105.Text = "23:59";
         this.TextBox105.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // label49
         // 
         this.label49.AutoSize = true;
         this.label49.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label49.Location = new System.Drawing.Point(6, 16);
         this.label49.Name = "label49";
         this.label49.Size = new System.Drawing.Size(41, 17);
         this.label49.TabIndex = 13;
         this.label49.Text = "Ein 3";
         this.label49.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label50
         // 
         this.label50.AutoSize = true;
         this.label50.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label50.Location = new System.Drawing.Point(65, 16);
         this.label50.Name = "label50";
         this.label50.Size = new System.Drawing.Size(45, 17);
         this.label50.TabIndex = 12;
         this.label50.Text = "Aus 3";
         this.label50.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TextBox104
         // 
         this.TextBox104.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox104.Location = new System.Drawing.Point(6, 33);
         this.TextBox104.Name = "TextBox104";
         this.TextBox104.Size = new System.Drawing.Size(46, 25);
         this.TextBox104.TabIndex = 10;
         this.TextBox104.Text = "00:00";
         this.TextBox104.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // GroupBox2202
         // 
         this.GroupBox2202.Controls.Add(this.TextBox150);
         this.GroupBox2202.Controls.Add(this.TextBox142);
         this.GroupBox2202.Controls.Add(this.TextBox134);
         this.GroupBox2202.Controls.Add(this.TextBox126);
         this.GroupBox2202.Controls.Add(this.TextBox151);
         this.GroupBox2202.Controls.Add(this.TextBox143);
         this.GroupBox2202.Controls.Add(this.TextBox135);
         this.GroupBox2202.Controls.Add(this.TextBox127);
         this.GroupBox2202.Controls.Add(this.TextBox119);
         this.GroupBox2202.Controls.Add(this.TextBox118);
         this.GroupBox2202.Controls.Add(this.TextBox111);
         this.GroupBox2202.Controls.Add(this.TextBox110);
         this.GroupBox2202.Controls.Add(this.TextBox103);
         this.GroupBox2202.Controls.Add(this.label16);
         this.GroupBox2202.Controls.Add(this.label18);
         this.GroupBox2202.Controls.Add(this.TextBox102);
         this.GroupBox2202.Location = new System.Drawing.Point(384, 15);
         this.GroupBox2202.Name = "GroupBox2202";
         this.GroupBox2202.Size = new System.Drawing.Size(117, 247);
         this.GroupBox2202.TabIndex = 2;
         this.GroupBox2202.TabStop = false;
         this.GroupBox2202.Text = "A1M1 ZP Zeit 2";
         // 
         // TextBox150
         // 
         this.TextBox150.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox150.Location = new System.Drawing.Point(6, 219);
         this.TextBox150.Name = "TextBox150";
         this.TextBox150.Size = new System.Drawing.Size(46, 25);
         this.TextBox150.TabIndex = 16;
         this.TextBox150.Text = "00:00";
         this.TextBox150.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox142
         // 
         this.TextBox142.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox142.Location = new System.Drawing.Point(6, 188);
         this.TextBox142.Name = "TextBox142";
         this.TextBox142.Size = new System.Drawing.Size(46, 25);
         this.TextBox142.TabIndex = 15;
         this.TextBox142.Text = "00:00";
         this.TextBox142.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox134
         // 
         this.TextBox134.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox134.Location = new System.Drawing.Point(6, 157);
         this.TextBox134.Name = "TextBox134";
         this.TextBox134.Size = new System.Drawing.Size(46, 25);
         this.TextBox134.TabIndex = 14;
         this.TextBox134.Text = "00:00";
         this.TextBox134.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox126
         // 
         this.TextBox126.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox126.Location = new System.Drawing.Point(6, 126);
         this.TextBox126.Name = "TextBox126";
         this.TextBox126.Size = new System.Drawing.Size(46, 25);
         this.TextBox126.TabIndex = 13;
         this.TextBox126.Text = "00:00";
         this.TextBox126.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox151
         // 
         this.TextBox151.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox151.Location = new System.Drawing.Point(65, 219);
         this.TextBox151.Name = "TextBox151";
         this.TextBox151.Size = new System.Drawing.Size(46, 25);
         this.TextBox151.TabIndex = 26;
         this.TextBox151.Text = "23:59";
         this.TextBox151.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox143
         // 
         this.TextBox143.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox143.Location = new System.Drawing.Point(65, 188);
         this.TextBox143.Name = "TextBox143";
         this.TextBox143.Size = new System.Drawing.Size(46, 25);
         this.TextBox143.TabIndex = 25;
         this.TextBox143.Text = "23:59";
         this.TextBox143.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox135
         // 
         this.TextBox135.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox135.Location = new System.Drawing.Point(65, 157);
         this.TextBox135.Name = "TextBox135";
         this.TextBox135.Size = new System.Drawing.Size(46, 25);
         this.TextBox135.TabIndex = 24;
         this.TextBox135.Text = "23:59";
         this.TextBox135.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox127
         // 
         this.TextBox127.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox127.Location = new System.Drawing.Point(65, 126);
         this.TextBox127.Name = "TextBox127";
         this.TextBox127.Size = new System.Drawing.Size(46, 25);
         this.TextBox127.TabIndex = 23;
         this.TextBox127.Text = "23:59";
         this.TextBox127.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox119
         // 
         this.TextBox119.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox119.Location = new System.Drawing.Point(65, 95);
         this.TextBox119.Name = "TextBox119";
         this.TextBox119.Size = new System.Drawing.Size(46, 25);
         this.TextBox119.TabIndex = 22;
         this.TextBox119.Text = "23:59";
         this.TextBox119.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox118
         // 
         this.TextBox118.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox118.Location = new System.Drawing.Point(6, 95);
         this.TextBox118.Name = "TextBox118";
         this.TextBox118.Size = new System.Drawing.Size(46, 25);
         this.TextBox118.TabIndex = 12;
         this.TextBox118.Text = "00:00";
         this.TextBox118.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox111
         // 
         this.TextBox111.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox111.Location = new System.Drawing.Point(65, 64);
         this.TextBox111.Name = "TextBox111";
         this.TextBox111.Size = new System.Drawing.Size(46, 25);
         this.TextBox111.TabIndex = 21;
         this.TextBox111.Text = "23:59";
         this.TextBox111.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox110
         // 
         this.TextBox110.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox110.Location = new System.Drawing.Point(6, 64);
         this.TextBox110.Name = "TextBox110";
         this.TextBox110.Size = new System.Drawing.Size(46, 25);
         this.TextBox110.TabIndex = 11;
         this.TextBox110.Text = "00:00";
         this.TextBox110.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox103
         // 
         this.TextBox103.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox103.Location = new System.Drawing.Point(65, 33);
         this.TextBox103.Name = "TextBox103";
         this.TextBox103.Size = new System.Drawing.Size(46, 25);
         this.TextBox103.TabIndex = 20;
         this.TextBox103.Text = "23:59";
         this.TextBox103.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // label16
         // 
         this.label16.AutoSize = true;
         this.label16.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label16.Location = new System.Drawing.Point(6, 16);
         this.label16.Name = "label16";
         this.label16.Size = new System.Drawing.Size(41, 17);
         this.label16.TabIndex = 13;
         this.label16.Text = "Ein 2";
         this.label16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // label18
         // 
         this.label18.AutoSize = true;
         this.label18.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.label18.Location = new System.Drawing.Point(65, 16);
         this.label18.Name = "label18";
         this.label18.Size = new System.Drawing.Size(45, 17);
         this.label18.TabIndex = 12;
         this.label18.Text = "Aus 2";
         this.label18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TextBox102
         // 
         this.TextBox102.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox102.Location = new System.Drawing.Point(6, 33);
         this.TextBox102.Name = "TextBox102";
         this.TextBox102.Size = new System.Drawing.Size(46, 25);
         this.TextBox102.TabIndex = 10;
         this.TextBox102.Text = "00:00";
         this.TextBox102.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox0200
         // 
         this.TextBox0200.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox0200.Location = new System.Drawing.Point(252, 288);
         this.TextBox0200.Name = "TextBox0200";
         this.TextBox0200.Size = new System.Drawing.Size(179, 25);
         this.TextBox0200.TabIndex = 45;
         this.TextBox0200.Text = "00:00";
         this.TextBox0200.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // Label42
         // 
         this.Label42.AutoSize = true;
         this.Label42.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label42.Location = new System.Drawing.Point(156, 291);
         this.Label42.Name = "Label42";
         this.Label42.Size = new System.Drawing.Size(87, 17);
         this.Label42.TabIndex = 44;
         this.Label42.Text = "Datum / Zeit";
         this.Label42.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // Label40
         // 
         this.Label40.AutoSize = true;
         this.Label40.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label40.Location = new System.Drawing.Point(6, 15);
         this.Label40.Name = "Label40";
         this.Label40.Size = new System.Drawing.Size(99, 17);
         this.Label40.TabIndex = 38;
         this.Label40.Text = "Zeitprogramm";
         this.Label40.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // Label37
         // 
         this.Label37.AutoSize = true;
         this.Label37.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label37.Location = new System.Drawing.Point(156, 237);
         this.Label37.Name = "Label37";
         this.Label37.Size = new System.Drawing.Size(62, 17);
         this.Label37.TabIndex = 37;
         this.Label37.Text = "Sonntag";
         this.Label37.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // Label36
         // 
         this.Label36.AutoSize = true;
         this.Label36.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label36.Location = new System.Drawing.Point(156, 206);
         this.Label36.Name = "Label36";
         this.Label36.Size = new System.Drawing.Size(67, 17);
         this.Label36.TabIndex = 36;
         this.Label36.Text = "Samstag";
         this.Label36.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // Label35
         // 
         this.Label35.AutoSize = true;
         this.Label35.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label35.Location = new System.Drawing.Point(156, 175);
         this.Label35.Name = "Label35";
         this.Label35.Size = new System.Drawing.Size(53, 17);
         this.Label35.TabIndex = 35;
         this.Label35.Text = "Freitag";
         this.Label35.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // Label34
         // 
         this.Label34.AutoSize = true;
         this.Label34.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label34.Location = new System.Drawing.Point(156, 144);
         this.Label34.Name = "Label34";
         this.Label34.Size = new System.Drawing.Size(84, 17);
         this.Label34.TabIndex = 34;
         this.Label34.Text = "Donnerstag";
         this.Label34.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // Label33
         // 
         this.Label33.AutoSize = true;
         this.Label33.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label33.Location = new System.Drawing.Point(156, 113);
         this.Label33.Name = "Label33";
         this.Label33.Size = new System.Drawing.Size(65, 17);
         this.Label33.TabIndex = 33;
         this.Label33.Text = "Mittwoch";
         this.Label33.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // Label32
         // 
         this.Label32.AutoSize = true;
         this.Label32.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label32.Location = new System.Drawing.Point(156, 82);
         this.Label32.Name = "Label32";
         this.Label32.Size = new System.Drawing.Size(66, 17);
         this.Label32.TabIndex = 32;
         this.Label32.Text = "Dienstag";
         this.Label32.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // Label31
         // 
         this.Label31.AutoSize = true;
         this.Label31.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label31.Location = new System.Drawing.Point(156, 51);
         this.Label31.Name = "Label31";
         this.Label31.Size = new System.Drawing.Size(55, 17);
         this.Label31.TabIndex = 31;
         this.Label31.Text = "Montag";
         this.Label31.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // GroupBox2200
         // 
         this.GroupBox2200.Controls.Add(this.TextBox148);
         this.GroupBox2200.Controls.Add(this.TextBox140);
         this.GroupBox2200.Controls.Add(this.TextBox132);
         this.GroupBox2200.Controls.Add(this.TextBox124);
         this.GroupBox2200.Controls.Add(this.TextBox149);
         this.GroupBox2200.Controls.Add(this.TextBox141);
         this.GroupBox2200.Controls.Add(this.TextBox133);
         this.GroupBox2200.Controls.Add(this.TextBox125);
         this.GroupBox2200.Controls.Add(this.TextBox117);
         this.GroupBox2200.Controls.Add(this.TextBox116);
         this.GroupBox2200.Controls.Add(this.TextBox109);
         this.GroupBox2200.Controls.Add(this.TextBox108);
         this.GroupBox2200.Controls.Add(this.TextBox101);
         this.GroupBox2200.Controls.Add(this.Label74);
         this.GroupBox2200.Controls.Add(this.Label75);
         this.GroupBox2200.Controls.Add(this.TextBox100);
         this.GroupBox2200.Location = new System.Drawing.Point(246, 15);
         this.GroupBox2200.Name = "GroupBox2200";
         this.GroupBox2200.Size = new System.Drawing.Size(117, 247);
         this.GroupBox2200.TabIndex = 1;
         this.GroupBox2200.TabStop = false;
         this.GroupBox2200.Text = "A1M1 Zeit 1";
         // 
         // TextBox148
         // 
         this.TextBox148.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox148.Location = new System.Drawing.Point(6, 219);
         this.TextBox148.Name = "TextBox148";
         this.TextBox148.Size = new System.Drawing.Size(46, 25);
         this.TextBox148.TabIndex = 16;
         this.TextBox148.Text = "00:00";
         this.TextBox148.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox140
         // 
         this.TextBox140.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox140.Location = new System.Drawing.Point(6, 188);
         this.TextBox140.Name = "TextBox140";
         this.TextBox140.Size = new System.Drawing.Size(46, 25);
         this.TextBox140.TabIndex = 15;
         this.TextBox140.Text = "00:00";
         this.TextBox140.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox132
         // 
         this.TextBox132.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox132.Location = new System.Drawing.Point(6, 157);
         this.TextBox132.Name = "TextBox132";
         this.TextBox132.Size = new System.Drawing.Size(46, 25);
         this.TextBox132.TabIndex = 14;
         this.TextBox132.Text = "00:00";
         this.TextBox132.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox124
         // 
         this.TextBox124.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox124.Location = new System.Drawing.Point(6, 126);
         this.TextBox124.Name = "TextBox124";
         this.TextBox124.Size = new System.Drawing.Size(46, 25);
         this.TextBox124.TabIndex = 13;
         this.TextBox124.Text = "00:00";
         this.TextBox124.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox149
         // 
         this.TextBox149.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox149.Location = new System.Drawing.Point(65, 219);
         this.TextBox149.Name = "TextBox149";
         this.TextBox149.Size = new System.Drawing.Size(46, 25);
         this.TextBox149.TabIndex = 26;
         this.TextBox149.Text = "23:59";
         this.TextBox149.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox141
         // 
         this.TextBox141.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox141.Location = new System.Drawing.Point(65, 188);
         this.TextBox141.Name = "TextBox141";
         this.TextBox141.Size = new System.Drawing.Size(46, 25);
         this.TextBox141.TabIndex = 25;
         this.TextBox141.Text = "23:59";
         this.TextBox141.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox133
         // 
         this.TextBox133.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox133.Location = new System.Drawing.Point(65, 157);
         this.TextBox133.Name = "TextBox133";
         this.TextBox133.Size = new System.Drawing.Size(46, 25);
         this.TextBox133.TabIndex = 24;
         this.TextBox133.Text = "23:59";
         this.TextBox133.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox125
         // 
         this.TextBox125.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox125.Location = new System.Drawing.Point(65, 126);
         this.TextBox125.Name = "TextBox125";
         this.TextBox125.Size = new System.Drawing.Size(46, 25);
         this.TextBox125.TabIndex = 23;
         this.TextBox125.Text = "23:59";
         this.TextBox125.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox117
         // 
         this.TextBox117.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox117.Location = new System.Drawing.Point(65, 95);
         this.TextBox117.Name = "TextBox117";
         this.TextBox117.Size = new System.Drawing.Size(46, 25);
         this.TextBox117.TabIndex = 22;
         this.TextBox117.Text = "23:59";
         this.TextBox117.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox116
         // 
         this.TextBox116.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox116.Location = new System.Drawing.Point(6, 95);
         this.TextBox116.Name = "TextBox116";
         this.TextBox116.Size = new System.Drawing.Size(46, 25);
         this.TextBox116.TabIndex = 12;
         this.TextBox116.Text = "00:00";
         this.TextBox116.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox109
         // 
         this.TextBox109.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox109.Location = new System.Drawing.Point(65, 64);
         this.TextBox109.Name = "TextBox109";
         this.TextBox109.Size = new System.Drawing.Size(46, 25);
         this.TextBox109.TabIndex = 21;
         this.TextBox109.Text = "23:59";
         this.TextBox109.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox108
         // 
         this.TextBox108.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox108.Location = new System.Drawing.Point(6, 64);
         this.TextBox108.Name = "TextBox108";
         this.TextBox108.Size = new System.Drawing.Size(46, 25);
         this.TextBox108.TabIndex = 11;
         this.TextBox108.Text = "00:00";
         this.TextBox108.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // TextBox101
         // 
         this.TextBox101.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox101.Location = new System.Drawing.Point(65, 33);
         this.TextBox101.Name = "TextBox101";
         this.TextBox101.Size = new System.Drawing.Size(46, 25);
         this.TextBox101.TabIndex = 20;
         this.TextBox101.Text = "23:59";
         this.TextBox101.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // Label74
         // 
         this.Label74.AutoSize = true;
         this.Label74.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label74.Location = new System.Drawing.Point(6, 16);
         this.Label74.Name = "Label74";
         this.Label74.Size = new System.Drawing.Size(41, 17);
         this.Label74.TabIndex = 13;
         this.Label74.Text = "Ein 1";
         this.Label74.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // Label75
         // 
         this.Label75.AutoSize = true;
         this.Label75.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.Label75.Location = new System.Drawing.Point(65, 16);
         this.Label75.Name = "Label75";
         this.Label75.Size = new System.Drawing.Size(45, 17);
         this.Label75.TabIndex = 12;
         this.Label75.Text = "Aus 1";
         this.Label75.TextAlign = System.Drawing.ContentAlignment.TopCenter;
         // 
         // TextBox100
         // 
         this.TextBox100.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.TextBox100.Location = new System.Drawing.Point(6, 33);
         this.TextBox100.Name = "TextBox100";
         this.TextBox100.Size = new System.Drawing.Size(46, 25);
         this.TextBox100.TabIndex = 10;
         this.TextBox100.Text = "00:00";
         this.TextBox100.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
         // 
         // tabPage4
         // 
         this.tabPage4.Controls.Add(this.plotterDisplayEx1);
         this.tabPage4.Location = new System.Drawing.Point(4, 22);
         this.tabPage4.Name = "tabPage4";
         this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
         this.tabPage4.Size = new System.Drawing.Size(976, 491);
         this.tabPage4.TabIndex = 3;
         this.tabPage4.Text = "Graph";
         this.tabPage4.UseVisualStyleBackColor = true;
         // 
         // plotterDisplayEx1
         // 
         this.plotterDisplayEx1.BackColor = System.Drawing.Color.White;
         this.plotterDisplayEx1.BackgroundColorBot = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
         this.plotterDisplayEx1.BackgroundColorTop = System.Drawing.Color.Navy;
         this.plotterDisplayEx1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
         this.plotterDisplayEx1.DashedGridColor = System.Drawing.Color.Blue;
         this.plotterDisplayEx1.Dock = System.Windows.Forms.DockStyle.Fill;
         this.plotterDisplayEx1.DoubleBuffering = true;
         this.plotterDisplayEx1.Location = new System.Drawing.Point(3, 3);
         this.plotterDisplayEx1.Name = "plotterDisplayEx1";
         this.plotterDisplayEx1.Size = new System.Drawing.Size(970, 485);
         this.plotterDisplayEx1.Skala_in_Min = 0;
         this.plotterDisplayEx1.SolidGridColor = System.Drawing.Color.Blue;
         this.plotterDisplayEx1.TabIndex = 8;
         // 
         // tabPage5
         // 
         this.tabPage5.Controls.Add(this.gbxStats);
         this.tabPage5.Location = new System.Drawing.Point(4, 22);
         this.tabPage5.Name = "tabPage5";
         this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
         this.tabPage5.Size = new System.Drawing.Size(976, 491);
         this.tabPage5.TabIndex = 4;
         this.tabPage5.Text = "Statistik";
         this.tabPage5.UseVisualStyleBackColor = true;
         // 
         // gbxStats
         // 
         this.gbxStats.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
         this.gbxStats.AutoSize = true;
         this.gbxStats.BackColor = System.Drawing.Color.Orange;
         this.gbxStats.Controls.Add(this.groupBox6);
         this.gbxStats.Controls.Add(this.btnRefreshData);
         this.gbxStats.Controls.Add(this.mydataGridView2);
         this.gbxStats.Controls.Add(this.groupBox5);
         this.gbxStats.Location = new System.Drawing.Point(4, 4);
         this.gbxStats.Name = "gbxStats";
         this.gbxStats.Size = new System.Drawing.Size(969, 484);
         this.gbxStats.TabIndex = 127;
         this.gbxStats.TabStop = false;
         // 
         // groupBox6
         // 
         this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
         this.groupBox6.AutoSize = true;
         this.groupBox6.BackColor = System.Drawing.Color.Tomato;
         this.groupBox6.Controls.Add(this.label20);
         this.groupBox6.Controls.Add(this.TextBox_status);
         this.groupBox6.Controls.Add(this.btnClearErrMsg);
         this.groupBox6.Location = new System.Drawing.Point(4, 330);
         this.groupBox6.Name = "groupBox6";
         this.groupBox6.Size = new System.Drawing.Size(959, 62);
         this.groupBox6.TabIndex = 129;
         this.groupBox6.TabStop = false;
         // 
         // label20
         // 
         this.label20.AutoSize = true;
         this.label20.Location = new System.Drawing.Point(65, 24);
         this.label20.Name = "label20";
         this.label20.Size = new System.Drawing.Size(79, 13);
         this.label20.TabIndex = 128;
         this.label20.Text = "Fehlermeldung:";
         // 
         // btnRefreshData
         // 
         this.btnRefreshData.BackColor = System.Drawing.SystemColors.ButtonFace;
         this.btnRefreshData.Location = new System.Drawing.Point(339, 207);
         this.btnRefreshData.Name = "btnRefreshData";
         this.btnRefreshData.Size = new System.Drawing.Size(114, 24);
         this.btnRefreshData.TabIndex = 510;
         this.btnRefreshData.Text = "Daten aktualisieren";
         this.btnRefreshData.UseVisualStyleBackColor = false;
         this.btnRefreshData.Click += new System.EventHandler(this.btnRefreshData_Click);
         // 
         // mydataGridView2
         // 
         this.mydataGridView2.AllowUserToAddRows = false;
         this.mydataGridView2.AllowUserToDeleteRows = false;
         this.mydataGridView2.AllowUserToResizeColumns = false;
         this.mydataGridView2.AllowUserToResizeRows = false;
         this.mydataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
         this.mydataGridView2.BackgroundColor = System.Drawing.SystemColors.Info;
         this.mydataGridView2.Location = new System.Drawing.Point(4, 15);
         this.mydataGridView2.Name = "mydataGridView2";
         this.mydataGridView2.Size = new System.Drawing.Size(960, 186);
         this.mydataGridView2.TabIndex = 4;
         // 
         // groupBox5
         // 
         this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
         this.groupBox5.AutoSize = true;
         this.groupBox5.BackColor = System.Drawing.Color.SkyBlue;
         this.groupBox5.Controls.Add(this.label45);
         this.groupBox5.Controls.Add(this.label25);
         this.groupBox5.Controls.Add(this.btnLoadOtherCsv);
         this.groupBox5.Controls.Add(this.tbDataFile);
         this.groupBox5.Controls.Add(this.tbCurrDataFile);
         this.groupBox5.Controls.Add(this.btnLoadCurrCsv);
         this.groupBox5.Location = new System.Drawing.Point(4, 236);
         this.groupBox5.Name = "groupBox5";
         this.groupBox5.Size = new System.Drawing.Size(959, 88);
         this.groupBox5.TabIndex = 128;
         this.groupBox5.TabStop = false;
         // 
         // label45
         // 
         this.label45.AutoSize = true;
         this.label45.Location = new System.Drawing.Point(613, 18);
         this.label45.Name = "label45";
         this.label45.Size = new System.Drawing.Size(81, 13);
         this.label45.TabIndex = 127;
         this.label45.Text = "(nicht änderbar)";
         // 
         // label25
         // 
         this.label25.AutoSize = true;
         this.label25.Location = new System.Drawing.Point(65, 18);
         this.label25.Name = "label25";
         this.label25.Size = new System.Drawing.Size(103, 13);
         this.label25.TabIndex = 126;
         this.label25.Text = "Aktuelle Datendatei:";
         // 
         // btnLoadOtherCsv
         // 
         this.btnLoadOtherCsv.BackColor = System.Drawing.SystemColors.ButtonFace;
         this.btnLoadOtherCsv.Location = new System.Drawing.Point(6, 44);
         this.btnLoadOtherCsv.Name = "btnLoadOtherCsv";
         this.btnLoadOtherCsv.Size = new System.Drawing.Size(166, 24);
         this.btnLoadOtherCsv.TabIndex = 511;
         this.btnLoadOtherCsv.Text = "lade andere Datenwochendatei";
         this.btnLoadOtherCsv.UseVisualStyleBackColor = false;
         this.btnLoadOtherCsv.Click += new System.EventHandler(this.btnLoadOtherCsv_Click);
         // 
         // tbDataFile
         // 
         this.tbDataFile.Location = new System.Drawing.Point(174, 46);
         this.tbDataFile.Name = "tbDataFile";
         this.tbDataFile.Size = new System.Drawing.Size(436, 20);
         this.tbDataFile.TabIndex = 124;
         // 
         // tbCurrDataFile
         // 
         this.tbCurrDataFile.Location = new System.Drawing.Point(174, 15);
         this.tbCurrDataFile.Name = "tbCurrDataFile";
         this.tbCurrDataFile.Size = new System.Drawing.Size(436, 20);
         this.tbCurrDataFile.TabIndex = 125;
         // 
         // btnLoadCurrCsv
         // 
         this.btnLoadCurrCsv.BackColor = System.Drawing.SystemColors.ButtonFace;
         this.btnLoadCurrCsv.Location = new System.Drawing.Point(616, 44);
         this.btnLoadCurrCsv.Name = "btnLoadCurrCsv";
         this.btnLoadCurrCsv.Size = new System.Drawing.Size(136, 24);
         this.btnLoadCurrCsv.TabIndex = 512;
         this.btnLoadCurrCsv.Text = "lade aktuelle Datendatei";
         this.btnLoadCurrCsv.UseVisualStyleBackColor = false;
         this.btnLoadCurrCsv.Click += new System.EventHandler(this.btnLoadCurrCsv_Click);
         // 
         // toolStrip1
         // 
         this.toolStrip1.AutoSize = false;
         this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtnSaveAll,
            this.toolStripSeparator4,
            this.tsbtnReadAll,
            this.toolStripLabel1,
            this.tscbPollInterval,
            this.tsbtnStartStop,
            this.toolStripSeparator2,
            this.toolStripLabel2,
            this.toolStripSeparator1,
            this.toolStripLabel3,
            this.tscbGraphArea,
            this.toolStripSeparator3,
            this.toolStripLabel4,
            this.toolStripTextBox1,
            this.toolStripLabel5,
            this.toolStripTextBox2,
            this.tsbtnInfo});
         this.toolStrip1.Location = new System.Drawing.Point(0, 0);
         this.toolStrip1.Name = "toolStrip1";
         this.toolStrip1.Size = new System.Drawing.Size(984, 27);
         this.toolStrip1.TabIndex = 150;
         this.toolStrip1.Text = "toolStrip1";
         // 
         // tsbtnSaveAll
         // 
         this.tsbtnSaveAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.tsbtnSaveAll.Image = global::Viess_Data.Properties.Resources.Save;
         this.tsbtnSaveAll.ImageTransparentColor = System.Drawing.Color.Magenta;
         this.tsbtnSaveAll.Name = "tsbtnSaveAll";
         this.tsbtnSaveAll.Size = new System.Drawing.Size(23, 24);
         this.tsbtnSaveAll.Text = "toolStripButton1";
         this.tsbtnSaveAll.ToolTipText = "alles sichern";
         this.tsbtnSaveAll.Click += new System.EventHandler(this.tsbtnSaveAll_Click);
         // 
         // toolStripSeparator4
         // 
         this.toolStripSeparator4.AutoSize = false;
         this.toolStripSeparator4.Name = "toolStripSeparator4";
         this.toolStripSeparator4.Size = new System.Drawing.Size(30, 25);
         // 
         // tsbtnReadAll
         // 
         this.tsbtnReadAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.tsbtnReadAll.Image = global::Viess_Data.Properties.Resources.Loop;
         this.tsbtnReadAll.ImageTransparentColor = System.Drawing.Color.Magenta;
         this.tsbtnReadAll.Name = "tsbtnReadAll";
         this.tsbtnReadAll.Size = new System.Drawing.Size(23, 24);
         this.tsbtnReadAll.Text = "toolStripButton3";
         this.tsbtnReadAll.ToolTipText = "alle DP lesen";
         this.tsbtnReadAll.Click += new System.EventHandler(this.tsbtnReadAll_Click);
         // 
         // toolStripLabel1
         // 
         this.toolStripLabel1.Name = "toolStripLabel1";
         this.toolStripLabel1.Size = new System.Drawing.Size(123, 24);
         this.toolStripLabel1.Text = "Abfrageintervall [Sek]:";
         // 
         // tscbPollInterval
         // 
         this.tscbPollInterval.AutoSize = false;
         this.tscbPollInterval.BackColor = System.Drawing.SystemColors.Window;
         this.tscbPollInterval.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
         this.tscbPollInterval.Name = "tscbPollInterval";
         this.tscbPollInterval.Size = new System.Drawing.Size(55, 23);
         this.tscbPollInterval.SelectedIndexChanged += new System.EventHandler(this.tscbPollInterval_SelectedIndexChanged);
         this.tscbPollInterval.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tscbPollInterval_KeyUp);
         // 
         // tsbtnStartStop
         // 
         this.tsbtnStartStop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
         this.tsbtnStartStop.Image = global::Viess_Data.Properties.Resources.Player_Play;
         this.tsbtnStartStop.ImageTransparentColor = System.Drawing.Color.Magenta;
         this.tsbtnStartStop.Name = "tsbtnStartStop";
         this.tsbtnStartStop.Size = new System.Drawing.Size(23, 24);
         this.tsbtnStartStop.Text = "StartStop";
         this.tsbtnStartStop.ToolTipText = "Start/Stop Polling";
         this.tsbtnStartStop.Click += new System.EventHandler(this.tsbtnStartStop_Click);
         // 
         // toolStripSeparator2
         // 
         this.toolStripSeparator2.Name = "toolStripSeparator2";
         this.toolStripSeparator2.Size = new System.Drawing.Size(6, 27);
         // 
         // toolStripLabel2
         // 
         this.toolStripLabel2.AutoSize = false;
         this.toolStripLabel2.Name = "toolStripLabel2";
         this.toolStripLabel2.Size = new System.Drawing.Size(22, 22);
         this.toolStripLabel2.Text = "toolStripLabel2";
         // 
         // toolStripSeparator1
         // 
         this.toolStripSeparator1.AutoSize = false;
         this.toolStripSeparator1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
         this.toolStripSeparator1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
         this.toolStripSeparator1.Name = "toolStripSeparator1";
         this.toolStripSeparator1.Size = new System.Drawing.Size(50, 25);
         // 
         // toolStripLabel3
         // 
         this.toolStripLabel3.Name = "toolStripLabel3";
         this.toolStripLabel3.Size = new System.Drawing.Size(42, 24);
         this.toolStripLabel3.Text = "Graph:";
         // 
         // tscbGraphArea
         // 
         this.tscbGraphArea.AutoSize = false;
         this.tscbGraphArea.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.tscbGraphArea.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
         this.tscbGraphArea.Name = "tscbGraphArea";
         this.tscbGraphArea.Size = new System.Drawing.Size(55, 23);
         this.tscbGraphArea.SelectedIndexChanged += new System.EventHandler(this.tscbGraphArea_SelectedIndexChanged);
         // 
         // toolStripSeparator3
         // 
         this.toolStripSeparator3.AutoSize = false;
         this.toolStripSeparator3.Name = "toolStripSeparator3";
         this.toolStripSeparator3.Size = new System.Drawing.Size(30, 25);
         // 
         // toolStripLabel4
         // 
         this.toolStripLabel4.Name = "toolStripLabel4";
         this.toolStripLabel4.Size = new System.Drawing.Size(48, 24);
         this.toolStripLabel4.Text = "lese DP:";
         // 
         // toolStripTextBox1
         // 
         this.toolStripTextBox1.Name = "toolStripTextBox1";
         this.toolStripTextBox1.Size = new System.Drawing.Size(35, 27);
         // 
         // toolStripLabel5
         // 
         this.toolStripLabel5.Name = "toolStripLabel5";
         this.toolStripLabel5.Size = new System.Drawing.Size(46, 24);
         this.toolStripLabel5.Text = "Anzahl:";
         this.toolStripLabel5.ToolTipText = "Datenpunktnummer";
         // 
         // toolStripTextBox2
         // 
         this.toolStripTextBox2.Name = "toolStripTextBox2";
         this.toolStripTextBox2.Size = new System.Drawing.Size(35, 27);
         // 
         // tsbtnInfo
         // 
         this.tsbtnInfo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
         this.tsbtnInfo.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnInfo.Image")));
         this.tsbtnInfo.ImageTransparentColor = System.Drawing.Color.Magenta;
         this.tsbtnInfo.Name = "tsbtnInfo";
         this.tsbtnInfo.Size = new System.Drawing.Size(32, 24);
         this.tsbtnInfo.Text = "Info";
         this.tsbtnInfo.ToolTipText = "Gerät Info anzeigen";
         this.tsbtnInfo.Click += new System.EventHandler(this.tsbtnInfo_Click);
         // 
         // Main_Form
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(984, 554);
         this.Controls.Add(this.toolStrip1);
         this.Controls.Add(this.tabControl1);
         this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
         this.Name = "Main_Form";
         this.Text = "Viessdata ";
         this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Main_Form_Closing);
         this.Load += new System.EventHandler(this.Main_Form_Load);
         this.Shown += new System.EventHandler(this.Main_Form_Shown);
         ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
         ((System.ComponentModel.ISupportInitialize)(this.dataSet2)).EndInit();
         this.tabControl1.ResumeLayout(false);
         this.tabPage1.ResumeLayout(false);
         this.tabPage1.PerformLayout();
         this.tabPage2.ResumeLayout(false);
         this.gbxComSettings.ResumeLayout(false);
         this.gbxComSettings.PerformLayout();
         ((System.ComponentModel.ISupportInitialize)(this.mydataGridView1)).EndInit();
         this.tabPage3.ResumeLayout(false);
         this.tabPage3.PerformLayout();
         this.GroupBox2206.ResumeLayout(false);
         this.GroupBox2206.PerformLayout();
         this.GroupBox2204.ResumeLayout(false);
         this.GroupBox2204.PerformLayout();
         this.GroupBox2202.ResumeLayout(false);
         this.GroupBox2202.PerformLayout();
         this.GroupBox2200.ResumeLayout(false);
         this.GroupBox2200.PerformLayout();
         this.tabPage4.ResumeLayout(false);
         this.tabPage5.ResumeLayout(false);
         this.tabPage5.PerformLayout();
         this.gbxStats.ResumeLayout(false);
         this.gbxStats.PerformLayout();
         this.groupBox6.ResumeLayout(false);
         this.groupBox6.PerformLayout();
         ((System.ComponentModel.ISupportInitialize)(this.mydataGridView2)).EndInit();
         this.groupBox5.ResumeLayout(false);
         this.groupBox5.PerformLayout();
         this.toolStrip1.ResumeLayout(false);
         this.toolStrip1.PerformLayout();
         this.ResumeLayout(false);

      }

      #endregion

      private System.Data.DataSet dataSet1;
      private System.Data.DataSet dataSet2;
      private System.Windows.Forms.OpenFileDialog openFileDialog1;
      private System.Windows.Forms.Button btnClearErrMsg;
      internal System.Windows.Forms.TextBox TextBox_status;
      private System.Windows.Forms.TabControl tabControl1;
      private System.Windows.Forms.TabPage tabPage1;
      internal System.Windows.Forms.Label label21;
      private System.Windows.Forms.TextBox TextBoxRTS_Tag;
      internal System.Windows.Forms.Label label14;
      private System.Windows.Forms.TextBox TextBoxRTS_Party;
      private System.Windows.Forms.TextBox TextBox3304;
      private System.Windows.Forms.TextBox TextBox3305;
      private System.Windows.Forms.CheckBox ChB_Sparbetrieb;
      private System.Windows.Forms.CheckBox ChB_Partybetrieb;
      internal System.Windows.Forms.Label label12;
      internal System.Windows.Forms.Label label10;
      internal System.Windows.Forms.TextBox TextBox0812;
      internal System.Windows.Forms.Label Label0842;
      internal System.Windows.Forms.Label Label3906;
      internal System.Windows.Forms.Label Label0883;
      internal System.Windows.Forms.Label Label0845;
      internal System.Windows.Forms.Label Label0846;
      internal System.Windows.Forms.TextBox TextBox081A;
      internal System.Windows.Forms.Label label46;
      internal System.Windows.Forms.TextBox TextBox5525;
      internal System.Windows.Forms.Label Label11;
      internal System.Windows.Forms.Label Label8;
      internal System.Windows.Forms.Label Label0845a;
      internal System.Windows.Forms.Label Label0846a;
      internal System.Windows.Forms.TextBox TextBox088A;
      internal System.Windows.Forms.Label Label17;
      internal System.Windows.Forms.Label Label15;
      internal System.Windows.Forms.TextBox TextBox0818;
      internal System.Windows.Forms.Label Label0883a;
      internal System.Windows.Forms.TextBox TextBox0810;
      internal System.Windows.Forms.Label label30;
      internal System.Windows.Forms.Label label38;
      internal System.Windows.Forms.TextBox TextBox0808;
      internal System.Windows.Forms.TextBox TextBox080A;
      internal System.Windows.Forms.TextBox TextBox080C;
      internal System.Windows.Forms.Label label39;
      internal System.Windows.Forms.TextBox TextBox0804;
      internal System.Windows.Forms.TextBox TextBox0802;
      internal System.Windows.Forms.TextBox TextBox0800;
      internal System.Windows.Forms.Label label41;
      internal System.Windows.Forms.Label label43;
      internal System.Windows.Forms.Label label44;
      internal System.Windows.Forms.TextBox TextBox08A7;
      internal System.Windows.Forms.Label label23;
      private System.Windows.Forms.TabPage tabPage2;
      private System.Windows.Forms.Button btn_select_kein;
      private System.Windows.Forms.Button btn_select_alle;
      private System.Windows.Forms.Button btnClearChart;
      private System.Windows.Forms.GroupBox gbxComSettings;
      private System.Windows.Forms.Label label6;
      private System.Windows.Forms.ComboBox CoBx_Handshake;
      private System.Windows.Forms.Label label5;
      private System.Windows.Forms.ComboBox CoBx_Datenbits;
      private System.Windows.Forms.Label label4;
      private System.Windows.Forms.ComboBox CoBx_Stopbits;
      private System.Windows.Forms.Label label3;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.ComboBox CoBx_Parity;
      private System.Windows.Forms.Label Label1;
      private System.Windows.Forms.ComboBox CoBx_BaudRate;
      private System.Windows.Forms.ComboBox cbxPort;
      private System.Windows.Forms.DataGridView mydataGridView1;
      private System.Windows.Forms.TabPage tabPage3;
      private System.Windows.Forms.RadioButton radioButton3;
      private System.Windows.Forms.RadioButton radioButton2;
      private System.Windows.Forms.RadioButton radioButton1;
      internal System.Windows.Forms.GroupBox GroupBox2206;
      internal System.Windows.Forms.TextBox TextBox154;
      internal System.Windows.Forms.TextBox TextBox146;
      internal System.Windows.Forms.TextBox TextBox138;
      internal System.Windows.Forms.TextBox TextBox130;
      internal System.Windows.Forms.TextBox TextBox155;
      internal System.Windows.Forms.TextBox TextBox147;
      internal System.Windows.Forms.TextBox TextBox139;
      internal System.Windows.Forms.TextBox TextBox131;
      internal System.Windows.Forms.TextBox TextBox123;
      internal System.Windows.Forms.TextBox TextBox122;
      internal System.Windows.Forms.TextBox TextBox115;
      internal System.Windows.Forms.TextBox TextBox114;
      internal System.Windows.Forms.TextBox TextBox107;
      internal System.Windows.Forms.Label label51;
      internal System.Windows.Forms.Label label52;
      internal System.Windows.Forms.TextBox TextBox106;
      internal System.Windows.Forms.GroupBox GroupBox2204;
      internal System.Windows.Forms.TextBox TextBox152;
      internal System.Windows.Forms.TextBox TextBox144;
      internal System.Windows.Forms.TextBox TextBox136;
      internal System.Windows.Forms.TextBox TextBox128;
      internal System.Windows.Forms.TextBox TextBox153;
      internal System.Windows.Forms.TextBox TextBox145;
      internal System.Windows.Forms.TextBox TextBox137;
      internal System.Windows.Forms.TextBox TextBox129;
      internal System.Windows.Forms.TextBox TextBox121;
      internal System.Windows.Forms.TextBox TextBox120;
      internal System.Windows.Forms.TextBox TextBox113;
      internal System.Windows.Forms.TextBox TextBox112;
      internal System.Windows.Forms.TextBox TextBox105;
      internal System.Windows.Forms.Label label49;
      internal System.Windows.Forms.Label label50;
      internal System.Windows.Forms.TextBox TextBox104;
      internal System.Windows.Forms.GroupBox GroupBox2202;
      internal System.Windows.Forms.TextBox TextBox150;
      internal System.Windows.Forms.TextBox TextBox142;
      internal System.Windows.Forms.TextBox TextBox134;
      internal System.Windows.Forms.TextBox TextBox126;
      internal System.Windows.Forms.TextBox TextBox151;
      internal System.Windows.Forms.TextBox TextBox143;
      internal System.Windows.Forms.TextBox TextBox135;
      internal System.Windows.Forms.TextBox TextBox127;
      internal System.Windows.Forms.TextBox TextBox119;
      internal System.Windows.Forms.TextBox TextBox118;
      internal System.Windows.Forms.TextBox TextBox111;
      internal System.Windows.Forms.TextBox TextBox110;
      internal System.Windows.Forms.TextBox TextBox103;
      internal System.Windows.Forms.Label label16;
      internal System.Windows.Forms.Label label18;
      internal System.Windows.Forms.TextBox TextBox102;
      internal System.Windows.Forms.TextBox TextBox0200;
      internal System.Windows.Forms.Label Label42;
      internal System.Windows.Forms.Label Label40;
      internal System.Windows.Forms.Label Label37;
      internal System.Windows.Forms.Label Label36;
      internal System.Windows.Forms.Label Label35;
      internal System.Windows.Forms.Label Label34;
      internal System.Windows.Forms.Label Label33;
      internal System.Windows.Forms.Label Label32;
      internal System.Windows.Forms.Label Label31;
      internal System.Windows.Forms.GroupBox GroupBox2200;
      internal System.Windows.Forms.TextBox TextBox148;
      internal System.Windows.Forms.TextBox TextBox140;
      internal System.Windows.Forms.TextBox TextBox132;
      internal System.Windows.Forms.TextBox TextBox124;
      internal System.Windows.Forms.TextBox TextBox149;
      internal System.Windows.Forms.TextBox TextBox141;
      internal System.Windows.Forms.TextBox TextBox133;
      internal System.Windows.Forms.TextBox TextBox125;
      internal System.Windows.Forms.TextBox TextBox117;
      internal System.Windows.Forms.TextBox TextBox116;
      internal System.Windows.Forms.TextBox TextBox109;
      internal System.Windows.Forms.TextBox TextBox108;
      internal System.Windows.Forms.TextBox TextBox101;
      internal System.Windows.Forms.Label Label74;
      internal System.Windows.Forms.Label Label75;
      internal System.Windows.Forms.TextBox TextBox100;
      private System.Windows.Forms.TabPage tabPage4;
      private System.Windows.Forms.TabPage tabPage5;
      private System.Windows.Forms.TextBox tbCurrDataFile;
      private System.Windows.Forms.TextBox tbDataFile;
      private System.Windows.Forms.Button btnLoadCurrCsv;
      private System.Windows.Forms.Button btnLoadOtherCsv;
      private System.Windows.Forms.Button btnRefreshData;
      private System.Windows.Forms.DataGridView mydataGridView2;
      private GraphLib.PlotterDisplayEx plotterDisplayEx1;
      private System.Windows.Forms.ToolStrip toolStrip1;
      private System.Windows.Forms.ToolStripButton tsbtnSaveAll;
      private System.Windows.Forms.ToolStripButton tsbtnReadAll;
      private System.Windows.Forms.ToolStripLabel toolStripLabel1;
      private System.Windows.Forms.ToolStripComboBox tscbPollInterval;
      private System.Windows.Forms.ToolStripButton tsbtnStartStop;
      private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
      private System.Windows.Forms.ToolStripLabel toolStripLabel2;
      private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
      private System.Windows.Forms.ToolStripLabel toolStripLabel3;
      private System.Windows.Forms.ToolStripComboBox tscbGraphArea;
      private System.Windows.Forms.Label label25;
      private System.Windows.Forms.GroupBox gbxStats;
      private System.Windows.Forms.GroupBox groupBox5;
      private System.Windows.Forms.GroupBox groupBox6;
      private System.Windows.Forms.ToolStripLabel toolStripLabel4;
      private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
      private System.Windows.Forms.ToolStripLabel toolStripLabel5;
      private System.Windows.Forms.ToolStripTextBox toolStripTextBox2;
      private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
      private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
      private System.Windows.Forms.Label label45;
      internal System.Windows.Forms.Label label9;
      internal System.Windows.Forms.Label label22;
      private System.Windows.Forms.TextBox TextBoxRTS_Nacht;
      internal System.Windows.Forms.Label label13;
      internal System.Windows.Forms.Label label27;
      internal System.Windows.Forms.Label label26;
      internal System.Windows.Forms.Label label24;
      internal System.Windows.Forms.Label label28;
      internal System.Windows.Forms.Label label29;
      internal System.Windows.Forms.Label label47;
      internal System.Windows.Forms.Label Frostgefahr;
      internal System.Windows.Forms.Label La_Betriebsart;
      private System.Windows.Forms.ComboBox CB_Betriebsart;
      internal System.Windows.Forms.Label label48;
      private System.Windows.Forms.TextBox TextBoxWWS;
      private System.Windows.Forms.ComboBox CB_WWHysterese;
      internal System.Windows.Forms.Label label19;
      private System.Windows.Forms.ComboBox CB_Frostschutztemp;
      internal System.Windows.Forms.Label label53;
      private System.Windows.Forms.TextBox TB_PumpebeiWW;
      internal System.Windows.Forms.Label label54;
      private System.Windows.Forms.TextBox TB_ErhoehungKTS;
      internal System.Windows.Forms.Label label55;
      private System.Windows.Forms.TextBox TB_ErhoehungszeitKTS;
      internal System.Windows.Forms.Label label56;
      private System.Windows.Forms.TextBox TB_PlstbeiRed;
      private System.Windows.Forms.TextBox TB_PlstminbeiNorm;
      private System.Windows.Forms.TextBox TB_PlstmaxbeiNorm;
      private System.Windows.Forms.CheckBox ChB_PlstbeiRed;
      internal System.Windows.Forms.Label label59;
      internal System.Windows.Forms.Label label58;
      internal System.Windows.Forms.Label label57;
      private System.Windows.Forms.TextBox TB_MaxBrennerWW;
      internal System.Windows.Forms.Label label61;
      private System.Windows.Forms.TextBox TB_MaxDeltaKTWW;
      internal System.Windows.Forms.Label label62;
      private System.Windows.Forms.TextBox TB_NachlaufWW;
      internal System.Windows.Forms.Label label63;
      private System.Windows.Forms.ComboBox CB_ZirkuFrequ;
      private System.Windows.Forms.TextBox TB_DaempfungAT;
      internal System.Windows.Forms.Label label65;
      internal System.Windows.Forms.Label label64;
      private System.Windows.Forms.ComboBox CB_SparBrenner;
      private System.Windows.Forms.ComboBox CB_SparHK;
      internal System.Windows.Forms.Label label66;
      internal System.Windows.Forms.Label label60;
      internal System.Windows.Forms.TextBox textBox3;
      internal System.Windows.Forms.Label label67;
      internal System.Windows.Forms.Label label86;
      internal System.Windows.Forms.Label label85;
      internal System.Windows.Forms.Label label84;
      internal System.Windows.Forms.Label label83;
      internal System.Windows.Forms.Label label82;
      internal System.Windows.Forms.Label label81;
      internal System.Windows.Forms.Label label80;
      internal System.Windows.Forms.Label label79;
      internal System.Windows.Forms.Label label78;
      internal System.Windows.Forms.Label label77;
      internal System.Windows.Forms.Label label76;
      internal System.Windows.Forms.Label label73;
      internal System.Windows.Forms.Label label72;
      internal System.Windows.Forms.Label label71;
      internal System.Windows.Forms.Label label70;
      internal System.Windows.Forms.Label label69;
      internal System.Windows.Forms.Label label68;
      internal System.Windows.Forms.Label label89;
      private System.Windows.Forms.TextBox TB_MaxBrennerNH;
      internal System.Windows.Forms.Label label88;
      private System.Windows.Forms.Button btnSendTimeTable;
      internal System.Windows.Forms.TextBox TextBoxRL;
      internal System.Windows.Forms.Label label7;
      private System.Windows.Forms.Label label20;
      internal System.Windows.Forms.Label label91;
      internal System.Windows.Forms.TextBox TextBoxRT;
      internal System.Windows.Forms.Label Label_SparA6;
      internal System.Windows.Forms.Label Label_SparA5;
      internal System.Windows.Forms.TextBox TB_RTSakt;
      internal System.Windows.Forms.TextBox tbBrennwert;
      internal System.Windows.Forms.TextBox tbZZahl;
      internal System.Windows.Forms.Label label90;
      internal System.Windows.Forms.Label label87;
      internal System.Windows.Forms.Label label93;
      internal System.Windows.Forms.Label label92;
      private System.Windows.Forms.Button btnNewCsv;
      private System.Windows.Forms.Button btnWriteDp;
      private System.Windows.Forms.Button btnReadDp;
      private System.Windows.Forms.Button btnClearRowVal;
      private System.Windows.Forms.Label lblHint;
      private System.Windows.Forms.ToolStripButton tsbtnInfo;
   }
}

