﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Viess_Data.Programme
{

   public class myProgram
   {
      // Der Haupteinstiegspunkt für die Anwendung.

      [STAThread]
      public static void Main(string[] args)
      {
         try
         {
            // Das ThreadException-Ereignis der Application-Klasse zuweisen
            // um unbehandelte UI-Thread-Fehler abzufangen 
            Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(myProgram.Application_ThreadException);

            // Das UnhandledException-Ereignis der aktuellen Anwendungsdomäne 
            // zuweisen um unbehandelte Arbeits-Thread-Fehler abzufangen
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(myProgram.CurrentDomain_UnhandledException);

            //Run
            //Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.Run(new Main_Form(args));
         }
         catch (Exception ex)
         {
            MessageBox.Show(ex.Message + ex.StackTrace, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);
         }
      }

      /// <summary>
      /// Fängt unbehandelte Exceptions ab, die im UI-Thread auftreten
      /// </summary>
      /// <param name="sender">Exception auslöser</param>
      /// <param name="e">Ereignisdaten</param>
      private static void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
      {
         //MessageBox.Show("Unhandled UI-Thread-Error: " + e.Exception, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);
      }

      /// <summary>
      /// Fängt unbehandelte Exceptions ab, die in einem 
      /// Arbeits-Thread auftreten 
      /// </summary>
      /// <param name="sender">Exception auslöser</param>
      /// <param name="e">Ereignisdaten</param>
      private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
      {
         //Exception auslesen
         Exception ex = e.ExceptionObject as Exception;

         if (ex != null)
         {
            //MessageBox.Show("Unhandled Working-Thread-Error " + ex.Message + ex.StackTrace, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);
         }
         else
         {
            //MessageBox.Show("Unhandled Working-Thread-Error, Type: '" + e.ExceptionObject.GetType().Name + "'", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);
         }
      }
   }
}
