﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace Viess_Data.Programme
{
    class myRoutinen
    {
        public static int BerechneMinute()  // Static damit es allen bkannt ist
        {
            // Welche Minute ist seit Montag 0Uhr vergangen?
            //  normalerweise beginnt die Woche mit dem Sonntag = Day of week = 0
            // da die Kalenderwoche jedoch mit dem Montag beginnen soll muss umgerechnet werden.
            
            DateTime jetzt = DateTime.Now;
            // DateTime jetzt = DateTime.Now.DayOfWeek;
            // DateTime jetzt = new DateTime(2011, 7, 30);

            int TDW = (int)jetzt.DayOfWeek;  // Tag der Woche Sonntag = 0, Montag = 1, ..., Samstag = 6
            if (TDW != 0) TDW = TDW - 1; else TDW = TDW + 6;

            //   DateTime jetzt = DateTime.Now;
            int Min_Seit_Montag = TDW * 24 * 60 + jetzt.Hour * 60 + jetzt.Minute;
            return Min_Seit_Montag;
        }



    }
}
